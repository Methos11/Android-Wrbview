package cn.autoforged.android_browser_mod_1789566815;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BiConsumer;

/**
 * Companion-helper bridge for ZL2/Pojav where the Minecraft JVM cannot see Android
 * framework classes. The helper app owns the real Android WebView and exposes a
 * localhost-only HTTP endpoint. No ZL2 modification is required.
 */
public final class LocalWebViewHelperBridge {
    private static final String HOST = "127.0.0.1";
    private static final int PORT = 28765;
    private static final String BASE = "http://" + HOST + ":" + PORT;
    private static final AtomicBoolean running = new AtomicBoolean(false);
    private static volatile boolean helperOnline;
    private static volatile boolean ready;
    private static volatile long frames;
    private static volatile String currentUrl = "";
    private static volatile String lastError = "";
    private static volatile Thread pollThread;
    private static volatile BiConsumer<int[], int[]> sink;
    private static volatile int width = 1024;
    private static volatile int height = 1024;

    private LocalWebViewHelperBridge() {}

    public static boolean available() {
        try {
            String s = request("GET", "/health", null, 1200);
            helperOnline = s != null && s.contains("WEBVIEW_HELPER_OK");
        } catch (Throwable t) {
            helperOnline = false;
        }
        return helperOnline;
    }

    public static void start(int w, int h, BiConsumer<int[], int[]> frameSink) {
        width = Math.max(256, Math.min(1536, w));
        height = Math.max(256, Math.min(1536, h));
        sink = frameSink;
        if (!available()) {
            lastError = "helper offline: start WebView Helper first";
            ExampleMod.LOGGER.warn("[WebView-Helper] {}", lastError);
            return;
        }
        running.set(true);
        ready = false;
        Thread old = pollThread;
        if (old != null && old.isAlive()) return;
        pollThread = new Thread(LocalWebViewHelperBridge::pollLoop, "WebView-Helper-Bridge");
        pollThread.setDaemon(true);
        pollThread.start();
        post("/configure", "width=" + width + "&height=" + height);
        ExampleMod.LOGGER.info("[WebView-Helper] connected to localhost:{}", PORT);
    }

    public static void loadUrl(String url) {
        if (url == null || url.isBlank()) return;
        currentUrl = url;
        String body = "url=" + enc(url);
        if (!post("/navigate", body)) {
            lastError = "navigate failed; helper offline?";
        }
    }

    public static void forwardTouch(int action, float x, float y) {
        post("/touch", "action=" + action + "&x=" + x + "&y=" + y);
    }

    public static void forwardKey(int action, int keyCode, int repeat, String chars) {
        String body = "action=" + action + "&key=" + keyCode + "&repeat=" + repeat + "&chars=" + enc(chars == null ? "" : chars);
        post("/key", body);
    }

    public static void forwardScroll(float dx, float dy) {
        post("/scroll", "dx=" + dx + "&dy=" + dy);
    }

    public static void setMuted(boolean muted) {
        post("/mute", "value=" + (muted ? "1" : "0"));
    }

    public static void stop() {
        running.set(false);
        Thread t = pollThread;
        pollThread = null;
        if (t != null) t.interrupt();
        sink = null;
        ready = false;
    }

    public static boolean online() { return helperOnline; }
    public static boolean pageReady() { return ready; }
    public static long frameCount() { return frames; }
    public static String lastError() { return lastError; }
    public static String currentUrl() { return currentUrl; }
    public static String debugSummary() {
        return "mode=LOCAL_HELPER | helper=" + (helperOnline ? "online" : "offline")
            + " | ready=" + ready + " | frames=" + frames + " | url=" + currentUrl
            + " | error=" + (lastError.isBlank() ? "none" : lastError);
    }

    private static void pollLoop() {
        while (running.get()) {
            try {
                String status = request("GET", "/status", null, 1500);
                if (status != null) {
                    helperOnline = true;
                    ready = status.contains("ready=1");
                    String u = value(status, "url");
                    if (u != null && !u.isBlank()) currentUrl = u;
                } else {
                    helperOnline = false;
                }

                byte[] png = requestBytes("GET", "/frame", (byte[]) null, 4000);
                if (png != null && png.length > 16) {
                    BufferedImage image = ImageIO.read(new ByteArrayInputStream(png));
                    if (image != null) {
                        int w = image.getWidth(), h = image.getHeight();
                        int[] pixels = new int[w * h];
                        image.getRGB(0, 0, w, h, pixels, 0, w);
                        BiConsumer<int[], int[]> s = sink;
                        if (s != null) s.accept(pixels, new int[]{w, h});
                        frames++;
                        ready = true;
                    }
                }
            } catch (Throwable t) {
                helperOnline = false;
                lastError = t.toString();
            }
            try { Thread.sleep(180L); } catch (InterruptedException e) { break; }
        }
    }

    private static String value(String text, String key) {
        for (String line : text.split("\\n")) {
            if (line.startsWith(key + "=")) return line.substring(key.length() + 1);
        }
        return null;
    }

    private static boolean post(String path, String body) {
        try {
            request("POST", path, body, 1800);
            helperOnline = true;
            return true;
        } catch (Throwable t) {
            helperOnline = false;
            lastError = t.toString();
            return false;
        }
    }

    private static String request(String method, String path, String body, int timeout) throws IOException {
        byte[] data = body == null ? null : body.getBytes(StandardCharsets.UTF_8);
        byte[] result = requestBytes(method, path, data, timeout);
        return result == null ? null : new String(result, StandardCharsets.UTF_8);
    }

    private static byte[] requestBytes(String method, String path, String body, int timeout) throws IOException {
        return requestBytes(method, path, body == null ? null : body.getBytes(StandardCharsets.UTF_8), timeout);
    }

    private static byte[] requestBytes(String method, String path, byte[] body, int timeout) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(BASE + path).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(timeout);
        c.setReadTimeout(timeout);
        c.setUseCaches(false);
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            try (OutputStream out = c.getOutputStream()) { out.write(body); }
        }
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw new IOException("HTTP " + code);
        try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
            return out.toByteArray();
        } finally { c.disconnect(); }
    }

    private static String enc(String s) {
        return URLEncoder.encode(s == null ? "" : s, StandardCharsets.UTF_8);
    }
}
