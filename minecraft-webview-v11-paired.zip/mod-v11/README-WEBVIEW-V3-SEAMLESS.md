# WebView Browser Mod v3 — Seamless Screen Wall

This revision addresses the screen-block boundary issue.

## Changes
- Screen block front face is removed from the block model so the vanilla cube face cannot leave a visible border underneath the WebView.
- All adjacent screen blocks with the same URL and facing share one WebView texture.
- Each block samples its own UV tile from that shared texture.
- A tiny 0.0025-block overlap is applied to the screen quad to hide rasterisation cracks between adjacent faces.
- Screen-wall discovery is bounded and checks both URL and facing.
- The WebView texture is automatically loaded when a screen block has a URL.
- Rendering uses Minecraft 26.2 Blaze3D/RenderPipeline APIs (`SubmitNodeCollector` + `RenderTypes.entitySolid`) rather than raw OpenGL.

## Important
This source revision was not fully Gradle-compiled in this environment. Test with the project's normal Minecraft 26.2 Fabric build first. If the compiler reports an API mismatch, provide the build log and the exact 26.2 mappings will be adjusted.
