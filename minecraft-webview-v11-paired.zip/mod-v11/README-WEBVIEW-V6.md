# Android Browser Mod WebView V6

V6 focuses on making the Android WebView bridge robust inside Zalith/Pojav-style classloader environments and making the in-world screen an opaque display rather than transparent glass.

## V6 changes

- Removed the `android.os.Handler` / `android.os.Looper` reflection path from UI dispatch.
- Uses the foreground Android `Activity.runOnUiThread(...)` for WebView creation/navigation.
- Uses `WebView.postDelayed(...)` for the capture loop, so no Android Handler class is required by the game classloader.
- Keeps the WebView attached and visible to satisfy Android WebView drawing requirements.
- Forces captured pixels to alpha `255` before uploading to Minecraft.
- Creates an opaque white loading surface immediately, so the world behind the screen is not visible while the page is loading.
- Clears the previous page to white when a new URL starts loading.
- Adds a small opaque loading progress animation.
- Keeps the connected multi-block wall as one continuous WebView texture with per-block UV slicing.
- Keeps Minecraft 26.2 rendering on Blaze3D/RenderType paths rather than raw OpenGL.
- Uses Java-final UV copies for lambda capture compatibility.
- Gradle wrapper points at the official Gradle distribution URL.

## Build

From the project directory:

```text
./gradlew clean build --no-daemon
```

The source was checked for the previous `u0/v1` lambda-capture error and for the V5 `android.os.Handler` dispatch path. A full Gradle build could not be executed in the generation environment because the Gradle distribution was unavailable there; therefore the archive should be built and tested in the actual Android/Code FA environment before treating the build as verified.


## V6.2 white-board fallback

The screen block front is now a fully opaque solid-white texture. The block model includes the
front face explicitly. If Android WebView is unavailable, the renderer leaves this white board
visible and does not draw the legacy HTML text renderer over it.
