# Android Browser Mod V5 Debug

V5 is a rendering-path debug build, not a claim that the phone-side result has already been verified.

## What changed

1. WebView uses the foreground Android Activity context when available.
2. WebView is attached to the Activity decor hierarchy, remains `VISIBLE`, and is laid out at 1024x1024.
3. The old `alpha=0.01` capture trick is removed. The View stays opaque/visible while positioned off the Minecraft view.
4. Capture runs only on Android's UI thread and pushes immutable ARGB frames to Minecraft.
5. V5 logs creation, attachment, URL, frame number, center pixel and upload number with `[WebView-V5]`.
6. Minecraft receives an opaque texture: alpha is forced to 255.
7. The screen uses `RenderTypes.entitySolid`, not a translucent glass pipeline.
8. A connected screen wall shares one WebView texture. Each block samples only its UV tile, so a 3x2 wall displays one continuous page rather than six repeated pages.
9. The screen block model has no front face; the WebView quad is the opaque front surface.

## Important limitation

The project is still compiled as a normal Fabric/JVM mod and uses reflection for Android APIs. The V5 source must be built and then tested on the target Android launcher. The web page rendering itself cannot be proven by static compilation alone.

## What to look for in the log

- `[WebView-V5] created ... attached=true`
- `[WebView-V5] frame #... center=0x...`
- `[WebView-V5] uploaded frame #...`

If frame capture succeeds but the in-world screen is wrong, the problem is after WebView capture (NativeImage/GPU texture/render pipeline). If frame capture itself is white, the problem is WebView/window/layout/network side.
