package cn.autoforged.webviewhelper;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

/** WebView Helper V13 - modern translucent blue/mint dashboard. */
public class MainActivity extends Activity {
    public static volatile WebView sharedWebView;
    public static volatile String lastError="", pageTitle="", currentUrl="https://www.minecraft.net";
    public static volatile int progress=0;
    public static volatile boolean cssEnabled=true, jsEnabled=true;
    public static final StringBuilder LOG=new StringBuilder(30000);
    final Handler ui=new Handler(Looper.getMainLooper());

    final int BG=Color.rgb(238,248,252);
    final int CARD=Color.argb(220,255,255,255);
    final int BLUE=Color.rgb(83,150,255);
    final int MINT=Color.rgb(70,205,166);
    final int TEXT=Color.rgb(25,42,58);
    final int MUTED=Color.rgb(100,125,143);
    final int SOFTBLUE=Color.rgb(225,239,255);
    final int SOFTMINT=Color.rgb(222,249,240);

    LinearLayout content;
    TextView status, stats, debug;
    EditText url;

    static void log(String s){
        String line=new SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date())+"  "+s;
        synchronized(LOG){ LOG.append(line).append('\n'); if(LOG.length()>29000) LOG.delete(0,LOG.length()-29000); }
        android.util.Log.d("MinecraftWebView",s);
    }
    public static String snapshotLogs(){ synchronized(LOG){ return LOG.toString(); } }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
        createWebView();
        startHelper();
        scheduleRefresh();
    }

    TextView tv(String s,float sp,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    TextView button(String s,boolean primary){
        TextView t=tv(s,14,primary?Color.WHITE:TEXT); t.setGravity(Gravity.CENTER); t.setTypeface(null,1);
        t.setBackground(bg(primary?BLUE:SOFTBLUE,22)); t.setPadding(14,0,14,0); return t;
    }
    LinearLayout card(){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(16,14,16,14); c.setBackground(bg(CARD,26));
        c.setElevation(2); return c;
    }
    LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }
    LinearLayout.LayoutParams lp(int w,int h,float weight){ return new LinearLayout.LayoutParams(w,h,weight); }

    void buildUi(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(BG);
        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(14,10,14,12);
        LinearLayout hero=card();
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand=tv("WebView Helper",24,TEXT); brand.setTypeface(null,1); top.addView(brand,lp(0,42,1));
        TextView ver=tv("V13",12,BLUE); ver.setGravity(Gravity.CENTER); ver.setBackground(bg(SOFTBLUE,18)); top.addView(ver,lp(58,34));
        hero.addView(top,lp(-1,46));
        hero.addView(tv("Minecraft 内置网页渲染桥 · ZL2 / Local Helper",12,MUTED),lp(-1,28));
        LinearLayout state=new LinearLayout(this); state.setGravity(Gravity.CENTER_VERTICAL);
        status=tv("● 连接中…",14,MINT); status.setTypeface(null,1); state.addView(status,lp(0,34,1));
        TextView about=button("诊断",false); about.setOnClickListener(v->showAbout()); state.addView(about,lp(82,38));
        hero.addView(state,lp(-1,44)); page.addView(hero,lp(-1,132));

        LinearLayout bar=card();
        bar.addView(tv("网页地址",12,MUTED),lp(-1,24));
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        url=new EditText(this); url.setSingleLine(true); url.setText(currentUrl); url.setTextColor(TEXT); url.setTextSize(14); url.setPadding(14,0,14,0); url.setBackground(bg(Color.rgb(244,250,255),18));
        row.addView(url,lp(0,48,1));
        TextView go=button("打开",true); go.setOnClickListener(v->navigate(url.getText().toString().trim())); row.addView(go,lp(78,48));
        bar.addView(row,lp(-1,52)); page.addView(bar,lp(-1,92));

        LinearLayout preview=card();
        LinearLayout ph=new LinearLayout(this); ph.setGravity(Gravity.CENTER_VERTICAL);
        TextView pt=tv("实时预览",17,TEXT); pt.setTypeface(null,1); ph.addView(pt,lp(0,34,1));
        TextView reload=button("刷新",false); reload.setOnClickListener(v->{if(sharedWebView!=null)sharedWebView.reload();}); ph.addView(reload,lp(76,36));
        preview.addView(ph,lp(-1,40));
        TextView hint=tv("WebView 原生渲染 · CSS / JS / 图片 / 视频由 Chromium 处理",12,MUTED); preview.addView(hint,lp(-1,30));
        page.addView(preview,lp(-1,86));

        LinearLayout monitor=card();
        monitor.addView(tv("运行状态",17,TEXT),lp(-1,32));
        stats=tv("读取中…",12,MUTED); stats.setTypeface(android.graphics.Typeface.MONOSPACE); monitor.addView(stats,lp(-1,122));
        LinearLayout actions=new LinearLayout(this); TextView copy=button("复制日志",false); copy.setOnClickListener(v->copyLogs()); TextView export=button("导出日志",false); export.setOnClickListener(v->exportLogs()); actions.addView(copy,lp(0,42,1)); actions.addView(export,lp(0,42,1)); monitor.addView(actions,lp(-1,48));
        page.addView(monitor,lp(-1,216));

        LinearLayout settings=card(); settings.addView(tv("性能模式",17,TEXT),lp(-1,32));
        TextView perf=tv("默认：512×512 · 约 8–10 FPS · 页面变化时捕获\n目标：减少 CPU / 内存 / GPU 上传压力",12,MUTED); settings.addView(perf,lp(-1,56));
        TextView stop=button("停止 Helper",false); stop.setOnClickListener(v->stopHelper()); settings.addView(stop,lp(-1,42));
        page.addView(settings,lp(-1,150));

        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.addView(page,lp(-1,-2));
        root.addView(scroll,flp(-1,-1));
        setContentView(root);
    }

    FrameLayout.LayoutParams flp(int w,int h){return new FrameLayout.LayoutParams(w,h);}

    void createWebView(){
        WebView web=new WebView(this); sharedWebView=web;
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setLoadsImagesAutomatically(true); s.setBlockNetworkImage(false); s.setBlockNetworkLoads(false); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setJavaScriptCanOpenWindowsAutomatically(true); s.setMediaPlaybackRequiresUserGesture(false); s.setCacheMode(WebSettings.LOAD_DEFAULT); s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE); s.setOffscreenPreRaster(false);
        web.setBackgroundColor(Color.WHITE); web.setVisibility(View.VISIBLE); web.setAlpha(0.01f);
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageStarted(WebView v,String u,android.graphics.Bitmap f){currentUrl=u;progress=0;lastError="";log("LOAD "+u);}
            @Override public void onPageFinished(WebView v,String u){currentUrl=u;pageTitle=v.getTitle()==null?"":v.getTitle();progress=100;log("FINISH "+u);}
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){lastError=e.getDescription()==null?"WebView error":e.getDescription().toString();log("ERROR "+lastError);}
        });
        web.setWebChromeClient(new WebChromeClient(){@Override public void onProgressChanged(WebView v,int p){progress=p;} @Override public boolean onConsoleMessage(ConsoleMessage m){log("JS "+m.message());return true;}});
        rootAddWebView(web);
        web.loadUrl(currentUrl);
    }
    void rootAddWebView(WebView web){
        // Keep the WebView attached for ZL2; WebViewService performs the actual off-screen capture.
        web.setTranslationX(-2000); web.setTranslationY(-2000);
        addContentView(web,flp(512,512));
    }
    void navigate(String u){if(u==null||u.isEmpty())return;if(!u.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*$"))u="https://"+u;currentUrl=u;if(sharedWebView!=null)sharedWebView.loadUrl(u);log("NAVIGATE "+u);}
    void startHelper(){try{Intent i=new Intent(this,WebViewService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);log("HELPER START requested");}catch(Throwable t){lastError="startService: "+t;log("ERROR "+lastError);}}
    void stopHelper(){try{stopService(new Intent(this,WebViewService.class));log("HELPER STOP requested");}catch(Throwable t){log("ERROR STOP "+t);}}
    void copyLogs(){android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("WebView Helper Log",snapshotLogs()));Toast.makeText(this,"日志已复制",Toast.LENGTH_SHORT).show();}
    void exportLogs(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,"webview-helper-v13.log");startActivityForResult(i,4001);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==4001&&c==RESULT_OK&&d!=null){try(java.io.OutputStream o=getContentResolver().openOutputStream(d.getData())){o.write(snapshotLogs().getBytes("UTF-8"));}catch(Exception e){log("EXPORT ERROR "+e);}}}
    void showAbout(){new AlertDialog.Builder(this).setTitle("WebView Helper V13").setMessage("Modern translucent blue × mint UI\nLow-latency capture profile\nLocal bridge: 127.0.0.1:28765").setPositiveButton("确定",null).show();}
    void scheduleRefresh(){ui.postDelayed(new Runnable(){public void run(){if(status!=null){boolean on=WebViewService.serverReady;status.setText(on?"● Helper 在线":"● 等待 Helper");status.setTextColor(on?MINT:BLUE);if(stats!=null)stats.setText(WebViewService.statusSummary());}ui.postDelayed(this,1000);}},400);}
}
