@echo off
set ROOT=%~dp0
where gradle >nul 2>nul
if %ERRORLEVEL%==0 (gradle %*) else (
  echo Portable Windows bootstrap requires Gradle or Code FA's Gradle environment.
  exit /b 2
)
