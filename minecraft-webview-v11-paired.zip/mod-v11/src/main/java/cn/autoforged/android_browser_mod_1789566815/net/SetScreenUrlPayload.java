package cn.autoforged.android_browser_mod_1789566815.net;

import cn.autoforged.android_browser_mod_1789566815.ExampleMod;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** 客户端 -> 服务端：把浏览器窗口里导航到的网址写到屏幕方块上。 */
public record SetScreenUrlPayload(BlockPos pos, String url) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<SetScreenUrlPayload> TYPE =
        new CustomPacketPayload.Type<>(ExampleMod.id("set_screen_url"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SetScreenUrlPayload> CODEC =
        StreamCodec.composite(
            BlockPos.STREAM_CODEC, SetScreenUrlPayload::pos,
            ByteBufCodecs.STRING_UTF8, SetScreenUrlPayload::url,
            SetScreenUrlPayload::new);

    @Override
    public CustomPacketPayload.Type<SetScreenUrlPayload> type() {
        return TYPE;
    }
}
