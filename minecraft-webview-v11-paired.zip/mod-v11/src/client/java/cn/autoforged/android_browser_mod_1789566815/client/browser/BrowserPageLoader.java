package cn.autoforged.android_browser_mod_1789566815.client.browser;

import cn.autoforged.android_browser_mod_1789566815.BrowserConfig;
import cn.autoforged.android_browser_mod_1789566815.ExampleMod;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.function.ToIntFunction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 浏览器页面加载器：后台线程抓取 URL，抽取纯文本，带内存缓存。
 *
 * <p>真正的网页渲染（JavaScript / CSS）交给 Android WebView 桥接；这里提供一个
 * 不依赖 Android 的纯文本回退引擎，保证任何平台都能"浏览"内容。
 */
public class BrowserPageLoader {
    private static final int MAX_CACHE_ENTRIES = 32;
    private static final int MAX_BODY_BYTES = 2 * 1024 * 1024;
    private static final int MAX_TEXT_CHARS = 200_000;

    private final BrowserConfig config;
    private final ExecutorService executor;
    private final Map<String, PageResult> cache;

    public BrowserPageLoader(BrowserConfig config) {
        this.config = config;
        this.executor = Executors.newSingleThreadExecutor(runnable -> {
            Thread thread = new Thread(runnable, "android-browser-fetch");
            thread.setDaemon(true);
            return thread;
        });
        this.cache = new LinkedHashMap<>(16, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, PageResult> eldest) {
                return size() > MAX_CACHE_ENTRIES;
            }
        };
    }

    public void load(String url, boolean allowCache, Consumer<PageResult> callback) {
        if (allowCache && config.cacheEnabled) {
            synchronized (cache) {
                PageResult cached = cache.get(url);
                if (cached != null) {
                    callback.accept(cached.asCached());
                    return;
                }
            }
        }
        executor.execute(() -> {
            PageResult result = fetch(url);
            if (result.error == null && config.cacheEnabled) {
                synchronized (cache) {
                    cache.put(url, result);
                }
            }
            callback.accept(result);
        });
    }

    public void shutdown() {
        executor.shutdownNow();
    }

    public void clearCache() {
        synchronized (cache) {
            cache.clear();
        }
    }

    private PageResult fetch(String url) {
        String current = url;
        // 手动跟随重定向以支持 http -> https 跨协议跳转
        for (int redirect = 0; redirect <= 5; redirect++) {
            HttpURLConnection connection = null;
            try {
                URL target = new URI(current).toURL();
                connection = (HttpURLConnection) target.openConnection();
                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(10_000);
                connection.setReadTimeout(15_000);
                connection.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 12) AndroidBrowserMod/1.0 Minecraft/26.2");
                connection.setRequestProperty("Accept",
                    "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.5");
                connection.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8");

                int code = connection.getResponseCode();
                if (code >= 300 && code < 400) {
                    String location = connection.getHeaderField("Location");
                    if (location != null && !location.isBlank()) {
                        connection.disconnect();
                        current = target.toURI().resolve(location).toURL().toString();
                        continue;
                    }
                }
                if (code >= 400) {
                    return PageResult.error(current, "HTTP " + code);
                }
                String contentType = connection.getContentType();
                byte[] bytes = readAll(connection.getInputStream());
                Charset charset = charsetFrom(contentType, bytes);
                String body = new String(bytes, charset);

                if (contentType == null || contentType.toLowerCase(Locale.ROOT).contains("html")) {
                    String text = htmlToText(body);
                    if (text.length() > MAX_TEXT_CHARS) {
                        text = text.substring(0, MAX_TEXT_CHARS) + "\n\n...（内容过长，已截断）";
                    }
                    return PageResult.ok(current, extractTitle(body), text, HtmlDocument.parseHtml(body));
                }
                return PageResult.ok(current, target.getHost(), body, HtmlDocument.plain(body));
            } catch (Exception e) {
                ExampleMod.LOGGER.debug("抓取页面失败 {}", current, e);
                String message = e.getMessage();
                return PageResult.error(current,
                    e.getClass().getSimpleName() + (message == null ? "" : ": " + message));
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }
        return PageResult.error(url, "重定向次数过多");
    }

    private static byte[] readAll(InputStream in) throws Exception {
        try (InputStream stream = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = stream.read(buffer)) != -1 && total < MAX_BODY_BYTES) {
                out.write(buffer, 0, read);
                total += read;
            }
            return out.toByteArray();
        }
    }

    private static Charset charsetFrom(String contentType, byte[] bytes) {
        if (contentType != null) {
            Matcher matcher = Pattern.compile("charset=([\\w\\-]+)", Pattern.CASE_INSENSITIVE).matcher(contentType);
            if (matcher.find()) {
                Charset charset = safeCharset(matcher.group(1));
                if (charset != null) {
                    return charset;
                }
            }
        }
        // BOM detection before guessing from HTML.
        if (bytes.length >= 3 && (bytes[0] & 0xFF) == 0xEF && (bytes[1] & 0xFF) == 0xBB && (bytes[2] & 0xFF) == 0xBF) {
            return StandardCharsets.UTF_8;
        }
        if (bytes.length >= 2 && (bytes[0] & 0xFF) == 0xFF && (bytes[1] & 0xFF) == 0xFE) {
            return StandardCharsets.UTF_16LE;
        }
        if (bytes.length >= 2 && (bytes[0] & 0xFF) == 0xFE && (bytes[1] & 0xFF) == 0xFF) {
            return StandardCharsets.UTF_16BE;
        }
        int probe = Math.min(bytes.length, 16384);
        String head = new String(bytes, 0, probe, StandardCharsets.ISO_8859_1).toLowerCase(Locale.ROOT);
        Matcher matcher = Pattern.compile("charset\\s*=\\s*[\"\\']?([\\w\\-]+)").matcher(head);
        if (matcher.find()) {
            Charset charset = safeCharset(matcher.group(1));
            if (charset != null) return charset;
        }
        return StandardCharsets.UTF_8;
    }

    private static Charset safeCharset(String name) {
        try {
            return Charset.forName(name);
        } catch (Exception e) {
            return null;
        }
    }

    // ---------------------------------------------------------------- HTML 处理

    private static final Pattern COMMENT = Pattern.compile("(?is)<!--.*?-->");
    private static final Pattern SCRIPT = Pattern.compile("(?is)<script[^>]*>.*?</script>");
    private static final Pattern STYLE = Pattern.compile("(?is)<style[^>]*>.*?</style>");
    private static final Pattern BR = Pattern.compile("(?i)<br\\s*/?>");
    private static final Pattern BLOCK = Pattern.compile(
        "(?i)</(p|div|li|tr|h[1-6]|section|article|header|footer|table|ul|ol|blockquote)[^>]*>");
    private static final Pattern TAG = Pattern.compile("(?s)<[^>]+>");
    private static final Pattern TITLE = Pattern.compile("(?is)<title[^>]*>(.*?)</title>");
    private static final Pattern NUMERIC_ENTITY = Pattern.compile("&#(x?)([0-9a-fA-F]+);");

    static String extractTitle(String html) {
        if (html == null) {
            return "";
        }
        Matcher matcher = TITLE.matcher(html);
        if (matcher.find()) {
            return decodeEntities(matcher.group(1).replaceAll("\\s+", " ")).trim();
        }
        return "";
    }

    static String htmlToText(String html) {
        if (html == null || html.isEmpty()) {
            return "";
        }
        String text = COMMENT.matcher(html).replaceAll(" ");
        text = SCRIPT.matcher(text).replaceAll(" ");
        text = STYLE.matcher(text).replaceAll(" ");
        text = BR.matcher(text).replaceAll("\n");
        text = BLOCK.matcher(text).replaceAll("\n");
        text = TAG.matcher(text).replaceAll(" ");
        text = decodeEntities(text);
        text = text.replace('\r', '\n');

        StringBuilder out = new StringBuilder();
        for (String rawLine : text.split("\n")) {
            String line = rawLine.replaceAll("[\\t\\x0B\\f ]+", " ").trim();
            if (line.isEmpty()) {
                if (out.length() > 0 && out.charAt(out.length() - 1) != '\n') {
                    out.append('\n');
                }
            } else {
                out.append(line).append('\n');
            }
        }
        return out.toString().trim();
    }

    static String decodeEntities(String input) {
        Matcher matcher = NUMERIC_ENTITY.matcher(input);
        StringBuffer buffer = new StringBuffer();
        while (matcher.find()) {
            String replacement = "";
            try {
                int codePoint = matcher.group(1).isEmpty()
                    ? Integer.parseInt(matcher.group(2))
                    : Integer.parseInt(matcher.group(2), 16);
                if (codePoint > 0 && codePoint <= 0x10FFFF) {
                    replacement = new String(Character.toChars(codePoint));
                }
            } catch (Exception ignored) {
                // 保留空字符串
            }
            matcher.appendReplacement(buffer, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(buffer);

        return buffer.toString()
            .replace("&nbsp;", " ")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
            .replace("&hellip;", "…")
            .replace("&mdash;", "—")
            .replace("&ndash;", "–")
            .replace("&middot;", "·")
            .replace("&copy;", "©")
            .replace("&reg;", "®")
            .replace("&trade;", "™")
            .replace("&amp;", "&");
    }

    /** 按像素宽度折行（CJK 友好，二分查找）。 */
    public static List<String> wrapText(String text, int maxWidth, ToIntFunction<String> widthFn) {
        List<String> lines = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return lines;
        }
        for (String paragraph : text.split("\n", -1)) {
            if (paragraph.isEmpty()) {
                lines.add("");
                continue;
            }
            String remaining = paragraph;
            while (!remaining.isEmpty()) {
                int fit = fitWidth(remaining, maxWidth, widthFn);
                if (fit <= 0) {
                    fit = 1;
                }
                if (fit >= remaining.length()) {
                    lines.add(remaining);
                    break;
                }
                lines.add(remaining.substring(0, fit));
                remaining = remaining.substring(fit);
                int skip = 0;
                while (skip < remaining.length() && remaining.charAt(skip) == ' ') {
                    skip++;
                }
                remaining = remaining.substring(skip);
            }
        }
        return lines;
    }

    private static int fitWidth(String text, int maxWidth, ToIntFunction<String> widthFn) {
        int low = 1;
        int high = text.length();
        int best = 1;
        while (low <= high) {
            int mid = (low + high) >>> 1;
            if (widthFn.applyAsInt(text.substring(0, mid)) <= maxWidth) {
                best = mid;
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return best;
    }

    /** 抓取结果。 */
    public static final class PageResult {
        public final String url;
        public final String title;
        public final String text;
        public final String error;
        public final boolean fromCache;
        /** 带样式的网页模型（解析失败时退化为纯文本）。 */
        public final HtmlDocument document;

        private PageResult(String url, String title, String text, String error, boolean fromCache,
                           HtmlDocument document) {
            this.url = url;
            this.title = title;
            this.text = text;
            this.error = error;
            this.fromCache = fromCache;
            this.document = document;
        }

        static PageResult ok(String url, String title, String text, HtmlDocument document) {
            return new PageResult(url, title == null ? "" : title, text == null ? "" : text, null, false,
                document == null ? HtmlDocument.plain(text) : document);
        }

        static PageResult error(String url, String error) {
            return new PageResult(url, "", "", error, false, HtmlDocument.plain(""));
        }

        PageResult asCached() {
            return new PageResult(url, title, text, error, true, document);
        }
    }
}
