#!/usr/bin/env bash
set -e
chmod +x ./gradlew
./gradlew clean assembleDebug --stacktrace
printf '\nAPK files:\n'
find app/build/outputs/apk -type f -name '*.apk' -print
