Offline diagnostic suite. Open file:///android_asset/diagnostic/index.html.
Checks HTML, CSS, JavaScript execution, local image loading, video element/media support, DOM state and runtime information.
