package cn.autoforged.android_browser_mod_1789566815.client.render;

import cn.autoforged.android_browser_mod_1789566815.ExampleMod;
import cn.autoforged.android_browser_mod_1789566815.block.ScreenBlock;
import cn.autoforged.android_browser_mod_1789566815.block.ScreenBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * V8 screen renderer: an opaque white-board base with an optional WebView texture
 * continuously UV-sliced across a connected wall. Never renders transparent glass.
 */
@Environment(EnvType.CLIENT)
public class ScreenBlockRenderer implements BlockEntityRenderer<ScreenBlockEntity, ScreenBlockRenderState> {
    // Slightly in front of the block face. The underlying block model has no front face, so there
    // is no transparent layer behind this quad.
    private static final float FACE_Z = 0.5015F;
    // Tiny overlap hides precision/raster cracks without visibly stretching the texture.
    private static final float SEAM_OVERLAP = 0.0015F;
    private static final float UV_EPS = 0.00025F;

    public ScreenBlockRenderer(BlockEntityRendererProvider.Context context) {}

    @Override public ScreenBlockRenderState createRenderState() { return new ScreenBlockRenderState(); }

    @Override
    public void extractRenderState(ScreenBlockEntity blockEntity, ScreenBlockRenderState state,
                                   float partialTicks, Vec3 cameraPosition,
                                   ModelFeatureRenderer.@Nullable CrumblingOverlay breakProgress) {
        BlockEntityRenderer.super.extractRenderState(blockEntity, state, partialTicks, cameraPosition, breakProgress);
        BlockState bs = blockEntity.getBlockState();
        state.facing = bs.hasProperty(ScreenBlock.FACING) ? bs.getValue(ScreenBlock.FACING) : Direction.NORTH;
        ScreenWallLayout wall = ScreenWallLayout.find(blockEntity);
        state.tileU = wall.tileU; state.tileV = wall.tileV;
        state.wallWidth = wall.width(); state.wallHeight = wall.height();
        state.url = blockEntity.getUrl();
        state.hint = "";
    }

    @Override
    public void submit(ScreenBlockRenderState state, PoseStack poseStack,
                       SubmitNodeCollector collector, CameraRenderState camera) {
        if (!state.url.isBlank() && !state.url.equals(WebViewTextureBridge.url())) {
            WebViewTextureBridge.load(state.url);
        }
        // The block model supplies a solid white front board. If WebView is unavailable,
        // deliberately stop here instead of falling back to the legacy text/LF renderer.
        if (!WebViewTextureBridge.ready()) return;

        final boolean loading = !WebViewTextureBridge.pageReady();
        final int tileU = state.tileU, tileV = state.tileV;
        final int wallW = Math.max(1, state.wallWidth), wallH = Math.max(1, state.wallHeight);
        final int light = state.lightCoords;
        final Direction facing = state.facing;

        // The entire wall is one logical 1:wallW by 1:wallH image. A block only samples its tile.
        float u0 = (float) tileU / wallW;
        float u1 = (float) (tileU + 1) / wallW;
        float v0 = (float) tileV / wallH;
        float v1 = (float) (tileV + 1) / wallH;
        // Do not clamp across the neighboring tile. The geometry overlap is enough to cover the
        // raster crack while the UVs remain continuous at exact tile boundaries.
        u0 = Math.max(0.0F, u0 - (tileU == 0 ? 0 : UV_EPS));
        u1 = Math.min(1.0F, u1 + (tileU == wallW - 1 ? 0 : UV_EPS));
        v0 = Math.max(0.0F, v0 - (tileV == 0 ? 0 : UV_EPS));
        v1 = Math.min(1.0F, v1 + (tileV == wallH - 1 ? 0 : UV_EPS));

        // Java lambda capture: these values must be final/effectively final.
        final float fu0 = u0;
        final float fu1 = u1;
        final float fv0 = v0;
        final float fv1 = v1;

        poseStack.pushPose();
        poseStack.translate(0.5F, 0.5F, 0.5F);
        poseStack.mulPose(Axis.YP.rotationDegrees(-facing.toYRot()));
        poseStack.translate(0.0F, 0.0F, FACE_Z);

        // entitySolid is intentionally used here: the screen face is an opaque textured panel,
        // never a transparent glass pane. The texture alpha is also forced to 255 on upload.
        RenderType renderType = RenderTypes.entitySolid(WebViewTextureBridge.textureId());
        collector.submitCustomGeometry(poseStack, renderType, (pose, buffer) -> {
            float x0 = -0.5F - SEAM_OVERLAP, x1 = 0.5F + SEAM_OVERLAP;
            float y0 = -0.5F - SEAM_OVERLAP, y1 = 0.5F + SEAM_OVERLAP;
            int color = 0xFFFFFFFF;
            buffer.addVertex(pose, x0, y0, 0).setColor(color).setUv(fu0, fv1).setOverlay(0).setLight(light).setNormal(pose, 0, 0, 1);
            buffer.addVertex(pose, x1, y0, 0).setColor(color).setUv(fu1, fv1).setOverlay(0).setLight(light).setNormal(pose, 0, 0, 1);
            buffer.addVertex(pose, x1, y1, 0).setColor(color).setUv(fu1, fv0).setOverlay(0).setLight(light).setNormal(pose, 0, 0, 1);
            buffer.addVertex(pose, x0, y1, 0).setColor(color).setUv(fu0, fv0).setOverlay(0).setLight(light).setNormal(pose, 0, 0, 1);
        });

        if (loading) {
            // Loading animation: the panel remains fully opaque white, while a small neutral
            // progress bar grows and pulses. No alpha is used, so the world can never show through.
            final float progress = 0.12F + 0.78F * (0.5F + 0.5F *
                (float) Math.sin((System.nanoTime() % 2_000_000_000L) / 2_000_000_000.0 * Math.PI * 2.0));
            collector.submitCustomGeometry(poseStack, renderType, (pose, buffer) -> {
                float bx0 = -0.36F;
                float bx1 = bx0 + 0.72F * progress;
                float by0 = -0.035F;
                float by1 = 0.035F;
                int barColor = 0xFFD0D0D0;
                buffer.addVertex(pose, bx0, by0, -0.001F).setColor(barColor).setUv(0, 0).setOverlay(0).setLight(light).setNormal(pose, 0, 0, 1);
                buffer.addVertex(pose, bx1, by0, -0.001F).setColor(barColor).setUv(1, 0).setOverlay(0).setLight(light).setNormal(pose, 0, 0, 1);
                buffer.addVertex(pose, bx1, by1, -0.001F).setColor(barColor).setUv(1, 1).setOverlay(0).setLight(light).setNormal(pose, 0, 0, 1);
                buffer.addVertex(pose, bx0, by1, -0.001F).setColor(barColor).setUv(0, 1).setOverlay(0).setLight(light).setNormal(pose, 0, 0, 1);
            });
        }
        poseStack.popPose();
    }
}
