package cn.autoforged.android_browser_mod_1789566815;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BiConsumer;

/**
 * V8 debug WebView -> Minecraft frame bridge (ZL2 multi-process / ZL2ac fix).
 *
 * <p>The Android WebView is a real attached Android View. It is created on the Android UI thread,
 * attached to the foreground Activity, laid out at the exact capture size, and periodically drawn
 * into an ARGB_8888 bitmap. Only immutable pixel arrays cross into Minecraft. This deliberately
 * avoids doing Android UI work from the Blaze3D/Vulkan render path.
 *
 * <p>V8 adds (ZL2ac fix):
 * <ul>
 *   <li><b>ZL2 multi-process Activity resolution</b> — ZL2 v2 runs the game JVM in the
 *       ":game" / ":jvm" process, so the main-process MainActivity is unreachable from the
 *       mod. V8 probes VMActivity (the ":game" Activity hosting the Minecraft surface) first
 *       and falls back to the Application context rather than disabling the browser.</li>
 *   <li>Input event forwarding — MotionEvent (touch) and KeyEvent (keyboard) are constructed via
 *       reflection and dispatched to the WebView on the Android UI thread.</li>
 *   <li>Media/audio settings — mediaPlaybackRequiresUserGesture is disabled, additional audio
 *       settings are applied.</li>
 *   <li>Volume control — the AudioManager stream volume can be adjusted from the game.</li>
 * </ul>
 */
public final class AndroidWebViewBridge {
    private static Method webViewPostDelayed;
    private static Object webView;
    private static Runnable captureTask;
    private static final AtomicBoolean running = new AtomicBoolean(false);
    private static volatile String currentUrl = "";
    private static volatile int width = 1024;
    private static volatile int height = 1024;
    private static volatile BiConsumer<int[], int[]> frameSink;
    private static volatile long captureCount;
    private static volatile long lastCaptureNanos;
    private static volatile String lastError = "";
    private static volatile boolean attached;
    private static volatile boolean pageReady;
    /**
     * True when the WebView runs on the Application context because no Activity was
     * reachable. This is the normal situation on ZL2 v2, where the game JVM lives in the
     * ":game" / ":jvm" process and cannot see the main-process MainActivity.
     */
    private static volatile boolean degraded;
    private static final String[] debugLog = new String[80];
    private static int debugLogCount = 0;
    private static synchronized void debug(String message) {
        if (message == null) return;
        int n = Math.min(debugLogCount, debugLog.length - 1);
        if (n > 0) System.arraycopy(debugLog, 0, debugLog, 1, n);
        debugLog[0] = message;
        debugLogCount = Math.min(debugLogCount + 1, debugLog.length);
    }
    public static synchronized String[] debugLogSnapshot() {
        String[] out = new String[debugLogCount];
        for (int i = 0; i < debugLogCount; i++) out[i] = debugLog[i];
        return out;
    }
    public static String debugSummary() {
        if (LocalWebViewHelperBridge.online()) return LocalWebViewHelperBridge.debugSummary();
        if (!AndroidBrowserBridge.isAndroidRuntime() || !AndroidBrowserBridge.contextDiagnostics().contains("mode=")) {
            return LocalWebViewHelperBridge.debugSummary();
        }
        String activity = "null";
        String view = "null";
        try {
            Object a = AndroidBrowserBridge.currentActivity();
            if (a != null) activity = a.getClass().getName();
            if (webView != null) view = webView.getClass().getName();
        } catch (Throwable t) { activity = "error:" + t; }
        return "process=" + AndroidBrowserBridge.processName()
            + " | mode=" + (degraded ? "APPLICATION(degraded)" : "ACTIVITY")
            + " | Activity=" + activity + " | WebView=" + view
            + " | attached=" + attached + " | ready=" + pageReady
            + " | running=" + running.get() + " | frames=" + captureCount
            + " | url=" + currentUrl
            + " | lastError=" + (lastError == null || lastError.isEmpty() ? "none" : lastError);
    }

    private AndroidWebViewBridge() {}

    public static boolean isAndroidRuntime() {
        return AndroidBrowserBridge.isAndroidRuntime();
    }

    public static boolean available() {
        if (LocalWebViewHelperBridge.available()) {
            degraded = true;
            debug("OK Local WebView Helper detected on 127.0.0.1:" + 28765);
            return true;
        }
        // Do NOT rely on java.vm.name / os.name or launcher environment variables.
        // In ZL2/Pojav the Minecraft JVM can look like a normal desktop JVM even though
        // it is running inside the Android application process.
        //
        // === ZL2ac fix (V8) ==========================================================
        // ZL2 v2 is a MULTI-PROCESS launcher. Its game JVM runs in ":game" or ":jvm",
        // so the main-process MainActivity is unreachable from the mod and
        // currentActivity() correctly returns null even though we ARE on Android.
        // V6/V7 treated that as fatal and disabled the WebView entirely — that was the
        // ZL2ac bug. Now: fall back to the Application context, which
        // ActivityThread.currentApplication() exposes in EVERY process of the app.
        // A WebView on the Application context still renders pages and runs JS; only
        // Activity-bound features (file pickers, JS dialogs) degrade.
        // ============================================================================
        try {
            Object activity = AndroidBrowserBridge.currentActivity();
            Object context = activity != null ? activity : AndroidBrowserBridge.applicationContext();
            if (context == null) {
                debug("ERROR no Android Context (no Activity and no Application); WebView disabled");
                ExampleMod.LOGGER.warn("[WebView-V8] no Android Context; WebView disabled | {}",
                    AndroidBrowserBridge.contextDiagnostics());
                return false;
            }
            Class<?> webViewClass = Class.forName("android.webkit.WebView");
            if (webViewClass == null) {
                ExampleMod.LOGGER.warn("[WebView-V8] android.webkit.WebView class unavailable");
                return false;
            }
            degraded = (activity == null);
            if (degraded) {
                debug("WARN Activity unreachable; Application context (degraded mode)");
                ExampleMod.LOGGER.warn("[WebView-V8] Activity unreachable in process '{}' -> Application context (degraded)",
                    AndroidBrowserBridge.processName());
            } else {
                debug("OK WebView capability detected; Activity=" + activity.getClass().getName());
            }
            ExampleMod.LOGGER.info("[WebView-V8] capability OK mode={} | {}",
                degraded ? "APPLICATION(degraded)" : "ACTIVITY",
                AndroidBrowserBridge.contextDiagnostics());
            return true;
        } catch (Throwable t) {
            lastError = "availability: " + t;
            debug("ERROR availability: " + t);
            ExampleMod.LOGGER.warn("[WebView-V8] capability detection failed: {}", t.toString());
            return false;
        }
    }

    /** True when running degraded on the Application context (no Activity reachable). */
    public static boolean isDegraded() { return degraded; }

    public static void start(int w, int h, BiConsumer<int[], int[]> sink) {
        if (LocalWebViewHelperBridge.available()) {
            width = clampSize(w);
            height = clampSize(h);
            frameSink = sink;
            running.set(true);
            attached = true;
            LocalWebViewHelperBridge.start(width, height, (pixels, size) -> {
                captureCount++;
                pageReady = LocalWebViewHelperBridge.pageReady();
                BiConsumer<int[], int[]> s = frameSink;
                if (s != null) s.accept(pixels, size);
            });
            debug("HELPER STARTED");
            return;
        }
        if (!available() || sink == null) return;
        width = clampSize(w);
        height = clampSize(h);
        frameSink = sink;
        runUi(AndroidWebViewBridge::createIfNeeded);
    }

    public static void loadUrl(String url) {
        if (url == null || url.isBlank()) return;
        if (LocalWebViewHelperBridge.online()) {
            currentUrl = url;
            pageReady = false;
            LocalWebViewHelperBridge.loadUrl(url);
            debug("HELPER LOAD " + url);
            return;
        }
        currentUrl = url;
        runUi(() -> {
            try {
                if (webView == null) createIfNeeded();
                if (webView == null) return;
                // Force a fresh layout before navigation so the first Chromium frame has a valid size.
                invoke(webView, "requestLayout");
                invoke(webView, "invalidate");
                pageReady = false;
                invoke(webView, "loadUrl", url);
                debug("LOAD " + url);
                ExampleMod.LOGGER.info("[WebView-V8] loadUrl {}", url);
                // Give Chromium time to produce a real frame before the Minecraft texture is
                // considered ready. The capture loop continues during this warm-up.
                postOnWebView(900L, () -> {
                    pageReady = true;
                    debug("READY initial page warm-up complete");
                    ExampleMod.LOGGER.info("[WebView-V8] initial page warm-up complete");
                });
            } catch (Throwable t) {
                lastError = "loadUrl: " + t;
                debug("ERROR loadUrl: " + t);
                ExampleMod.LOGGER.warn("[WebView-V8] loadUrl failed: {}", t.toString());
            }
        });
    }

    public static String currentUrl() { return currentUrl; }
    public static long captureCount() { return captureCount; }
    public static boolean attached() { return attached; }
    public static boolean pageReady() { return pageReady; }
    public static String lastError() { return lastError; }

    // =================================================================
    // Phase 4: Input event forwarding (MotionEvent / KeyEvent)
    // =================================================================

    /** WebView capture width, for coordinate mapping. */
    public static int viewWidth() { return width; }
    /** WebView capture height, for coordinate mapping. */
    public static int viewHeight() { return height; }

    private static volatile long touchDownTime;
    private static volatile boolean touchPressed;

    /**
     * Forwards a touch/mouse event to the WebView.
     *
     * @param action  0=DOWN, 1=UP, 2=MOVE, 3=CANCEL (android.view.MotionEvent constants)
     * @param x       X in WebView viewport coordinates (0..width)
     * @param y       Y in WebView viewport coordinates (0..height)
     */
    public static void forwardTouch(int action, float x, float y) {
        if (LocalWebViewHelperBridge.online()) { LocalWebViewHelperBridge.forwardTouch(action, x, y); return; }
        if (webView == null || !running.get()) return;
        runUi(() -> {
            try {
                Class<?> motionEventClass = Class.forName("android.view.MotionEvent");
                long now = systemUptimeMillis();
                if (action == 0) { // ACTION_DOWN
                    touchDownTime = now;
                    touchPressed = true;
                }
                Method obtain = motionEventClass.getMethod("obtain",
                    long.class, long.class, int.class, float.class, float.class, int.class);
                Object event = obtain.invoke(null, touchDownTime, now, action, x, y, 0);
                if (event == null) return;
                try {
                    Method dispatch = webView.getClass().getMethod("dispatchTouchEvent", motionEventClass);
                    Boolean result = (Boolean) dispatch.invoke(webView, event);
                    if ((action == 1 || action == 3) && touchPressed) {
                        touchPressed = false;
                    }
                    debug("TOUCH action=" + action + " x=" + x + " y=" + y + " result=" + result);
                } finally {
                    Method recycle = motionEventClass.getMethod("recycle");
                    recycle.invoke(event);
                }
            } catch (Throwable t) {
                lastError = "touch: " + t;
                debug("ERROR touch: " + t);
                ExampleMod.LOGGER.warn("[WebView-V8] touch dispatch failed: {}", t.toString());
            }
        });
    }

    /**
     * Forwards a keyboard event to the WebView.
     *
     * @param action  0=ACTION_DOWN, 1=ACTION_UP (android.view.KeyEvent constants)
     * @param keyCode Android keyCode (e.g. KeyEvent.KEYCODE_A=29)
     * @param repeat  repeat count (0 for first press)
     * @param chars   character sequence for typing, null if none
     */
    public static void forwardKey(int action, int keyCode, int repeat, String chars) {
        if (LocalWebViewHelperBridge.online()) { LocalWebViewHelperBridge.forwardKey(action, keyCode, repeat, chars); return; }
        if (webView == null || !running.get()) return;
        // If only character text is provided (no real keyCode), skip KeyEvent dispatch
        // and go straight to text commit. This handles typed characters from charTyped.
        if (keyCode == 0 && chars != null && !chars.isEmpty()) {
            runUi(() -> tryCommitText(chars));
            return;
        }
        runUi(() -> {
            try {
                Class<?> keyEventClass = Class.forName("android.view.KeyEvent");
                long now = systemUptimeMillis();
                // KeyEvent.obtain(downTime, eventTime, action, code, repeat, metaState, deviceId, flags)
                // Try the 6-arg overload first, then the 7-arg one.
                Object event = null;
                try {
                    Method obtain = keyEventClass.getMethod("obtain",
                        long.class, long.class, int.class, int.class, int.class, int.class);
                    event = obtain.invoke(null, now, now, action, keyCode, repeat, 0);
                } catch (NoSuchMethodException ignored) {}
                if (event == null) {
                    try {
                        Method obtain = keyEventClass.getMethod("obtain",
                            long.class, long.class, int.class, int.class, int.class, int.class, int.class, int.class);
                        event = obtain.invoke(null, now, now, action, keyCode, repeat, 0, 0, 0);
                    } catch (NoSuchMethodException ignored) {}
                }
                if (event == null) {
                    // Fallback: use the constructor directly.
                    try {
                        Constructor<?> ctor = keyEventClass.getConstructor(
                            long.class, long.class, int.class, int.class, int.class);
                        event = ctor.newInstance(now, now, action, keyCode, repeat);
                    } catch (NoSuchMethodException ignored) {}
                }
                if (event == null) {
                    debug("ERROR key: no obtain/constructor found");
                    return;
                }
                try {
                    Method dispatch = webView.getClass().getMethod("dispatchKeyEvent", keyEventClass);
                    Boolean result = (Boolean) dispatch.invoke(webView, event);
                    debug("KEY action=" + action + " code=" + keyCode + " result=" + result);
                } finally {
                    Method recycle = keyEventClass.getMethod("recycle");
                    recycle.invoke(event);
                }
                // Also try to commit text for character input via the WebView's onCreateInputConnection.
                if (chars != null && !chars.isEmpty() && action == 0) {
                    tryCommitText(chars);
                }
            } catch (Throwable t) {
                lastError = "key: " + t;
                debug("ERROR key: " + t);
                ExampleMod.LOGGER.warn("[WebView-V8] key dispatch failed: {}", t.toString());
            }
        });
    }

    /**
     * Attempts to commit text through the WebView's input connection (for typing in form fields).
     */
    private static void tryCommitText(String text) {
        try {
            // WebView.onCreateInputConnection returns an InputConnection.
            Class<?> editorInfoClass = Class.forName("android.view.inputmethod.EditorInfo");
            Object editorInfo = editorInfoClass.getConstructor().newInstance();
            Method createConn = webView.getClass().getMethod("onCreateInputConnection", editorInfoClass);
            Object conn = createConn.invoke(webView, editorInfo);
            if (conn == null) return;
            // InputConnection.commitText(text, newCursorPos)
            Class<?> inputConnClass = Class.forName("android.view.inputmethod.InputConnection");
            Method commit = inputConnClass.getMethod("commitText",
                CharSequence.class, int.class);
            commit.invoke(conn, text, 1);
            // The InputConnection is not needed after commit; the WebView owns it.
            debug("TEXT commit: " + text);
        } catch (Throwable ignored) {
            // Not all WebView builds support this; silent fallback.
        }
    }

    /**
     * Simulates a scroll event on the WebView by forwarding ACTION_MOVE with a vertical delta.
     */
    public static void forwardScroll(float deltaX, float deltaY) {
        if (LocalWebViewHelperBridge.online()) { LocalWebViewHelperBridge.forwardScroll(deltaX, deltaY); return; }
        if (webView == null || !running.get()) return;
        runUi(() -> {
            try {
                // Use WebView.scrollBy for actual scrolling instead of touch simulation.
                invoke(webView, "scrollBy", (int) deltaX, (int) deltaY);
                debug("SCROLL dx=" + deltaX + " dy=" + deltaY);
            } catch (Throwable t) {
                lastError = "scroll: " + t;
                debug("ERROR scroll: " + t);
            }
        });
    }

    // =================================================================
    // Phase 7: Audio / video support
    // =================================================================

    private static volatile boolean muted;

    /** Returns true if audio has been muted. */
    public static boolean isMuted() { return muted; }

    /**
     * Mutes or unmutes the WebView audio. When muted, the AudioManager stream volume is set to 0;
     * when unmuted, it is restored to the previous volume.
     */
    public static void setMuted(boolean mute) {
        muted = mute;
        if (LocalWebViewHelperBridge.online()) { LocalWebViewHelperBridge.setMuted(mute); return; }
        runUi(() -> {
            try {
                // ZL2ac: AudioManager is a system service, so the Application context works
                // just as well as an Activity. Use bestContext() so mute still works when we
                // are running degraded on the ":game"/":jvm" process.
                Object context = AndroidBrowserBridge.bestContext();
                if (context == null) return;
                // AudioManager.STREAM_MUSIC = 3
                Class<?> contextClass = Class.forName("android.content.Context");
                Object audioService = contextClass
                    .getMethod("getSystemService", String.class)
                    .invoke(context, "audio");
                if (audioService == null) return;
                Class<?> audioManagerClass = Class.forName("android.media.AudioManager");
                Method getStreamMax = audioManagerClass.getMethod("getStreamMaxVolume", int.class);
                int maxVol = (Integer) getStreamMax.invoke(audioService, 3);
                int targetVol = mute ? 0 : maxVol;
                audioManagerClass.getMethod("setStreamVolume", int.class, int.class, int.class)
                    .invoke(audioService, 3, targetVol, 0);
                debug("AUDIO muted=" + mute + " vol=" + targetVol + "/" + maxVol);
                ExampleMod.LOGGER.info("[WebView-V8] audio muted={} vol={}/{}", mute, targetVol, maxVol);
            } catch (Throwable t) {
                lastError = "audio: " + t;
                debug("ERROR audio: " + t);
                ExampleMod.LOGGER.warn("[WebView-V8] audio control failed: {}", t.toString());
            }
        });
    }

    /** Toggles mute state. */
    public static void toggleMute() {
        setMuted(!muted);
    }

    private static long systemUptimeMillis() {
        try {
            Class<?> systemClock = Class.forName("android.os.SystemClock");
            Method uptime = systemClock.getMethod("uptimeMillis");
            return (Long) uptime.invoke(null);
        } catch (Throwable ignored) {
            return System.currentTimeMillis();
        }
    }

    public static void stop() {
        LocalWebViewHelperBridge.stop();
        running.set(false);
        runUi(() -> {
            try {
                if (webView != null && captureTask != null) {
                    invoke(webView, "removeCallbacks", captureTask);
                }
            } catch (Throwable ignored) {}
            try {
                if (webView != null) {
                    Object p = invoke(webView, "getParent");
                    if (p != null) invoke(p, "removeView", webView);
                }
            } catch (Throwable ignored) {}
            try { if (webView != null) invoke(webView, "stopLoading"); } catch (Throwable ignored) {}
            try { if (webView != null) invoke(webView, "destroy"); } catch (Throwable ignored) {}
            webView = null;
            attached = false;
            pageReady = false;
            webViewPostDelayed = null;
        });
    }

    private static void createIfNeeded() {
        if (webView != null || !running.compareAndSet(false, true)) return;
        try {
            // IMPORTANT: never load android.os.Handler/Looper here. Zalith/Pojav's Android
            // launcher classloader may not expose those classes to the game classloader.
            // createIfNeeded() is already called through Activity.runOnUiThread().
            //
            // Use the Activity context, not only ApplicationContext. WebView is a window-backed UI
            // component and Android's rendering guarantees are tied to an attached view hierarchy.
            // ZL2ac: prefer an in-process Activity (VMActivity when running in ":game"),
            // but accept the Application context when the game JVM lives in a process that
            // has no Activity at all (":jvm", or ":game" before VMActivity is created).
            Object activity = AndroidBrowserBridge.currentActivity();
            Object context = AndroidBrowserBridge.bestContext();
            if (context == null) throw new IllegalStateException("Android Activity/Context unavailable");
            ExampleMod.LOGGER.info("[WebView-V8] creating WebView on {} context ({})",
                activity != null ? "Activity" : "Application(degraded)", context.getClass().getName());

            Class<?> webViewClass = Class.forName("android.webkit.WebView");
            webView = webViewClass.getConstructor(Class.forName("android.content.Context")).newInstance(context);

            Object settings = invoke(webView, "getSettings");
            invoke(settings, "setJavaScriptEnabled", true);
            invoke(settings, "setDomStorageEnabled", true);
            try { invoke(settings, "setDatabaseEnabled", true); } catch (Throwable ignored) {}
            try { invoke(settings, "setUseWideViewPort", true); } catch (Throwable ignored) {}
            try { invoke(settings, "setLoadWithOverviewMode", false); } catch (Throwable ignored) {}
            try { invoke(settings, "setDefaultTextEncodingName", "UTF-8"); } catch (Throwable ignored) {}
            try { invoke(settings, "setMediaPlaybackRequiresUserGesture", false); } catch (Throwable ignored) {}
            // Phase 7: Enable HTML5 media features for video/audio playback.
            try { invoke(settings, "setDomStorageEnabled", true); } catch (Throwable ignored) {}
            try { invoke(settings, "setDatabaseEnabled", true); } catch (Throwable ignored) {}
            try { invoke(settings, "setAppCacheEnabled", true); } catch (Throwable ignored) {}
            // Derive the cache path from the Context instead of hard-coding a package name:
            // the mod runs in the LAUNCHER's process/package (com.movtery.zalithlauncher on
            // ZL2), so a fixed "/data/data/cn.autoforged/..." path would be unwritable.
            try {
                Object cacheDir = context.getClass().getMethod("getCacheDir").invoke(context);
                if (cacheDir != null) {
                    String cachePath = String.valueOf(cacheDir.getClass().getMethod("getAbsolutePath").invoke(cacheDir))
                        + "/webview";
                    invoke(settings, "setAppCachePath", cachePath);
                }
            } catch (Throwable ignored) {}
            try { invoke(settings, "setAllowFileAccess", true); } catch (Throwable ignored) {}
            try { invoke(settings, "setAllowContentAccess", true); } catch (Throwable ignored) {}
            // Enable hardware acceleration for video decoding.
            try { invoke(settings, "setPluginState", 1); } catch (Throwable ignored) {} // PLUGIN_ON
            try { invoke(settings, "setBuiltInZoomControls", false); } catch (Throwable ignored) {}
            try { invoke(settings, "setDisplayZoomControls", false); } catch (Throwable ignored) {}
            try { invoke(settings, "setSupportZoom", false); } catch (Throwable ignored) {}
            try { invoke(settings, "setTextZoom", 100); } catch (Throwable ignored) {}

            Class<?> client = Class.forName("android.webkit.WebViewClient");
            invoke(webView, "setWebViewClient", client.getConstructor().newInstance());
            try { invoke(webView, "setBackgroundColor", 0xFFFFFFFF); } catch (Throwable ignored) {}
            try { invoke(webView, "setScrollBarStyle", 0); } catch (Throwable ignored) {}
            try { invoke(webView, "setOverScrollMode", 2); } catch (Throwable ignored) {}
            try { invoke(webView, "setFocusable", true); } catch (Throwable ignored) {}
            try { invoke(webView, "setFocusableInTouchMode", true); } catch (Throwable ignored) {}
            try { invoke(webView, "setLayerType", 1, null); } catch (Throwable ignored) {} // software layer: makes View.draw(Canvas) deterministic for bitmap capture

            attached = attachToCurrentActivity(webView, width, height);
            invoke(webView, "setVisibility", 0); // VISIBLE; required for reliable WebView drawing.
            invoke(webView, "measure", measureSpec(width), measureSpec(height));
            invoke(webView, "layout", 0, 0, width, height);
            invoke(webView, "requestLayout");
            invoke(webView, "invalidate");

            captureTask = AndroidWebViewBridge::capture;
            webViewPostDelayed = webView.getClass().getMethod("postDelayed", Runnable.class, long.class);
            webViewPostDelayed.invoke(webView, captureTask, 350L);
            debug("CREATED " + width + "x" + height + " attached=" + attached);
            ExampleMod.LOGGER.info("[WebView-V8] created size={}x{} attached={} activityContext={}",
                width, height, attached, activity != null);
        } catch (Throwable t) {
            running.set(false);
            lastError = "create: " + t;
            debug("ERROR create: " + t);
            ExampleMod.LOGGER.warn("[WebView-V8] initialization failed: {}", t.toString());
        }
    }

    private static void capture() {
        if (!running.get() || webView == null) return;
        try {
            // Re-assert a real layout every frame. This is intentional debug hardening: some
            // launcher/window transitions can temporarily give WebView a zero-sized layout.
            invoke(webView, "measure", measureSpec(width), measureSpec(height));
            invoke(webView, "layout", 0, 0, width, height);
            invoke(webView, "invalidate");

            Class<?> bitmap = Class.forName("android.graphics.Bitmap");
            Object cfg = bitmap.getField("ARGB_8888").get(null);
            Object image = bitmap.getMethod("createBitmap", int.class, int.class,
                    Class.forName("android.graphics.Bitmap$Config")).invoke(null, width, height, cfg);
            Object canvas = Class.forName("android.graphics.Canvas").getConstructor(bitmap).newInstance(image);

            // draw() is public and drives the View's onDraw() implementation. Keep this call on
            // the Android UI thread, exactly where the WebView was created.
            invoke(webView, "draw", canvas);

            int[] pixels = new int[width * height];
            bitmap.getMethod("getPixels", int[].class, int.class, int.class, int.class, int.class, int.class, int.class)
                .invoke(image, pixels, 0, width, 0, 0, width, height);

            BiConsumer<int[], int[]> sink = frameSink;
            if (sink != null) sink.accept(pixels, new int[]{width, height});
            captureCount++;
            lastCaptureNanos = System.nanoTime();
            if ((captureCount & 15) == 1) {
                int center = pixels[(height / 2) * width + (width / 2)];
                ExampleMod.LOGGER.info("[WebView-V8] frame #{} center=0x{} attached={} ready={} url={}",
                    captureCount, Integer.toHexString(center), attached, pageReady, currentUrl);
            }
            try { invoke(image, "recycle"); } catch (Throwable ignored) {}
        } catch (Throwable t) {
            lastError = "capture: " + t;
            debug("ERROR capture: " + t);
            ExampleMod.LOGGER.warn("[WebView-V8] frame capture failed: {}", t.toString());
        }
        postOnWebView(100L, captureTask);
    }

    private static boolean attachToCurrentActivity(Object view, int w, int h) throws Exception {
        Object activity = AndroidBrowserBridge.currentActivity();
        if (activity == null) return false;
        Object window = activity.getClass().getMethod("getWindow").invoke(activity);
        Object decor = window.getClass().getMethod("getDecorView").invoke(window);
        Class<?> viewGroup = Class.forName("android.view.ViewGroup");
        if (!viewGroup.isInstance(decor)) return false;
        Class<?> lp = Class.forName("android.view.ViewGroup$LayoutParams");
        Object params = lp.getConstructor(int.class, int.class).newInstance(Math.max(1, w), Math.max(1, h));
        try { invoke(view, "setX", -w - 32f); } catch (Throwable ignored) {}
        try { invoke(view, "setY", -h - 32f); } catch (Throwable ignored) {}
        // Do NOT set alpha to 0.0: the View must remain visibly drawable for the first frame.
        // A tiny alpha is also avoided because draw(Canvas) can carry the View alpha into the
        // captured result on some Android WebView implementations.
        try { invoke(view, "setAlpha", 1.0f); } catch (Throwable ignored) {}
        viewGroup.getMethod("addView", Class.forName("android.view.View"), lp).invoke(decor, view, params);
        return true;
    }

    private static int measureSpec(int size) throws Exception {
        Class<?> ms = Class.forName("android.view.View$MeasureSpec");
        return (Integer) ms.getMethod("makeMeasureSpec", int.class, int.class).invoke(null, size, 1073741824);
    }

    private static int clampSize(int value) {
        return Math.max(512, Math.min(1536, value));
    }

    private static Object invoke(Object target, String name, Object... args) throws Exception {
        if (target == null) throw new NullPointerException(name + ": target=null");
        Method found = null;
        outer:
        for (Method m : target.getClass().getMethods()) {
            if (!m.getName().equals(name) || m.getParameterCount() != args.length) continue;
            Class<?>[] p = m.getParameterTypes();
            for (int i = 0; i < p.length; i++) {
                if (args[i] == null) continue;
                if (!box(p[i]).isAssignableFrom(args[i].getClass())) continue outer;
            }
            found = m;
            break;
        }
        if (found == null) throw new NoSuchMethodException(name + "/" + args.length);
        return found.invoke(target, args);
    }

    private static Class<?> box(Class<?> c) {
        if (!c.isPrimitive()) return c;
        if (c == boolean.class) return Boolean.class;
        if (c == byte.class) return Byte.class;
        if (c == short.class) return Short.class;
        if (c == int.class) return Integer.class;
        if (c == long.class) return Long.class;
        if (c == float.class) return Float.class;
        if (c == double.class) return Double.class;
        if (c == char.class) return Character.class;
        return c;
    }

    private static void runUi(Runnable task) {
        if (task == null) return;
        // 1) Preferred: Activity.runOnUiThread(...). Android's Activity API owns the
        //    UI-thread dispatch and avoids android.os.Handler/Looper reflection.
        try {
            Object activity = AndroidBrowserBridge.currentActivity();
            if (activity != null) {
                Method runOnUiThread = activity.getClass().getMethod("runOnUiThread", Runnable.class);
                runOnUiThread.invoke(activity, task);
                return;
            }
        } catch (Throwable t) {
            debug("WARN runOnUiThread failed: " + t);
        }
        // 2) ZL2 degraded mode: no Activity in this process (":jvm", or ":game" before
        //    VMActivity exists). Previously this threw and silently DROPPED every UI task,
        //    which is why WebView creation/capture never happened on ZL2 (ZL2ac). Fall back
        //    to the main-thread Handler so the work still reaches the Android UI thread.
        try {
            Class<?> looperClass = Class.forName("android.os.Looper");
            Object mainLooper = looperClass.getMethod("getMainLooper").invoke(null);
            Class<?> handlerClass = Class.forName("android.os.Handler");
            Object handler = handlerClass.getConstructor(looperClass).newInstance(mainLooper);
            handlerClass.getMethod("post", Runnable.class).invoke(handler, task);
            return;
        } catch (Throwable t) {
            debug("WARN main-Handler dispatch failed: " + t);
        }
        // 3) Last resort: run inline (the caller may already be on the UI thread).
        try {
            task.run();
        } catch (Throwable t) {
            lastError = "ui: " + t;
            debug("ERROR UI dispatch: " + t);
            ExampleMod.LOGGER.warn("[WebView-V8] UI dispatch failed: {}", t.toString());
        }
    }

    private static void postOnWebView(long delayMs, Runnable task) {
        try {
            if (webView == null || task == null) return;
            if (webViewPostDelayed == null) {
                webViewPostDelayed = webView.getClass().getMethod("postDelayed", Runnable.class, long.class);
            }
            webViewPostDelayed.invoke(webView, task, Math.max(0L, delayMs));
        } catch (Throwable t) {
            lastError = "post: " + t;
            debug("ERROR post: " + t);
            ExampleMod.LOGGER.warn("[WebView-V8] WebView postDelayed failed: {}", t.toString());
        }
    }
}
