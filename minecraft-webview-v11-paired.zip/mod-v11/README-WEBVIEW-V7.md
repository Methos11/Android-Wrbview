# WebView Browser Mod V7 — Input + Audio + Config

V7 基于 V6.2 的 ZL2 Activity 修复版，按 Skill 分阶段路线图实现以下功能：

## 阶段 4：输入事件转发

**新增文件**：`client/input/BrowserInputAdapter.java`

将 Minecraft 鼠标/键盘事件映射并转发到 Android WebView：

| Minecraft 事件 | WebView 转发 | 说明 |
|---|---|---|
| 鼠标点击（内容区） | `MotionEvent.ACTION_DOWN` | 坐标映射到 WebView 视口 |
| 鼠标拖动（内容区） | `MotionEvent.ACTION_MOVE` | 实时跟踪 |
| 鼠标释放 | `MotionEvent.ACTION_UP` | 释放后 WebView 收到点击完成 |
| 滚轮 | `WebView.scrollBy()` | 原生页面滚动 |
| 键盘按键 | `KeyEvent.ACTION_DOWN/UP` | GLFW→Android keyCode 映射 |
| 字符输入（`charTyped`） | `InputConnection.commitText` | 表单输入框打字 |

- `AndroidWebViewBridge` 新增 `forwardTouch()`、`forwardKey()`、`forwardScroll()` 方法，全部通过反射构造 `MotionEvent`/`KeyEvent`。
- `BrowserScreen` 在 `mouseClicked/Dragged/Released/Scrolled` 和 `keyPressed/charTyped` 中，当 WebView 激活时将事件转发到适配器。
- 坐标映射：Minecraft GUI 坐标 → WebView 视口坐标（按内容区比例缩放）。

## 阶段 5：配置系统增强

`BrowserConfig` 新增字段：

| 配置项 | 默认值 | 说明 |
|---|---|---|
| `maxTextureResolution` | 1024 | WebView 纹理最大分辨率 |
| `windowDefaultWidth` | 560 | 浏览器窗口默认宽度 |
| `windowDefaultHeight` | 420 | 浏览器窗口默认高度 |
| `audioMuted` | false | 默认静音 |

- `WebViewTextureBridge` 在 `start()` 时读取 `maxTextureResolution`，纹理大小可配置。
- `BrowserScreen` 在 `init()` 时读取 `windowDefaultWidth/Height`。
- 初始静音状态从配置读取。

## 阶段 7：音频/视频支持

`AndroidWebViewBridge` 新增：

- `setMuted(boolean)` / `toggleMute()` — 通过 `AudioManager` 控制 `STREAM_MUSIC` 音量。
- `isMuted()` — 查询当前静音状态。
- WebView 设置增强：`setAppCacheEnabled`、`setAllowFileAccess`、`setAllowContentAccess`、`setPluginState(PLUGIN_ON)`。
- `BrowserScreen` 新增 M（静音）按钮，导航栏共 10 个按钮。

## 其他修复

- 全局日志前缀从 `[WebView-V6]` 统一更新为 `[WebView-V7]`。
- `AndroidWebViewBridge` 的 V5 日志错误修复。
- 纹理名称从 `webview_surface_v6` 更新为 `webview_surface_v7`。
- 语言文件（zh_cn / en_us）新增 `tip.mute` 翻译键。

## 构建

```text
./gradlew clean build --no-daemon
```

环境：Minecraft 26.2、Fabric Loader 0.19.3、Loom 1.17、Gradle 9.5.1、Java 25。

> 本环境无法联网获取 Gradle 9.5.1，因此未完成本地 Gradle 构建验证。
> 请在实际 Android / ZL2 开发环境中构建并测试。

## 26.2 API 注意事项

Minecraft 26.2 的输入 API 已重构为事件对象（`KeyEvent`、`MouseButtonEvent`）。
`BrowserScreen.charTyped(char, int)` 使用的是标准 MC 签名，如果 26.2 已将其重构为
事件对象签名（如 `charTyped(CharacterEvent)`），请相应调整。键盘导航键转发
（方向键、Enter、Backspace 等）通过 `keyPressed(KeyEvent)` 转发，不受此影响。

字符文本输入通过 `InputConnection.commitText` 提交给 WebView 的输入连接。
当用户点击网页表单字段时，Android 系统 IME 会自动弹出，不需要 Minecraft 侧
转发字符事件即可完成文字输入。
