# WebView Browser Mod V8 — ZL2ac 修复（ZL2 多进程 Activity 适配）

V8 专门修复 **ZL2ac**：在 ZL2（Zalith Launcher 2）上 WebView 永久不可用、
日志里反复出现 "Activity not found / WebView disabled" 的问题。

---

## 一、根因：ZL2 v2 是多进程启动器

通过查阅 ZL2 官方仓库（`ZalithLauncher/ZalithLauncher2`）的
`build.gradle.kts` 与 `AndroidManifest.xml` 确认：

| 属性 | 值 |
|---|---|
| namespace | `com.movtery.zalithlauncher` |
| applicationId | `com.movtery.zalithlauncher.v2` |

`AndroidManifest.xml` 中声明的进程归属：

| 组件 | 进程 | 作用 |
|---|---|---|
| `.ui.activities.VMActivity` | `android:process=":game"` | **承载 Minecraft 画面** |
| `.ui.activities.MainActivity` | 主进程 | 启动器 UI |
| `.ui.activities.SplashActivity` | 主进程（LAUNCHER 入口） | 启动页 |
| `.game.launch.GameService` | `android:process=":game"` | 游戏引擎 |
| `.game.download.jvm_server.JvmService` | `android:process=":jvm"` | **跑 JVM** |
| `.ZLApplication` | 主进程 | 自定义 Application |

**结论**：Mod 运行在游戏 JVM 里，也就是 `:game` 或 `:jvm` 进程。

V6/V7 的 `AndroidBrowserBridge.currentActivity()` 只探测了 **`MainActivity`**
和 `net.kdt.pojavlaunch.MainActivity` —— 这两个都在**主进程**。
Android 的进程隔离决定了：**跨进程拿不到另一个进程的 Activity 实例**。

所以：

```
currentActivity() == null  →  available() 返回 false  →  WebView 永久禁用
```

这就是 ZL2ac。它不是"没找到 Activity"，而是**找错了进程**。

---

## 二、V8 的三层修复

### 修复 1：按进程排布的 Activity 候选列表（VMActivity 优先）

`AndroidBrowserBridge.currentActivity()` 的候选类名改为 6 项，**把真正同进程的
`VMActivity` 排到最前面**：

```java
String[] launcherClasses = {
    // ZL2 v2 — 游戏进程（最可能命中，优先级最高）
    "com.movtery.zalithlauncher.ui.activities.VMActivity",
    // ZL2 v2 — 主进程兜底
    "com.movtery.zalithlauncher.ui.activities.MainActivity",
    "com.movtery.zalithlauncher.ui.activities.SplashActivity",
    "com.movtery.zalithlauncher.ui.activities.ControlEditorActivity",
    // ZL2 v1 / Pojav 血统
    "net.kdt.pojavlaunch.MainActivity",
    "net.kdt.pojavlaunch.customcontrols.ControlEditorActivity"
};
```

### 修复 2：Application Context 降级模式（核心）

`ActivityThread.currentApplication()` 在**任意一个进程**里都能拿到，
每个应用只有一个 Application 对象。V8 新增：

```java
public static Object applicationContext();           // Application Context（任何进程可达）
public static Object bestContext();                  // Activity 优先，否则 Application
public static boolean hasActivity();                 // 是否处于完整模式
public static String processName();                  // ":game" / ":jvm" / 包名
public static String contextDiagnostics();           // 诊断串，见下
```

`AndroidWebViewBridge.available()` 不再因为拿不到 Activity 就返回 `false`：

```java
Object activity = AndroidBrowserBridge.currentActivity();
Object context  = activity != null ? activity : AndroidBrowserBridge.applicationContext();
if (context == null) { /* 真的不在 Android 上 */ return false; }
degraded = (activity == null);
return true;
```

**降级模式下 WebView 仍然能渲染页面、执行 JS**；只有依赖 Activity 的能力会退化：
文件选择器（`<input type=file>`）、JS 弹窗（`alert/confirm/prompt`）。
这远比整个浏览器被禁用要好 —— 而"整个禁用"正是 V6/V7 的行为。

### 修复 3：UI 线程 Handler 兜底（此前会静默丢任务）

旧版 `runUi()` 在拿不到 Activity 时直接 `throw`，于是 **WebView 的创建和抓帧任务
全部被丢弃且无日志** —— 这是 ZL2ac 除了 Activity 探测之外的第二个致命点。

V8 改成三级派发：

| 级别 | 机制 | 适用 |
|---|---|---|
| 1 | `Activity.runOnUiThread()` | 拿到 Activity（完整模式） |
| 2 | `Looper.getMainLooper()` + `new Handler(mainLooper).post()` | **降级模式（ZL2 关键）** |
| 3 | 内联 `task.run()` | 调用方已在 UI 线程 |

---

## 三、顺带修复

| 问题 | 修复 |
|---|---|
| `setMuted()` 硬依赖 Activity，降级模式下静音失效 | 改用 `bestContext()`；`AudioManager` 是系统服务，Application Context 同样可用 |
| `setAppCachePath` 写死 `/data/data/cn.autoforged/...` | 改用 `context.getCacheDir()` 推导；Mod 跑在**启动器**的包名下，硬编码路径不可写 |
| 无法在不开 logcat 的情况下判断进程/模式 | 调试面板（D 按钮）新增 `contextDiagnostics()` 行 |
| 日志/纹理标识符残留 V7 | 全文统一为 `[WebView-V8]` / `webview_surface_v8` / `android_browser_webview_v8` |

---

## 四、如何验证（看日志 / 看面板）

### 游戏内调试面板

打开浏览器窗口 → 点 **D** 按钮，第一行会显示（绿色 = 完整模式，橙色 = 降级）：

```
process=com.movtery.zalithlauncher.v2:game | activity=com.movtery.zalithlauncher.ui.activities.VMActivity | application=com...ZLApplication | mode=ACTIVITY
```

### logcat 关键行

| 日志 | 含义 |
|---|---|
| `[WebView-V8] Activity resolved via LauncherField:...VMActivity.xxx -> com...VMActivity` | 完整模式，拿到了同进程 Activity |
| `[WebView-V8] Activity unreachable in process ':jvm' -> Application context (degraded)` | 降级模式，预期行为（不再禁用） |
| `[WebView-V8] capability OK mode=APPLICATION(degraded) \| process=... \| activity=none \| ...` | WebView 已启用，可继续 |
| `[WebView-V8] no Android Context; WebView disabled \| ...` | 真的不在 Android 环境（桌面端正常） |
| `[WebView-V8] created size=1024x1024 attached=false activityContext=false` | 降级模式创建成功；`attached=false` 表示未挂到窗口，属正常 |

`mode=APPLICATION(degraded)` **不是错误**，它就是本次要修的目标场景。

### 诊断串格式

```
process=<进程名> | activity=<类名|none> | application=<类名|none> | mode=ACTIVITY|APPLICATION(degraded)|NONE
```

---

## 五、降级模式的已知限制

1. **未挂载窗口**：`attachToCurrentActivity()` 需要 Activity 的 `DecorView`，降级模式下
   返回 `false`，WebView 处于"离屏"状态。抓帧依赖 `setLayerType(SOFTWARE)` +
   `measure/layout/draw(Canvas)` 这条标准离屏路径。
   若抓到的帧全白/全黑，说明该 ROM 的 Chromium 实现要求 View 已 attached —— 此时需让
   VMActivity 可被探测到（即完整模式）。
2. **JS 弹窗 / 文件选择器**不可用（需要 `WebChromeClient` + Activity）。
3. 进程名在极少数 ROM 上可能返回 `unknown`，此时以 `mode=` 为准。

---

## 构建

```text
./gradlew clean build --no-daemon
```

环境：Minecraft 26.2、Fabric Loader 0.19.3、Loom 1.17、Gradle 9.5.1、Java 25。

> 本环境无法联网获取 Gradle 9.5.1，因此**未完成本地 Gradle 构建验证**。
> 已做的验证：`javac` 语法/结构检查通过（Minecraft 符号缺失属预期，因为未挂载 Loom 依赖）；
> 版本标识符通过 grep 全量核对。请在实际 Android / ZL2 设备上构建并测试。

### 26.2 API 注意事项

与 V7 相同：26.2 的输入 API 已重构为事件对象（`KeyEvent`、`MouseButtonEvent`）。
`charTyped(char, int)` 若已被重构为事件对象签名，请相应调整。
