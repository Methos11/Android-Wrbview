package cn.autoforged.android_browser_mod_1789566815.client.render;

import cn.autoforged.android_browser_mod_1789566815.AndroidBrowserBridge;
import cn.autoforged.android_browser_mod_1789566815.AndroidWebViewBridge;
import cn.autoforged.android_browser_mod_1789566815.BrowserConfig;
import cn.autoforged.android_browser_mod_1789566815.ExampleMod;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

/**
 * V8: owns the single WebView frame texture and uploads frames only on the Minecraft client thread.
 * The texture is deliberately opaque: every incoming pixel has alpha forced to 255.
 *
 * <p>Texture size is now configurable via {@link BrowserConfig#maxTextureResolution}.
 */
public final class WebViewTextureBridge {
    private static int SIZE = 1024;
    private static final Identifier TEXTURE_ID = Identifier.fromNamespaceAndPath(
        ExampleMod.MOD_ID, "webview_surface_v8");

    private static DynamicTexture texture;
    private static volatile int[] pendingPixels;
    private static volatile int[] pendingSize;
    private static volatile String url = "";
    private static boolean started;
    private static boolean androidStartRequested;
    private static int activityRetryTicks;
    private static long uploadedFrames;
    private static int lastCenter;
    private static volatile boolean pageReady;

    private WebViewTextureBridge() {}

    public static void start() {
        if (started) return;
        started = true;
        androidStartRequested = false;
        activityRetryTicks = 0;
        SIZE = BrowserConfig.get().maxTextureResolution;
        // Create an opaque white placeholder immediately. ZL2 may expose its foreground
        // Activity a few ticks after Fabric client initialization, so WebView startup is retried.
        // The board itself stays solid white during that period.
        // Create an opaque white placeholder immediately. This prevents the world/block behind
        // the screen from ever becoming visible while Chromium is warming up.
        try {
            NativeImage image = new NativeImage(SIZE, SIZE, false);
            for (int y = 0; y < SIZE; y++) {
                for (int x = 0; x < SIZE; x++) {
                    image.setPixel(x, y, 0xFFFFFFFF);
                }
            }
            texture = new DynamicTexture(() -> "android_browser_webview_v8", image);
            Minecraft.getInstance().getTextureManager().register(TEXTURE_ID, texture);
        } catch (Throwable t) {
            ExampleMod.LOGGER.warn("[WebView-V8] placeholder texture creation failed: {}", t.toString());
        }
        pageReady = false;
        // Apply initial mute setting from config.
        if (BrowserConfig.get().audioMuted) {
            AndroidWebViewBridge.setMuted(true);
        }
        tryStartAndroidWebView();
        ExampleMod.LOGGER.info("[WebView-V8/ZL2] texture bridge started; size={}x{} | {}",
            SIZE, SIZE, AndroidBrowserBridge.contextDiagnostics());
    }

    private static void tryStartAndroidWebView() {
        if (androidStartRequested) return;
        if (!AndroidWebViewBridge.available()) return;
        androidStartRequested = true;
        AndroidWebViewBridge.start(SIZE, SIZE, (pixels, size) -> {
            pendingPixels = pixels;
            pendingSize = size;
        });
        if (!url.isBlank()) {
            AndroidWebViewBridge.loadUrl(url);
        }
    }

    public static void load(String nextUrl) {
        if (nextUrl == null || nextUrl.isBlank()) return;
        start();
        if (!nextUrl.equals(url)) {
            url = nextUrl;
            pageReady = false;
            clearToWhite();
            ExampleMod.LOGGER.info("[WebView-V8] switching page to {}", nextUrl);
            AndroidWebViewBridge.loadUrl(nextUrl);
        }
    }

    public static void tick() {
        // ZL2 can finish attaching the game Activity after Fabric client initialization.
        // Retry for roughly 5 seconds instead of permanently disabling WebView on the first tick.
        if (!androidStartRequested && activityRetryTicks++ < 300) {
            if (AndroidWebViewBridge.available()) {
                tryStartAndroidWebView();
            }
        }
        int[] pixels = pendingPixels;
        int[] size = pendingSize;
        if (pixels == null || size == null || size.length < 2 || pixels.length != size[0] * size[1]) return;
        pendingPixels = null;
        pendingSize = null;

        Minecraft mc = Minecraft.getInstance();
        if (mc == null) return;
        if (!AndroidWebViewBridge.pageReady()) return;
        try {
            if (texture == null || texture.getPixels() == null
                    || texture.getPixels().getWidth() != size[0]
                    || texture.getPixels().getHeight() != size[1]) {
                if (texture != null) {
                    try { texture.close(); } catch (Throwable ignored) {}
                }
                NativeImage image = new NativeImage(size[0], size[1], false);
                texture = new DynamicTexture(() -> "android_browser_webview_v8", image);
                mc.getTextureManager().register(TEXTURE_ID, texture);
                ExampleMod.LOGGER.info("[WebView-V8] GPU texture created {}x{}", size[0], size[1]);
            }

            NativeImage image = texture.getPixels();
            int w = Math.min(image.getWidth(), size[0]);
            int h = Math.min(image.getHeight(), size[1]);
            for (int y = 0; y < h; y++) {
                int row = y * size[0];
                for (int x = 0; x < w; x++) {
                    // Android Bitmap#getPixels returns ARGB. NativeImage's public setPixel API in
                    // the modern Minecraft mapping is the ARGB-facing setter; force alpha opaque
                    // so the screen is a solid textured panel, never see-through glass.
                    image.setPixel(x, y, pixels[row + x] | 0xFF000000);
                }
            }
            texture.upload();
            pageReady = AndroidWebViewBridge.pageReady();
            uploadedFrames++;
            lastCenter = pixels[(h / 2) * size[0] + (w / 2)] | 0xFF000000;
            if ((uploadedFrames & 15) == 1) {
                ExampleMod.LOGGER.info("[WebView-V8] uploaded frame #{} center=0x{} captureCount={} pageReady={}",
                    uploadedFrames, Integer.toHexString(lastCenter), AndroidWebViewBridge.captureCount(), pageReady);
            }
        } catch (Throwable t) {
            ExampleMod.LOGGER.warn("[WebView-V8] texture upload failed: {}", t.toString());
        }
    }

    private static void clearToWhite() {
        try {
            if (texture == null || texture.getPixels() == null) return;
            NativeImage image = texture.getPixels();
            for (int y = 0; y < image.getHeight(); y++) {
                for (int x = 0; x < image.getWidth(); x++) {
                    image.setPixel(x, y, 0xFFFFFFFF);
                }
            }
            texture.upload();
        } catch (Throwable t) {
            ExampleMod.LOGGER.warn("[WebView-V8] failed to reset loading surface: {}", t.toString());
        }
    }

    public static Identifier textureId() { return TEXTURE_ID; }
    public static int textureSize() { return SIZE; }
    public static boolean ready() { return texture != null; }
    public static boolean pageReady() { return pageReady && AndroidWebViewBridge.pageReady(); }
    public static String url() { return url; }
    public static long uploadedFrames() { return uploadedFrames; }
    public static int lastCenter() { return lastCenter; }
    public static boolean webViewAttached() { return AndroidWebViewBridge.attached(); }
    public static String webViewError() { return AndroidWebViewBridge.lastError(); }
    public static boolean audioMuted() { return AndroidWebViewBridge.isMuted(); }
    public static void toggleMute() { AndroidWebViewBridge.toggleMute(); }

    public static void close() {
        AndroidWebViewBridge.stop();
        if (texture != null) {
            try { texture.close(); } catch (Throwable ignored) {}
            texture = null;
        }
        pendingPixels = null;
        pendingSize = null;
        started = false;
        androidStartRequested = false;
        activityRetryTicks = 0;
        uploadedFrames = 0;
        lastCenter = 0;
        pageReady = false;
    }
}
