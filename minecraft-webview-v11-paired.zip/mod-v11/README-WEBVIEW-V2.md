# Android Browser Mod — WebView Render Bridge v2

本版本针对 Android / ZL2 / Minecraft 26.2：

- 使用 Android System WebView / Chromium 作为真正网页渲染器。
- HTML/CSS/图片/JavaScript 不再依赖 `HtmlDocument` 的简化解析。
- WebView 通过 Android UI 主线程创建，并尝试挂接到当前 Activity 的 decor hierarchy，随后转成 ARGB 帧。
- Minecraft 侧通过 `WebViewTextureBridge` 将帧上传为 `DynamicTexture`，GUI 使用 `RenderPipelines.GUI_TEXTURED` 绘制。
- 保留原有 `BrowserPageLoader` 作为桌面/无 WebView 回退，同时增强 BOM、HTTP charset、HTML charset 的中文编码检测。
- UI 保留窗口化浏览器结构，但增加顶部高亮边、状态栏和更适合触控的布局。
- `ScreenWallLayout` 已加入，用于检测同 URL 的相邻屏幕方块矩形，为后续真正的无缝大屏 UV 分片提供布局数据。

## 重要

`ScreenWallLayout` 是本轮的布局层；世界中的动态网页纹理仍需要进一步通过 26.2 的 `SubmitNodeCollector.submitCustomGeometry` 接到自定义四边形 RenderType，才能最终实现“多个屏幕方块 = 一块连续网页屏幕”。本版本没有假装这一部分已经完成。

Minecraft 26.2 应使用 Blaze3D/RenderPipeline，而不是原始 OpenGL；官方文档也说明 26.2 的 GUI 使用 `GuiGraphicsExtractor`，世界渲染使用新的 submit/render-state 架构。

## 构建

环境需准备 Minecraft 26.2、Fabric Loader 0.19.3、Loom 1.17、Gradle 9.5.1、Java 25。由于本次工作环境无法访问 Gradle 镜像，因此没有在这里宣称构建成功。
