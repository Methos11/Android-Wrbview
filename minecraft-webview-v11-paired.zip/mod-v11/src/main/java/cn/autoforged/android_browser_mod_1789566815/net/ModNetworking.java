package cn.autoforged.android_browser_mod_1789566815.net;

import cn.autoforged.android_browser_mod_1789566815.block.ScreenBlockEntity;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;

/** 屏幕方块用到的网络包注册与接收。 */
public final class ModNetworking {
    private ModNetworking() {
    }

    public static void registerPayloads() {
        // 26.2 的 PayloadTypeRegistry 改名为 serverboundPlay()/clientboundPlay()（旧 playC2S()/playS2C() 已删）
        PayloadTypeRegistry.serverboundPlay().register(SetScreenUrlPayload.TYPE, SetScreenUrlPayload.CODEC);
    }

    public static void registerServerReceivers() {
        ServerPlayNetworking.registerGlobalReceiver(SetScreenUrlPayload.TYPE, (payload, context) -> {
            ServerPlayer player = context.player();
            ServerLevel level = player.level();
            // 验证客户端数据，防任意 chunk 加载 DoS
            if (!level.hasChunkAt(payload.pos())) {
                return;
            }
            if (player.distanceToSqr(Vec3.atCenterOf(payload.pos())) > 64 * 64) {
                return;
            }
            BlockEntity blockEntity = level.getBlockEntity(payload.pos());
            if (blockEntity instanceof ScreenBlockEntity screen) {
                screen.setUrl(payload.url());
            }
        });
    }
}
