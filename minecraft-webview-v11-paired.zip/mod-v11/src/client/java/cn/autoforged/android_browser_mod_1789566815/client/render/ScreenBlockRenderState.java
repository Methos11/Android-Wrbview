package cn.autoforged.android_browser_mod_1789566815.client.render;

import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.core.Direction;

import java.util.List;

/** 屏幕方块渲染状态：只放渲染需要的不可变数据。 */
public class ScreenBlockRenderState extends BlockEntityRenderState {
    public Direction facing = Direction.NORTH;
    public List<String> lines = List.of();
    /** 没有内容时要显示的提示（空字符串表示没有提示）。 */
    public String hint = "";
    public int tileU = 0;
    public int tileV = 0;
    public int wallWidth = 1;
    public int wallHeight = 1;
    public String url = "";
}
