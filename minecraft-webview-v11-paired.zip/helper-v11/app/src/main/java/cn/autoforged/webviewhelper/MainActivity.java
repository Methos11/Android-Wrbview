package cn.autoforged.webviewhelper;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.view.animation.DecelerateInterpolator;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/** Modern KSU-inspired (not a copy) Helper UI: dark surface, sliding navigation pill, preview diagnostics. */
public class MainActivity extends Activity {
    static volatile WebView sharedWebView;
    static volatile String lastError="", pageTitle="", currentUrl="https://www.minecraft.net";
    static volatile int progress=0;
    static volatile boolean cssEnabled=true, jsEnabled=true;
    static final StringBuilder LOG=new StringBuilder(30000);
    final Handler ui=new Handler(Looper.getMainLooper());
    FrameLayout root, previewHost; LinearLayout content; ScrollView scroll; FrameLayout navFrame; LinearLayout navItems;
    TextView navTitle, subtitle, statusText, statusDot, pageInfo, webStats, logText, previewDebug;
    View navSelector; int page=0; float downX; long downT;
    final int BG=Color.rgb(7,10,15), SURFACE=Color.rgb(17,22,30), SURFACE2=Color.rgb(25,32,43), TEXT=Color.rgb(241,244,249), MUTED=Color.rgb(145,157,176), PRIMARY=Color.rgb(124,153,255), GOOD=Color.rgb(79,224,151), BAD=Color.rgb(239,100,115), WARN=Color.rgb(242,183,78);

    static void log(String s){String line=new SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date())+"  "+s; synchronized(LOG){LOG.append(line).append('\n');if(LOG.length()>29000)LOG.delete(0,LOG.length()-29000);} android.util.Log.d("MinecraftWebView",s);}
    static String snapshotLogs(){synchronized(LOG){return LOG.toString();}}

    @Override public void onCreate(Bundle b){super.onCreate(b);WebView.setWebContentsDebuggingEnabled(true);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);buildUi();createWebView();startHelper();scheduleRefresh();}

    void buildUi(){
        root=new FrameLayout(this);root.setBackgroundColor(BG);
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);shell.setPadding(18,10,18,10);root.addView(shell,flp(-1,-1));
        root.setOnApplyWindowInsetsListener((v,in)->{v.setPadding(in.getSystemWindowInsetLeft(),in.getSystemWindowInsetTop(),in.getSystemWindowInsetRight(),in.getSystemWindowInsetBottom());return in;});
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);
        navTitle=txt("概览",25,TEXT);brand.addView(navTitle,lp(-1,36));subtitle=txt("LOCAL WEBVIEW BRIDGE · ZL2",11,MUTED);brand.addView(subtitle,lp(-1,22));top.addView(brand,lp(0,64,1));
        TextView menu=roundButton("⋯",20);menu.setOnClickListener(v->showAbout());top.addView(menu,sz(48));shell.addView(top,lp(-1,66));
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(content,lp(-1,-2));
        scroll.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downT=SystemClock.uptimeMillis();}else if(e.getAction()==MotionEvent.ACTION_UP){float dx=e.getX()-downX;if(Math.abs(dx)>120&&SystemClock.uptimeMillis()-downT<700){setPage(page+(dx<0?1:-1));return true;}}return false;});shell.addView(scroll,lp(-1,0,1));
        navFrame=new FrameLayout(this);navFrame.setPadding(4,4,4,4);navFrame.setBackground(round(SURFACE,28));navSelector=new View(this);navSelector.setBackground(round(PRIMARY,22));navFrame.addView(navSelector,flp(0,0,0,0));
        String[] labels={"概览","预览","日志","设置"};String[] icons={"⌂","◉","≡","⚙"};
        navItems=new LinearLayout(this);navItems.setOrientation(LinearLayout.HORIZONTAL);navItems.setGravity(Gravity.CENTER_VERTICAL);navItems.setPadding(4,0,4,0);
        for(int i=0;i<4;i++){final int idx=i;LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);item.addView(txt(icons[i],19,TEXT),lp(-1,25));item.addView(txt(labels[i],11,TEXT),lp(-1,20));item.setOnClickListener(v->setPage(idx));navItems.addView(item,lp(0,60,1));}
        navFrame.addView(navItems,flp(0,0,-1,-1));shell.addView(navFrame,lp(-1,68));setContentView(root);navFrame.post(()->moveSelector(false));renderPage();
    }
    FrameLayout.LayoutParams flp(int w,int h){return new FrameLayout.LayoutParams(w,h);} FrameLayout.LayoutParams flp(int left,int top,int width,int height){FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(width,height);p.leftMargin=left;p.topMargin=top;return p;}
    void setPage(int p){p=Math.max(0,Math.min(3,p));if(page==p)return;page=p;renderPage();moveSelector(true);}
    void moveSelector(boolean animate){if(navFrame==null)return;int w=Math.max(1,(navFrame.getWidth()-8)/4);FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)navSelector.getLayoutParams();lp.width=w;lp.height=60;lp.leftMargin=4;navSelector.setLayoutParams(lp);float x=4+page*w;if(animate)navSelector.animate().translationX(x-4).setDuration(260).setInterpolator(new DecelerateInterpolator()).start();else navSelector.setTranslationX(x-4);}
    void renderPage(){detachWebView();content.removeAllViews();String[] t={"概览","网页预览","运行日志","设置"};navTitle.setText(t[page]);if(page==0)overview();else if(page==1)previewPage();else if(page==2)logsPage();else settingsPage();}
    void detachWebView(){if(sharedWebView==null)return;ViewParent p=sharedWebView.getParent();if(p instanceof ViewGroup)((ViewGroup)p).removeView(sharedWebView);sharedWebView.setVisibility(View.GONE);root.addView(sharedWebView,flp(-1000,-1000,1,1));}

    void overview(){
        addHero();LinearLayout stats=new LinearLayout(this);stats.setPadding(0,8,0,8);stats.addView(stat("连接",WebViewService.serverReady?"在线":"离线"),lp(0,112,1));stats.addView(stat("帧",String.valueOf(WebViewService.captureCount)),lp(0,112,1));stats.addView(stat("捕获",WebViewService.getCaptureFps()+" FPS"),lp(0,112,1));content.addView(stats,lp(-1,120));
        LinearLayout quick=card();quick.addView(section("快速操作"),lp(-1,32));LinearLayout r=new LinearLayout(this);TextView prev=primary("打开预览");prev.setOnClickListener(v->setPage(1));TextView reload=secondary("刷新页面");reload.setOnClickListener(v->navigate(currentUrl));TextView diag=secondary("诊断");diag.setOnClickListener(v->setPage(2));r.addView(prev,lp(0,46,1));r.addView(reload,lp(0,46,1));r.addView(diag,lp(0,46,1));quick.addView(r,lp(-1,58));content.addView(quick,lp(-1,112));
        LinearLayout health=card();health.addView(section("网页健康检查"),lp(-1,32));health.addView(check("WebView",WebViewService.ready),lp(-1,35));health.addView(check("JavaScript",jsEnabled),lp(-1,35));health.addView(check("CSS",WebViewService.cssResourceCount>=0),lp(-1,35));health.addView(check("图片",WebViewService.imageResourceCount>=0),lp(-1,35));health.addView(check("视频",WebViewService.videoResourceCount>=0),lp(-1,35));content.addView(health,lp(-1,205));
    }
    void addHero(){LinearLayout h=card();h.setPadding(18,16,18,16);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);statusDot=txt("●",29,WebViewService.serverReady?GOOD:WARN);row.addView(statusDot,sz(48));LinearLayout t=new LinearLayout(this);t.setOrientation(LinearLayout.VERTICAL);statusText=txt(WebViewService.serverReady?"Helper 在线":"等待 Helper",19,TEXT);t.addView(statusText,lp(-1,34));t.addView(txt("127.0.0.1:28765 · "+(WebViewService.ready?"WebView Ready":"WebView Waiting"),11,MUTED),lp(-1,24));row.addView(t,lp(0,66,1));TextView action=primary(WebViewService.serverReady?"停止":"启动");action.setOnClickListener(v->{if(WebViewService.serverReady)stopHelper();else startHelper();});row.addView(action,lp(78,44));h.addView(row,lp(-1,76));content.addView(h,lp(-1,112));}
    void previewPage(){
        LinearLayout url=card();LinearLayout ur=new LinearLayout(this);EditText input=new EditText(this);input.setSingleLine(true);input.setText(currentUrl);input.setTextColor(TEXT);input.setHintTextColor(MUTED);input.setHint("输入网址");input.setPadding(14,0,14,0);input.setBackground(round(SURFACE2,18));ur.addView(input,lp(0,48,1));TextView go=primary("打开");go.setOnClickListener(v->navigate(input.getText().toString().trim()));ur.addView(go,lp(72,48));TextView test=secondary("本地诊断");test.setOnClickListener(v->navigate("file:///android_asset/diagnostic/index.html"));ur.addView(test,lp(92,48));url.addView(ur,lp(-1,52));content.addView(url,lp(-1,70));
        FrameLayout ph=new FrameLayout(this);ph.setBackground(round(Color.WHITE,22));ph.setClipToOutline(true);previewHost=ph;content.addView(ph,lp(-1,330));
        TextView dbg=txt("加载中…",11,Color.WHITE);dbg.setPadding(12,7,12,7);dbg.setBackground(round(Color.argb(210,10,14,20),14));FrameLayout.LayoutParams dp=flp(10,10,-1,0);dp.height=72;dp.gravity=Gravity.BOTTOM;dp.leftMargin=10;dp.rightMargin=10;dp.bottomMargin=10;ph.addView(dbg,dp);previewDebug=dbg;
        attachPreview(ph);
        LinearLayout actions=card();LinearLayout ar=new LinearLayout(this);TextView back=secondary("‹ 后退");back.setOnClickListener(v->{if(sharedWebView!=null&&sharedWebView.canGoBack())sharedWebView.goBack();});TextView forward=secondary("前进 ›");forward.setOnClickListener(v->{if(sharedWebView!=null&&sharedWebView.canGoForward())sharedWebView.goForward();});TextView refresh=secondary("刷新");refresh.setOnClickListener(v->{if(sharedWebView!=null)sharedWebView.reload();});TextView copy=secondary("复制诊断");copy.setOnClickListener(v->copyLogs());ar.addView(back,lp(0,44,1));ar.addView(forward,lp(0,44,1));ar.addView(refresh,lp(0,44,1));ar.addView(copy,lp(0,44,1));actions.addView(ar,lp(-1,54));content.addView(actions,lp(-1,78));
        LinearLayout diag=card();diag.addView(section("实时检测"),lp(-1,30));webStats=txt(WebViewService.previewDiagnostics(),12,TEXT);webStats.setTypeface(Typeface.MONOSPACE);diag.addView(webStats,lp(-1,185));content.addView(diag,lp(-1,220));
    }
    void attachPreview(FrameLayout host){if(sharedWebView==null)return;ViewParent p=sharedWebView.getParent();if(p instanceof ViewGroup)((ViewGroup)p).removeView(sharedWebView);sharedWebView.setVisibility(View.VISIBLE);sharedWebView.setAlpha(1f);host.addView(sharedWebView,0,new FrameLayout.LayoutParams(-1,-1));}
    void logsPage(){LinearLayout tools=card();LinearLayout r=new LinearLayout(this);TextView copy=primary("复制日志");copy.setOnClickListener(v->copyLogs());TextView exp=secondary("导出");exp.setOnClickListener(v->exportLogs());TextView clear=secondary("清空");clear.setOnClickListener(v->{synchronized(LOG){LOG.setLength(0);}renderPage();});r.addView(copy,lp(0,44,1));r.addView(exp,lp(0,44,1));r.addView(clear,lp(0,44,1));tools.addView(r,lp(-1,52));content.addView(tools,lp(-1,72));ScrollView sv=new ScrollView(this);logText=txt(snapshotLogs(),11,Color.rgb(205,214,226));logText.setTypeface(Typeface.MONOSPACE);logText.setPadding(14,14,14,14);sv.setBackground(round(Color.rgb(9,12,17),18));sv.addView(logText,lp(-1,-2));content.addView(sv,lp(-1,0,1));}
    void settingsPage(){
        LinearLayout p=card();p.addView(section("性能"),lp(-1,32));p.addView(settingRow("网页捕获帧率","当前 "+(1000/Math.max(1,WebViewService.captureIntervalMs))+" FPS",new String[]{"2 FPS","4 FPS","8 FPS","15 FPS"},new int[]{500,250,125,67}),lp(-1,68));p.addView(settingRow("预览/纹理分辨率",WebViewService.width+"×"+WebViewService.height,new String[]{"256×256","512×512","768×768","1024×1024"},new int[]{256,512,768,1024}),lp(-1,68));content.addView(p,lp(-1,190));
        LinearLayout e=card();e.addView(section("网页引擎"),lp(-1,32));e.addView(check("JavaScript",jsEnabled),lp(-1,36));e.addView(check("CSS / Stylesheet",true),lp(-1,36));e.addView(check("图片资源",true),lp(-1,36));e.addView(check("视频资源",true),lp(-1,36));e.addView(check("DOM Storage",true),lp(-1,36));content.addView(e,lp(-1,220));
        LinearLayout about=card();about.addView(section("诊断能力"),lp(-1,32));about.addView(txt("主页面 / 子资源 / HTTP / JS Console / CSS / JS / Image / Video / DOM / 帧捕获 / Server 状态",12,MUTED),lp(-1,68));content.addView(about,lp(-1,120));
    }
    LinearLayout settingRow(String name,String current,String[] options,int[] values){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);LinearLayout t=new LinearLayout(this);t.setOrientation(LinearLayout.VERTICAL);t.addView(txt(name,14,TEXT),lp(-1,28));t.addView(txt(current,11,MUTED),lp(-1,22));r.addView(t,lp(0,60,1));TextView b=secondary("选择");b.setOnClickListener(v->{PopupMenu pm=new PopupMenu(this,b);for(int i=0;i<options.length;i++){final int val=values[i];pm.getMenu().add(options[i]).setOnMenuItemClickListener(m->{if(name.contains("帧率"))WebViewService.setCaptureInterval(val);else WebViewService.setResolution(val);renderPage();return true;});}pm.show();});r.addView(b,lp(72,42));return r;}
    LinearLayout check(String name,boolean ok){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.addView(txt(name,14,TEXT),lp(0,36,1));r.addView(txt(ok?"● 正常":"● 异常",12,ok?GOOD:BAD),lp(95,36));return r;}
    LinearLayout stat(String a,String b){LinearLayout c=card();c.setPadding(13,10,13,8);c.addView(txt(a,11,MUTED),lp(-1,26));c.addView(txt(b,19,TEXT),lp(-1,38));return c;}
    TextView section(String s){return txt(s,15,TEXT);} TextView txt(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    TextView roundButton(String s,int size){TextView t=txt(s,size,TEXT);t.setGravity(Gravity.CENTER);t.setBackground(round(SURFACE,18));return t;}
    TextView primary(String s){TextView t=txt(s,13,Color.WHITE);t.setGravity(Gravity.CENTER);t.setBackground(round(PRIMARY,16));return t;}
    TextView secondary(String s){TextView t=txt(s,12,TEXT);t.setGravity(Gravity.CENTER);t.setBackground(round(SURFACE2,16));return t;}
    LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(15,12,15,12);c.setBackground(round(SURFACE,22));return c;}
    GradientDrawable round(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);return g;}
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}LinearLayout.LayoutParams lp(int w,int h,float wt){return new LinearLayout.LayoutParams(w,h,wt);}FrameLayout.LayoutParams sz(int x){return new FrameLayout.LayoutParams(x,x);}

    void createWebView(){WebView web=new WebView(this);sharedWebView=web;configureWebView(web);web.setBackgroundColor(Color.WHITE);web.setVisibility(View.VISIBLE);web.setAlpha(0.01f);FrameLayout.LayoutParams hidden=new FrameLayout.LayoutParams(512,512);hidden.leftMargin=0;hidden.topMargin=0;root.addView(web,hidden);web.loadUrl(currentUrl);log("WEBVIEW CREATED · Activity Context · JS enabled · attached VISIBLE");}
    static void configureWebView(WebView web){
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setLoadsImagesAutomatically(true);s.setBlockNetworkImage(false);s.setBlockNetworkLoads(false);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setJavaScriptCanOpenWindowsAutomatically(true);s.setSupportMultipleWindows(false);s.setLoadWithOverviewMode(true);s.setUseWideViewPort(true);s.setMediaPlaybackRequiresUserGesture(false);s.setCacheMode(WebSettings.LOAD_DEFAULT);s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);s.setOffscreenPreRaster(true);s.setUserAgentString(s.getUserAgentString()+" MinecraftWebViewHelper/8.0");CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageStarted(WebView v,String url,Bitmap f){currentUrl=url;progress=0;lastError="";WebViewService.resetChecks();log("LOAD "+url);}
            @Override public void onPageFinished(WebView v,String url){currentUrl=url;pageTitle=v.getTitle()==null?"":v.getTitle();progress=100;WebViewService.mainFrameOk=true;log("FINISH "+url);if(WebViewService.instance!=null)WebViewService.instance.main.post(()->WebViewService.instance.captureLoop());v.evaluateJavascript("(function(){var q=s=>document.querySelectorAll(s).length;var css=0;try{css=document.styleSheets.length}catch(e){};return JSON.stringify({ready:document.readyState,css:css,js:q('script'),img:q('img'),video:q('video'),audio:q('audio'),title:document.title})})()",value->{log("DOM "+value);WebViewService.updateDom(value);});}
            @Override public void onLoadResource(WebView v,String url){WebViewService.countResource(url);}
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){String m="RESOURCE "+(r.isForMainFrame()?"MAIN":"SUB")+" "+e.getErrorCode()+" "+e.getDescription()+" "+r.getUrl();WebViewService.resourceErrorCount++;log("ERROR "+m);if(r.isForMainFrame())lastError=m;}
            @Override public void onReceivedHttpError(WebView v,WebResourceRequest r,WebResourceResponse e){String m="HTTP "+e.getStatusCode()+" "+e.getReasonPhrase()+" "+r.getUrl();WebViewService.httpErrorCount++;log(m);if(r.isForMainFrame())lastError=m;}
        });
        web.setWebChromeClient(new WebChromeClient(){@Override public void onProgressChanged(WebView v,int p){progress=p;}@Override public boolean onConsoleMessage(ConsoleMessage m){log("JS "+m.messageLevel()+" "+m.message()+" @"+m.sourceId()+":"+m.lineNumber());return true;}@Override public void onReceivedTitle(WebView v,String t){pageTitle=t==null?"":t;}});
    }
    void navigate(String u){if(u==null||u.isEmpty())return;if(!u.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*$"))u="https://"+u;final String x=u;ui.post(()->{if(sharedWebView!=null)sharedWebView.loadUrl(x);});log("NAVIGATE "+x);setPage(1);}
    void startHelper(){try{Intent i=new Intent(this,WebViewService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);log("HELPER START requested");}catch(Throwable t){lastError="startService: "+t;log("ERROR "+lastError);}}
    void stopHelper(){try{stopService(new Intent(this,WebViewService.class));log("HELPER STOP requested");}catch(Throwable t){log("ERROR STOP "+t);}}
    void copyLogs(){ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("WebView Helper Log",snapshotLogs()));Toast.makeText(this,"日志已复制",Toast.LENGTH_SHORT).show();}
    void exportLogs(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,"webview-helper-"+System.currentTimeMillis()+".log");startActivityForResult(i,4001);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==4001&&c==RESULT_OK&&d!=null){try(OutputStream o=getContentResolver().openOutputStream(d.getData())){o.write(snapshotLogs().getBytes("UTF-8"));Toast.makeText(this,"运行日志已生成",Toast.LENGTH_SHORT).show();}catch(Exception e){log("EXPORT ERROR "+e);}}}
    void showAbout(){new AlertDialog.Builder(this).setTitle("WebView Helper 11").setMessage("Modern Local Bridge\nPreview-first diagnostics\n127.0.0.1:28765").setPositiveButton("确定",null).show();}
    void scheduleRefresh(){ui.postDelayed(new Runnable(){public void run(){if(statusText!=null){boolean on=WebViewService.serverReady;statusText.setText(on?"Helper 在线":"等待 Helper");statusDot.setTextColor(on?GOOD:WARN);if(pageInfo!=null)pageInfo.setText(WebViewService.statusSummary());if(webStats!=null)webStats.setText(WebViewService.previewDiagnostics());if(previewDebug!=null)previewDebug.setText(WebViewService.previewDiagnostics());if(logText!=null)logText.setText(snapshotLogs());}ui.postDelayed(this,700);}},300);}
    @Override protected void onDestroy(){super.onDestroy();}
}
