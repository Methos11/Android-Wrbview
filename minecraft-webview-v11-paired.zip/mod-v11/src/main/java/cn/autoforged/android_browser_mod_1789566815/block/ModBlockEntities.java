package cn.autoforged.android_browser_mod_1789566815.block;

import cn.autoforged.android_browser_mod_1789566815.ExampleMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.entity.BlockEntityType;

import java.util.Set;

/** 方块实体类型注册。26.2 无 {@code BlockEntityType.Builder}，直接用构造函数。 */
public final class ModBlockEntities {
    public static final BlockEntityType<ScreenBlockEntity> SCREEN_BLOCK = Registry.register(
        BuiltInRegistries.BLOCK_ENTITY_TYPE,
        ExampleMod.id("screen_block"),
        new BlockEntityType<>(ScreenBlockEntity::new, Set.of(ModBlocks.SCREEN_BLOCK)));

    private ModBlockEntities() {
    }

    public static void register() {
    }
}
