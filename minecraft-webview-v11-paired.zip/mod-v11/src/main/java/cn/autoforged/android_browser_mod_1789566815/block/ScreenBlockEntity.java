package cn.autoforged.android_browser_mod_1789566815.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jetbrains.annotations.Nullable;

/**
 * 屏幕方块实体：持久保存并同步当前显示的网址。网页文本由客户端各自抓取缓存（见
 * {@code client.browser.ScreenBlockContentCache}），方块本身只存 URL，避免服务端做网络请求。
 */
public class ScreenBlockEntity extends BlockEntity {
    public static final int MAX_URL_LENGTH = 2048;
    private static final String KEY_URL = "Url";

    private String url = "";

    public ScreenBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.SCREEN_BLOCK, pos, state);
    }

    public String getUrl() {
        return this.url;
    }

    public void setUrl(@Nullable String value) {
        String next = value == null ? "" : value.trim();
        if (next.length() > MAX_URL_LENGTH) {
            next = next.substring(0, MAX_URL_LENGTH);
        }
        if (next.equals(this.url)) {
            return;
        }
        this.url = next;
        this.setChanged();
        this.sync();
    }

    private void sync() {
        if (this.level != null && !this.level.isClientSide()) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(),
                Block.UPDATE_CLIENTS);
        }
    }

    @Override
    protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        output.putString(KEY_URL, this.url);
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        this.url = input.getStringOr(KEY_URL, "");
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return this.saveCustomOnly(registries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
