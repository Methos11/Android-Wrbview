package cn.autoforged.android_browser_mod_1789566815.block;

import cn.autoforged.android_browser_mod_1789566815.ExampleMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

import java.util.function.Function;

/**
 * 本 mod 的方块注册入口。
 *
 * <p>新增「屏幕方块」：可放置的显示器，蹲下右键打开浏览器窗口并把网址同步到方块上。
 * 26.2 的 {@code new Block}/{@code new BlockItem} 之前 MUST 先 {@code properties.setId(key)}，
 * 否则类加载期直接 NPE("Block id not set")。
 */
public final class ModBlocks {
    public static final ScreenBlock SCREEN_BLOCK = register(
        "screen_block",
        ScreenBlock::new,
        BlockBehaviour.Properties.of()
            .mapColor(MapColor.COLOR_BLACK)
            .strength(1.5f, 6.0f)
            .sound(SoundType.METAL));

    private ModBlocks() {
    }

    private static <T extends Block> T register(String name,
                                                Function<BlockBehaviour.Properties, T> factory,
                                                BlockBehaviour.Properties properties) {
        Identifier id = ExampleMod.id(name);
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
        T block = Registry.register(BuiltInRegistries.BLOCK, blockKey,
            factory.apply(properties.setId(blockKey)));

        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
        Registry.register(BuiltInRegistries.ITEM, itemKey,
            new BlockItem(block, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix()));
        return block;
    }

    /** 在 {@code onInitialize()} 里调用一次，触发本类静态初始化。 */
    public static void register() {
        ExampleMod.LOGGER.info("已注册屏幕方块 {}", SCREEN_BLOCK);
    }
}
