package cn.autoforged.android_browser_mod_1789566815.client.browser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 轻量「富文本」网页模型：把 HTML 解析成带颜色 / 加粗 / 链接的文本行，供内置浏览器渲染。
 *
 * <p>这不是完整的 CSS/JS 引擎——真正的网页渲染仍依靠 Android WebView 桥接。这里只是把
 * 内联 CSS（<code>color</code>）、<code>&lt;b&gt;</code>/<code>&lt;strong&gt;</code>、
 * 标题、链接等常见样式还原出来，让没有 WebView 时也能看到有层次的排版，而不是纯文本。
 */
public final class HtmlDocument {
    public static final int DEFAULT_TEXT_COLOR = 0xFF1A1A22;
    public static final int LINK_COLOR = 0xFF1E6FD9;
    public static final int HEADING_COLOR = 0xFF103B66;

    private static final int MAX_CHARS = 120_000;

    public final List<Line> lines;

    private HtmlDocument(List<Line> lines) {
        this.lines = lines;
    }

    public boolean isEmpty() {
        for (Line line : this.lines) {
            if (!line.spans.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    /** 纯文本（非 HTML 内容、抓取失败等）包装成单一样式文档。 */
    public static HtmlDocument plain(String text) {
        List<Line> lines = new ArrayList<>();
        if (text != null) {
            for (String raw : text.split("\n", -1)) {
                Line line = new Line();
                if (!raw.isEmpty()) {
                    line.spans.add(new Span(raw, DEFAULT_TEXT_COLOR, false, null));
                }
                lines.add(line);
            }
        }
        return new HtmlDocument(lines);
    }

    public static HtmlDocument parseHtml(String html) {
        if (html == null || html.isEmpty()) {
            return new HtmlDocument(new ArrayList<>());
        }
        return HtmlParser.parse(html);
    }

    // ---------------------------------------------------------------- 折行

    /**
     * 按像素宽度折行，保留每个片段的颜色 / 加粗 / 链接。
     *
     * @param maxWidth 每行最大像素宽度
     * @param widthFn  {@code String -> 像素宽}（通常传 {@code Font::width}）
     */
    public List<Line> wrap(int maxWidth, java.util.function.ToIntFunction<String> widthFn) {
        List<Line> result = new ArrayList<>();
        for (Line source : this.lines) {
            if (source.spans.isEmpty()) {
                result.add(new Line());
                continue;
            }
            List<Span> outSpans = new ArrayList<>();
            int lineWidth = 0;
            for (Span span : source.spans) {
                String text = span.text;
                int i = 0;
                while (i < text.length()) {
                    if (lineWidth >= maxWidth) {
                        result.add(new Line(outSpans));
                        outSpans = new ArrayList<>();
                        lineWidth = 0;
                    }
                    int available = maxWidth - lineWidth;
                    int fit = fitPrefix(text, i, available, widthFn);
                    if (fit <= 0) {
                        if (lineWidth == 0) {
                            fit = 1; // 单个字符都放不下：强制放一个，避免死循环
                        } else {
                            result.add(new Line(outSpans));
                            outSpans = new ArrayList<>();
                            lineWidth = 0;
                            continue;
                        }
                    }
                    int end = Math.min(text.length(), i + fit);
                    if (end < text.length()) {
                        int space = text.lastIndexOf(' ', end - 1);
                        if (space > i) {
                            end = space + 1;
                        }
                    }
                    String chunk = text.substring(i, end);
                    outSpans.add(new Span(chunk, span.color, span.bold, span.href));
                    lineWidth += widthFn.applyAsInt(chunk);
                    i = end;
                    if (i < text.length()) {
                        result.add(new Line(outSpans));
                        outSpans = new ArrayList<>();
                        lineWidth = 0;
                        while (i < text.length() && text.charAt(i) == ' ') {
                            i++;
                        }
                    }
                }
            }
            result.add(new Line(outSpans));
        }
        return result;
    }

    /** 二分查找从 {@code start} 起、总宽不超过 {@code available} 的最长前缀长度。 */
    private static int fitPrefix(String text, int start, int available,
                                 java.util.function.ToIntFunction<String> widthFn) {
        int low = 0;
        int high = text.length() - start;
        int best = 0;
        while (low <= high) {
            int mid = (low + high) >>> 1;
            if (widthFn.applyAsInt(text.substring(start, start + mid)) <= available) {
                best = mid;
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- 数据结构

    public static final class Line {
        public final List<Span> spans;

        Line() {
            this(new ArrayList<>());
        }

        Line(List<Span> spans) {
            this.spans = spans;
        }
    }

    public static final class Span {
        public final String text;
        public final int color;
        public final boolean bold;
        public final String href;

        Span(String text, int color, boolean bold, String href) {
            this.text = text;
            this.color = color;
            this.bold = bold;
            this.href = href;
        }
    }

    // ---------------------------------------------------------------- HTML 解析

    private static final class HtmlParser {
        private static final Pattern HEAD = Pattern.compile(
            "(?is)<(script|style|head|title|noscript)[^>]*>.*?</\\1>");
        private static final Pattern COMMENT = Pattern.compile("(?is)<!--.*?-->");
        private static final Pattern TAG = Pattern.compile("(?s)<(/?)([a-zA-Z0-9]+)((?:\\s+[^>]*?)?)/?>");
        private static final Pattern ATTR = Pattern.compile(
            "([a-zA-Z_:][-a-zA-Z0-9_:.]*)\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s\"'>]+))");
        private static final Map<String, Integer> NAMED_COLORS = new HashMap<>();

        static {
            NAMED_COLORS.put("black", 0xFF000000);
            NAMED_COLORS.put("white", 0xFFFFFFFF);
            NAMED_COLORS.put("red", 0xFFFF0000);
            NAMED_COLORS.put("green", 0xFF008000);
            NAMED_COLORS.put("blue", 0xFF0000FF);
            NAMED_COLORS.put("gray", 0xFF808080);
            NAMED_COLORS.put("grey", 0xFF808080);
            NAMED_COLORS.put("silver", 0xFFC0C0C0);
            NAMED_COLORS.put("darkgray", 0xFF404040);
            NAMED_COLORS.put("darkgrey", 0xFF404040);
            NAMED_COLORS.put("lightgray", 0xFFD3D3D3);
            NAMED_COLORS.put("lightgrey", 0xFFD3D3D3);
            NAMED_COLORS.put("yellow", 0xFFFFFF00);
            NAMED_COLORS.put("gold", 0xFFFFD700);
            NAMED_COLORS.put("orange", 0xFFFFA500);
            NAMED_COLORS.put("purple", 0xFF800080);
            NAMED_COLORS.put("pink", 0xFFFFC0CB);
            NAMED_COLORS.put("brown", 0xFFA52A2A);
            NAMED_COLORS.put("cyan", 0xFF00FFFF);
            NAMED_COLORS.put("magenta", 0xFFFF00FF);
            NAMED_COLORS.put("lime", 0xFF00FF00);
            NAMED_COLORS.put("navy", 0xFF000080);
            NAMED_COLORS.put("teal", 0xFF008080);
            NAMED_COLORS.put("maroon", 0xFF800000);
            NAMED_COLORS.put("olive", 0xFF808000);
        }

        static HtmlDocument parse(String html) {
            String body = COMMENT.matcher(html).replaceAll(" ");
            body = HEAD.matcher(body).replaceAll(" ");
            body = body.replaceAll("(?s)<![^>]*>", " ");
            body = body.replaceAll("(?s)<\\?[^>]*>", " ");
            if (body.length() > MAX_CHARS) {
                body = body.substring(0, MAX_CHARS);
            }

            List<Line> out = new ArrayList<>();
            List<Span> spans = new ArrayList<>();
            StringBuilder buffer = new StringBuilder();

            int color = DEFAULT_TEXT_COLOR;
            boolean bold = false;
            String href = null;

            Matcher matcher = TAG.matcher(body);
            int cursor = 0;
            while (matcher.find()) {
                if (matcher.start() > cursor) {
                    buffer.append(body, cursor, matcher.start());
                }
                cursor = matcher.end();
                boolean closing = !matcher.group(1).isEmpty();
                String name = matcher.group(2).toLowerCase(Locale.ROOT);
                String attrText = matcher.group(3) == null ? "" : matcher.group(3);

                if (isHeading(name)) {
                    flushText(spans, buffer, color, bold, href);
                    endLine(out, spans);
                    spans = new ArrayList<>();
                    if (closing) {
                        bold = false;
                        color = DEFAULT_TEXT_COLOR;
                    } else {
                        bold = true;
                        color = HEADING_COLOR;
                    }
                    continue;
                }

                if (isBlock(name) || name.equals("br")) {
                    flushText(spans, buffer, color, bold, href);
                    if (name.equals("li") && !closing) {
                        buffer.append("• ");
                    }
                    if (name.equals("hr")) {
                        if (!spans.isEmpty()) {
                            out.add(new Line(spans));
                            spans = new ArrayList<>();
                        }
                        List<Span> rule = new ArrayList<>();
                        rule.add(new Span("────────────────────────", DEFAULT_TEXT_COLOR, false, null));
                        out.add(new Line(rule));
                    } else {
                        endLine(out, spans);
                        spans = new ArrayList<>();
                    }
                    continue;
                }

                if (name.equals("a")) {
                    flushText(spans, buffer, color, bold, href);
                    if (closing) {
                        href = null;
                        if (color == LINK_COLOR) {
                            color = DEFAULT_TEXT_COLOR;
                        }
                    } else {
                        href = attr(attrText, "href");
                        color = LINK_COLOR;
                    }
                    continue;
                }
                if (name.equals("b") || name.equals("strong")) {
                    flushText(spans, buffer, color, bold, href);
                    bold = !closing;
                    continue;
                }
                if (name.equals("i") || name.equals("em") || name.equals("u") || name.equals("small")
                    || name.equals("big") || name.equals("sub") || name.equals("sup")) {
                    continue; // 字体无真正的斜体/下划线，保留文字即可
                }
                if (name.equals("font") || name.equals("span")) {
                    Matcher attrMatcher = ATTR.matcher(attrText);
                    while (attrMatcher.find()) {
                        String key = attrMatcher.group(1).toLowerCase(Locale.ROOT);
                        String value = firstNonNull(attrMatcher.group(3), attrMatcher.group(4), attrMatcher.group(5));
                        if (value == null) {
                            continue;
                        }
                        if ((key.equals("color")) || key.equals("style")) {
                            int parsed = key.equals("color") ? parseColor(value) : colorFromStyle(value);
                            if (parsed != -1) {
                                flushText(spans, buffer, color, bold, href);
                                color = parsed;
                            }
                        }
                    }
                    continue;
                }
                // 其它标签忽略
            }
            if (cursor < body.length()) {
                buffer.append(body, cursor, body.length());
            }
            flushText(spans, buffer, color, bold, href);
            endLine(out, spans);

            // 去掉首尾空行
            while (!out.isEmpty() && out.get(0).spans.isEmpty()) {
                out.remove(0);
            }
            while (!out.isEmpty() && out.get(out.size() - 1).spans.isEmpty()) {
                out.remove(out.size() - 1);
            }
            return new HtmlDocument(out);
        }

        private static void flushText(List<Span> spans, StringBuilder buffer,
                                      int color, boolean bold, String href) {
            if (buffer.length() == 0) {
                return;
            }
            spans.add(new Span(BrowserPageLoader.decodeEntities(buffer.toString()), color, bold, href));
            buffer.setLength(0);
        }

        private static void endLine(List<Line> out, List<Span> spans) {
            boolean blank = spans.isEmpty();
            if (blank && (out.isEmpty() || out.get(out.size() - 1).spans.isEmpty())) {
                return; // 不重复插入空行
            }
            out.add(new Line(spans));
        }

        private static boolean isBlock(String name) {
            switch (name) {
                case "p":
                case "div":
                case "li":
                case "tr":
                case "ul":
                case "ol":
                case "table":
                case "section":
                case "article":
                case "header":
                case "footer":
                case "blockquote":
                case "pre":
                case "main":
                case "nav":
                case "aside":
                case "h1":
                case "h2":
                case "h3":
                case "h4":
                case "h5":
                case "h6":
                case "hr":
                    return true;
                default:
                    return false;
            }
        }

        private static boolean isHeading(String name) {
            return name.length() == 2 && name.charAt(0) == 'h' && name.charAt(1) >= '1' && name.charAt(1) <= '6';
        }

        private static String attr(String attrText, String name) {
            Matcher matcher = ATTR.matcher(attrText);
            while (matcher.find()) {
                if (matcher.group(1).equalsIgnoreCase(name)) {
                    return firstNonNull(matcher.group(3), matcher.group(4), matcher.group(5));
                }
            }
            return null;
        }

        private static String firstNonNull(String... values) {
            for (String value : values) {
                if (value != null) {
                    return value;
                }
            }
            return null;
        }

        private static int colorFromStyle(String style) {
            for (String part : style.split(";")) {
                int colon = part.indexOf(':');
                if (colon < 0) {
                    continue;
                }
                String key = part.substring(0, colon).trim().toLowerCase(Locale.ROOT);
                if (key.equals("color")) {
                    int parsed = parseColor(part.substring(colon + 1));
                    if (parsed != -1) {
                        return parsed;
                    }
                }
            }
            return -1;
        }

        static int parseColor(String value) {
            if (value == null) {
                return -1;
            }
            String v = value.trim().toLowerCase(Locale.ROOT);
            if (v.isEmpty()) {
                return -1;
            }
            if (v.startsWith("#")) {
                String hex = v.substring(1);
                try {
                    if (hex.length() == 3) {
                        int r = Integer.parseInt(hex.substring(0, 1).repeat(2), 16);
                        int g = Integer.parseInt(hex.substring(1, 2).repeat(2), 16);
                        int b = Integer.parseInt(hex.substring(2, 3).repeat(2), 16);
                        return 0xFF000000 | (r << 16) | (g << 8) | b;
                    }
                    if (hex.length() == 6) {
                        return 0xFF000000 | Integer.parseInt(hex, 16);
                    }
                    if (hex.length() == 8) {
                        return (int) Long.parseLong(hex, 16);
                    }
                } catch (NumberFormatException ignored) {
                    return -1;
                }
                return -1;
            }
            if (v.startsWith("rgb")) {
                int open = v.indexOf('(');
                int close = v.indexOf(')');
                if (open >= 0 && close > open) {
                    String[] parts = v.substring(open + 1, close).split(",");
                    if (parts.length >= 3) {
                        try {
                            int r = clamp(Integer.parseInt(parts[0].trim()));
                            int g = clamp(Integer.parseInt(parts[1].trim()));
                            int b = clamp(Integer.parseInt(parts[2].trim()));
                            return 0xFF000000 | (r << 16) | (g << 8) | b;
                        } catch (NumberFormatException ignored) {
                            return -1;
                        }
                    }
                }
                return -1;
            }
            Integer named = NAMED_COLORS.get(v);
            return named == null ? -1 : named;
        }

        private static int clamp(int value) {
            return Math.max(0, Math.min(255, value));
        }
    }
}
