# V8 Helper 方案

如果 ZL2 游戏 JVM 中出现 `ClassNotFoundException: android.os.Looper` / `Activity=null`，不要继续修改 ZL2。

本版本支持独立 Android WebView Helper：
- Helper 负责真实 Android WebView
- Mod 通过 `127.0.0.1:28765` 获取网页帧
- Mod 仍负责 Minecraft GUI、纹理和白板方块
- 不需要修改 ZL2

先启动 Helper，再启动 Minecraft。
