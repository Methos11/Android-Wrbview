package cn.autoforged.android_browser_mod_1789566815.client.input;

import cn.autoforged.android_browser_mod_1789566815.AndroidWebViewBridge;
import cn.autoforged.android_browser_mod_1789566815.ExampleMod;
import org.lwjgl.glfw.GLFW;

/**
 * Maps Minecraft mouse/keyboard events to Android WebView input.
 *
 * <p>The WebView is at a fixed resolution (e.g. 1024x1024). The BrowserScreen has a content
 * area with arbitrary pixel dimensions on the Minecraft GUI. This class converts Minecraft
 * screen coordinates to WebView viewport coordinates and forwards touch and key events
 * through {@link AndroidWebViewBridge}.
 *
 * <p>Per the skill Phase 4:
 * <ul>
 *   <li>Mouse click → MotionEvent.ACTION_DOWN/UP at the mapped coordinate.</li>
 *   <li>Mouse drag → MotionEvent.ACTION_MOVE.</li>
 *   <li>Scroll → WebView.scrollBy() for page scrolling.</li>
 *   <li>Keyboard → KeyEvent.ACTION_DOWN/UP with appropriate Android keyCode mapping.</li>
 * </ul>
 */
public final class BrowserInputAdapter {
    // Android MotionEvent action constants
    private static final int ACTION_DOWN = 0;
    private static final int ACTION_UP = 1;
    private static final int ACTION_MOVE = 2;
    private static final int ACTION_CANCEL = 3;

    // Content area bounds (set by BrowserScreen on layout)
    private int contentX;
    private int contentY;
    private int contentW;
    private int contentH;

    // Track mouse state
    private boolean mouseDown;
    private float lastWebX;
    private float lastWebY;

    /** Public constructor — created by BrowserScreen. */
    public BrowserInputAdapter() {}

    /**
     * Sets the content area rectangle so that mouse coordinates can be mapped
     * to the WebView's viewport.
     */
    public void setContentBounds(int x, int y, int w, int h) {
        this.contentX = x;
        this.contentY = y;
        this.contentW = Math.max(1, w);
        this.contentH = Math.max(1, h);
    }

    /**
     * Converts a Minecraft screen X to a WebView viewport X.
     */
    public float mapX(double screenX) {
        float ratio = (float) ((screenX - contentX) / contentW);
        return Math.max(0, Math.min(1, ratio)) * AndroidWebViewBridge.viewWidth();
    }

    /**
     * Converts a Minecraft screen Y to a WebView viewport Y.
     */
    public float mapY(double screenY) {
        float ratio = (float) ((screenY - contentY) / contentH);
        return Math.max(0, Math.min(1, ratio)) * AndroidWebViewBridge.viewHeight();
    }

    /** Returns true if the given screen coordinates are inside the content area. */
    public boolean isInContent(double x, double y) {
        return x >= contentX && x < contentX + contentW
            && y >= contentY && y < contentY + contentH;
    }

    // ---------------------------------------------------------------- Mouse / touch

    public void onMouseDown(double screenX, double screenY, int button) {
        if (!AndroidWebViewBridge.attached()) return;
        if (button != 0) return; // only left button for now
        mouseDown = true;
        lastWebX = mapX(screenX);
        lastWebY = mapY(screenY);
        AndroidWebViewBridge.forwardTouch(ACTION_DOWN, lastWebX, lastWebY);
        ExampleMod.LOGGER.debug("[WebView-V8] mouseDown -> touch down at {},{}", lastWebX, lastWebY);
    }

    public void onMouseMove(double screenX, double screenY) {
        if (!AndroidWebViewBridge.attached() || !mouseDown) return;
        lastWebX = mapX(screenX);
        lastWebY = mapY(screenY);
        AndroidWebViewBridge.forwardTouch(ACTION_MOVE, lastWebX, lastWebY);
    }

    public void onMouseUp(double screenX, double screenY, int button) {
        if (!AndroidWebViewBridge.attached()) return;
        if (button != 0) return;
        mouseDown = false;
        lastWebX = mapX(screenX);
        lastWebY = mapY(screenY);
        AndroidWebViewBridge.forwardTouch(ACTION_UP, lastWebX, lastWebY);
    }

    public void onMouseCancel() {
        if (!AndroidWebViewBridge.attached()) return;
        mouseDown = false;
        AndroidWebViewBridge.forwardTouch(ACTION_CANCEL, lastWebX, lastWebY);
    }

    /**
     * Scroll: convert scrollY (in "notches") into pixel deltas and call scrollBy.
     * A positive scrollY means the user scrolled up (content moves down).
     */
    public void onScroll(double scrollY) {
        if (!AndroidWebViewBridge.attached()) return;
        int scrollHeight = AndroidWebViewBridge.viewHeight();
        // Each notch scrolls about 1/8 of the viewport height.
        float delta = (float) (-scrollY * scrollHeight / 8.0f);
        AndroidWebViewBridge.forwardScroll(0, delta);
    }

    // ---------------------------------------------------------------- Keyboard

    /**
     * Maps a GLFW keyCode to an Android keyCode and forwards it.
     *
     * @param glfwKeyCode the GLFW key code (GLFW_KEY_*)
     * @param action      0=PRESS, 1=RELEASE, 2=REPEAT
     * @param ch          the typed character, or '\0' if none
     * @return true if the event was forwarded
     */
    public boolean onKeyEvent(int glfwKeyCode, int action, char ch) {
        if (!AndroidWebViewBridge.attached()) return false;
        int androidKeyCode = mapKeyCode(glfwKeyCode);
        int androidAction;
        int repeat = 0;
        switch (action) {
            case 0: androidAction = 0; break; // ACTION_DOWN
            case 1: androidAction = 1; break; // ACTION_UP
            case 2: androidAction = 0; repeat = 1; break; // ACTION_DOWN with repeat
            default: return false;
        }
        if (androidKeyCode == 0 && ch == '\0') return false;
        AndroidWebViewBridge.forwardKey(androidAction, androidKeyCode, repeat,
            ch != '\0' ? String.valueOf(ch) : null);
        return true;
    }

    /** Maps GLFW key codes to Android KeyEvent key codes. */
    private static int mapKeyCode(int glfwKey) {
        // Only the most useful keys for web browsing are mapped.
        // See android.view.KeyEvent constants.
        switch (glfwKey) {
            case GLFW.GLFW_KEY_ENTER: return 66;       // KEYCODE_ENTER
            case GLFW.GLFW_KEY_BACKSPACE: return 67;   // KEYCODE_DEL
            case GLFW.GLFW_KEY_TAB: return 61;         // KEYCODE_TAB
            case GLFW.GLFW_KEY_ESCAPE: return 111;     // KEYCODE_ESCAPE
            case GLFW.GLFW_KEY_SPACE: return 62;       // KEYCODE_SPACE
            case GLFW.GLFW_KEY_LEFT: return 21;        // KEYCODE_DPAD_LEFT
            case GLFW.GLFW_KEY_RIGHT: return 22;       // KEYCODE_DPAD_RIGHT
            case GLFW.GLFW_KEY_UP: return 19;          // KEYCODE_DPAD_UP
            case GLFW.GLFW_KEY_DOWN: return 20;        // KEYCODE_DPAD_DOWN
            case GLFW.GLFW_KEY_HOME: return 122;       // KEYCODE_MOVE_HOME
            case GLFW.GLFW_KEY_END: return 123;       // KEYCODE_MOVE_END
            case GLFW.GLFW_KEY_PAGE_UP: return 92;    // KEYCODE_PAGE_UP
            case GLFW.GLFW_KEY_PAGE_DOWN: return 93;  // KEYCODE_PAGE_DOWN
            case GLFW.GLFW_KEY_DELETE: return 112;    // KEYCODE_FORWARD_DEL
            case GLFW.GLFW_KEY_LEFT_SHIFT:
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return 59; // KEYCODE_SHIFT_LEFT
            case GLFW.GLFW_KEY_LEFT_CONTROL:
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return 17; // KEYCODE_CTRL_LEFT
            case GLFW.GLFW_KEY_LEFT_ALT:
            case GLFW.GLFW_KEY_RIGHT_ALT: return 57;  // KEYCODE_ALT_LEFT
            // Letters A-Z → KEYCODE_A (29) + offset
            case GLFW.GLFW_KEY_A: return 29;
            case GLFW.GLFW_KEY_B: return 30;
            case GLFW.GLFW_KEY_C: return 31;
            case GLFW.GLFW_KEY_D: return 32;
            case GLFW.GLFW_KEY_E: return 33;
            case GLFW.GLFW_KEY_F: return 34;
            case GLFW.GLFW_KEY_G: return 35;
            case GLFW.GLFW_KEY_H: return 36;
            case GLFW.GLFW_KEY_I: return 37;
            case GLFW.GLFW_KEY_J: return 38;
            case GLFW.GLFW_KEY_K: return 39;
            case GLFW.GLFW_KEY_L: return 40;
            case GLFW.GLFW_KEY_M: return 41;
            case GLFW.GLFW_KEY_N: return 42;
            case GLFW.GLFW_KEY_O: return 43;
            case GLFW.GLFW_KEY_P: return 44;
            case GLFW.GLFW_KEY_Q: return 45;
            case GLFW.GLFW_KEY_R: return 46;
            case GLFW.GLFW_KEY_S: return 47;
            case GLFW.GLFW_KEY_T: return 48;
            case GLFW.GLFW_KEY_U: return 49;
            case GLFW.GLFW_KEY_V: return 50;
            case GLFW.GLFW_KEY_W: return 51;
            case GLFW.GLFW_KEY_X: return 52;
            case GLFW.GLFW_KEY_Y: return 53;
            case GLFW.GLFW_KEY_Z: return 54;
            // Digits 0-9 → KEYCODE_0 (7) + offset
            case GLFW.GLFW_KEY_0: return 7;
            case GLFW.GLFW_KEY_1: return 8;
            case GLFW.GLFW_KEY_2: return 9;
            case GLFW.GLFW_KEY_3: return 10;
            case GLFW.GLFW_KEY_4: return 11;
            case GLFW.GLFW_KEY_5: return 12;
            case GLFW.GLFW_KEY_6: return 13;
            case GLFW.GLFW_KEY_7: return 14;
            case GLFW.GLFW_KEY_8: return 15;
            case GLFW.GLFW_KEY_9: return 16;
            default: return 0; // unmapped
        }
    }
}
