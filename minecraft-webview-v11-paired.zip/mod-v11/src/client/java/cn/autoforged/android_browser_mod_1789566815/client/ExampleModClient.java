package cn.autoforged.android_browser_mod_1789566815.client;

import cn.autoforged.android_browser_mod_1789566815.ExampleMod;
import cn.autoforged.android_browser_mod_1789566815.block.ModBlockEntities;
import cn.autoforged.android_browser_mod_1789566815.block.ScreenBlockClientHooks;
import cn.autoforged.android_browser_mod_1789566815.block.ScreenBlockEntity;
import cn.autoforged.android_browser_mod_1789566815.client.browser.BrowserScreen;
import cn.autoforged.android_browser_mod_1789566815.client.render.ScreenBlockRenderer;
import cn.autoforged.android_browser_mod_1789566815.client.render.WebViewTextureBridge;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.lwjgl.glfw.GLFW;

public class ExampleModClient implements ClientModInitializer {
    /** 自定义按键类别，必须 static final 且只注册一次。 */
    public static final KeyMapping.Category BROWSER_CATEGORY =
        KeyMapping.Category.register(Identifier.fromNamespaceAndPath(ExampleMod.MOD_ID, "browser"));

    public static KeyMapping OPEN_BROWSER;

    @Override
    public void onInitializeClient() {
        // 默认 N 键（原版未占用），可在控制选项中改键
        OPEN_BROWSER = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.android_browser_mod_1789566815.open_browser",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_N,
            BROWSER_CATEGORY
        ));

        // 屏幕方块的正面渲染
        BlockEntityRendererRegistry.register(ModBlockEntities.SCREEN_BLOCK, ScreenBlockRenderer::new);

        // 蹲下右键屏幕方块 -> 打开浏览器窗口，并把窗口绑定到该方块（导航网址会同步上去）
        ScreenBlockClientHooks.OPEN_SCREEN = pos -> {
            Minecraft minecraft = Minecraft.getInstance();
            if (minecraft.gui.screen() != null) {
                return;
            }
            String url = "";
            if (minecraft.level != null) {
                BlockEntity blockEntity = minecraft.level.getBlockEntity(pos);
                if (blockEntity instanceof ScreenBlockEntity screen) {
                    url = screen.getUrl();
                }
            }
            minecraft.gui.setScreen(new BrowserScreen(pos, url));
        };

        WebViewTextureBridge.start();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            WebViewTextureBridge.tick();
            while (OPEN_BROWSER.consumeClick()) {
                if (client.gui.screen() == null) {
                    client.gui.setScreen(new BrowserScreen());
                }
            }
        });

        // 触控设备没有实体键盘，暂停菜单里再放一个入口按钮
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof PauseScreen) {
                Screens.getWidgets(screen).add(Button.builder(
                    Component.translatable("screen.android_browser_mod_1789566815.browser"),
                    button -> client.gui.setScreen(new BrowserScreen())
                ).bounds(6, 6, 120, 20).build());
            }
        });
    }
}
