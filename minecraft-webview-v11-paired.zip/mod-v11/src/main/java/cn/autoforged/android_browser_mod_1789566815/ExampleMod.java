package cn.autoforged.android_browser_mod_1789566815;

import cn.autoforged.android_browser_mod_1789566815.block.ModBlockEntities;
import cn.autoforged.android_browser_mod_1789566815.block.ModBlocks;
import cn.autoforged.android_browser_mod_1789566815.net.ModNetworking;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;

import net.minecraft.resources.Identifier;
import net.minecraft.world.item.CreativeModeTabs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExampleMod implements ModInitializer {
	public static final String MOD_ID = "android_browser_mod_1789566815";

	// This logger is used to write text to the console and the log file.
	// It is considered best practice to use your mod id as the logger's name.
	// That way, it's clear which mod wrote info, warnings, and errors.
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// 注册屏幕方块 / 方块实体 / 屏幕网址同步包（顺序：方块先于方块实体）
		ModBlocks.register();
		ModBlockEntities.register();
		ModNetworking.registerPayloads();
		ModNetworking.registerServerReceivers();

		// 把屏幕方块加入原版「功能方块」创造选项卡
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS)
			.register(output -> output.accept(ModBlocks.SCREEN_BLOCK));

		// 读取/生成配置文件；Android 桥接只使用反射，common 端加载是安全的。
		BrowserConfig config = BrowserConfig.get();
		LOGGER.info("安卓内置浏览器已加载，默认地址 {}，Android 运行环境={}",
			config.defaultUrl, AndroidBrowserBridge.isAndroidRuntime());
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
