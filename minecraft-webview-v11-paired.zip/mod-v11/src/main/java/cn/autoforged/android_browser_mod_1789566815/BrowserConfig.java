package cn.autoforged.android_browser_mod_1789566815;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * 浏览器设置。默认值来自需求规格，玩家可通过 config/android_browser_mod.json 覆盖。
 */
public class BrowserConfig {
    public static final String FILE_NAME = "android_browser_mod.json";

    public String defaultUrl = "https://www.minecraft.net";
    public boolean overlayMode = true;
    public boolean touchOptimized = true;
    public boolean zoomSupport = true;
    public boolean javascriptEnabled = true;
    public boolean cacheEnabled = true;
    public int stackSize = 1;
    public String browserDisplayMode = "floating";
    public String[] allowedDomains = new String[] {"*"};
    /** Phase 5: Maximum WebView texture resolution (width = height, power of 2 recommended). */
    public int maxTextureResolution = 1024;
    /** Phase 5: Default browser window width in Minecraft GUI pixels. */
    public int windowDefaultWidth = 560;
    /** Phase 5: Default browser window height in Minecraft GUI pixels. */
    public int windowDefaultHeight = 420;
    /** Phase 5: Mute audio by default. */
    public boolean audioMuted = false;

    private static BrowserConfig instance;

    public static BrowserConfig get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    public static BrowserConfig load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
        if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                BrowserConfig cfg = new Gson().fromJson(reader, BrowserConfig.class);
                if (cfg != null) {
                    cfg.sanitize();
                    instance = cfg;
                    return cfg;
                }
            } catch (Exception e) {
                ExampleMod.LOGGER.warn("读取浏览器配置失败，使用默认配置", e);
            }
        }
        BrowserConfig cfg = new BrowserConfig();
        instance = cfg;
        cfg.save();
        return cfg;
    }

    public void save() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
        try {
            Files.createDirectories(path.getParent());
            try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
                new GsonBuilder().setPrettyPrinting().create().toJson(this, writer);
            }
        } catch (Exception e) {
            ExampleMod.LOGGER.warn("保存浏览器配置失败", e);
        }
    }

    private void sanitize() {
        if (defaultUrl == null || defaultUrl.isBlank()) {
            defaultUrl = "https://www.minecraft.net";
        }
        if (stackSize < 1) {
            stackSize = 1;
        }
        if (browserDisplayMode == null || browserDisplayMode.isBlank()) {
            browserDisplayMode = "floating";
        }
        if (allowedDomains == null || allowedDomains.length == 0) {
            allowedDomains = new String[] {"*"};
        }
        // Clamp texture resolution to a sane range (256..2048, prefer powers of 2).
        if (maxTextureResolution < 256) maxTextureResolution = 256;
        if (maxTextureResolution > 2048) maxTextureResolution = 2048;
        if (windowDefaultWidth < 300) windowDefaultWidth = 300;
        if (windowDefaultWidth > 1280) windowDefaultWidth = 1280;
        if (windowDefaultHeight < 220) windowDefaultHeight = 220;
        if (windowDefaultHeight > 960) windowDefaultHeight = 960;
    }

    /** 规格默认 all allowed domains，这里仍然实现白名单以便配置受限。 */
    public boolean isDomainAllowed(String host) {
        if (host == null || host.isBlank()) {
            return false;
        }
        String h = host.toLowerCase();
        for (String raw : allowedDomains) {
            if (raw == null) {
                continue;
            }
            String d = raw.trim().toLowerCase();
            if (d.isEmpty()) {
                continue;
            }
            if (d.equals("*") || d.equals("all")) {
                return true;
            }
            if (d.startsWith("*.")) {
                d = d.substring(2);
            }
            if (h.equals(d) || h.endsWith("." + d)) {
                return true;
            }
        }
        return false;
    }
}
