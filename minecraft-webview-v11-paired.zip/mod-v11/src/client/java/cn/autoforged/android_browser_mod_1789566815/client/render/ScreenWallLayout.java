package cn.autoforged.android_browser_mod_1789566815.client.render;

import cn.autoforged.android_browser_mod_1789566815.block.ScreenBlock;
import cn.autoforged.android_browser_mod_1789566815.block.ScreenBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

/**
 * Finds one connected rectangular-ish screen wall. Every block in the same URL/facing-connected
 * component samples a different UV tile from the SAME WebView texture. There is intentionally no
 * per-block page scaling or texture repetition.
 */
public final class ScreenWallLayout {
    public final int minU, maxU, minV, maxV, tileU, tileV;

    private ScreenWallLayout(int minU, int maxU, int minV, int maxV, int tileU, int tileV) {
        this.minU = minU; this.maxU = maxU; this.minV = minV; this.maxV = maxV;
        this.tileU = tileU; this.tileV = tileV;
    }

    public int width() { return maxU - minU + 1; }
    public int height() { return maxV - minV + 1; }

    private record Node(BlockPos pos, int u, int v) {}

    public static ScreenWallLayout find(ScreenBlockEntity origin) {
        if (origin == null || origin.getLevel() == null) return single();
        Direction facing = origin.getBlockState().getValue(ScreenBlock.FACING);
        Direction horizontal = facing.getClockWise();
        String url = origin.getUrl();
        BlockPos start = origin.getBlockPos();

        ArrayDeque<Node> queue = new ArrayDeque<>();
        Set<BlockPos> seen = new HashSet<>();
        queue.add(new Node(start, 0, 0));
        seen.add(start);

        int minU = 0, maxU = 0, minV = 0, maxV = 0;
        final int limit = 32;
        while (!queue.isEmpty()) {
            Node n = queue.removeFirst();
            minU = Math.min(minU, n.u()); maxU = Math.max(maxU, n.u());
            minV = Math.min(minV, n.v()); maxV = Math.max(maxV, n.v());
            tryAdd(origin, url, horizontal, n.pos().relative(horizontal), n.u() + 1, n.v(), limit, queue, seen);
            tryAdd(origin, url, horizontal, n.pos().relative(horizontal, -1), n.u() - 1, n.v(), limit, queue, seen);
            tryAdd(origin, url, horizontal, n.pos().above(), n.u(), n.v() + 1, limit, queue, seen);
            tryAdd(origin, url, horizontal, n.pos().below(), n.u(), n.v() - 1, limit, queue, seen);
        }
        return new ScreenWallLayout(minU, maxU, minV, maxV, -minU, -minV);
    }

    private static void tryAdd(ScreenBlockEntity origin, String url, Direction horizontal, BlockPos pos,
                               int u, int v, int limit, ArrayDeque<Node> queue, Set<BlockPos> seen) {
        if (Math.abs(u) > limit || Math.abs(v) > limit || seen.contains(pos)) return;
        var be = origin.getLevel().getBlockEntity(pos);
        if (!(be instanceof ScreenBlockEntity other)) return;
        if (!other.getBlockState().hasProperty(ScreenBlock.FACING)) return;
        if (other.getBlockState().getValue(ScreenBlock.FACING) != origin.getBlockState().getValue(ScreenBlock.FACING)) return;
        if (!url.equals(other.getUrl())) return;
        seen.add(pos);
        queue.addLast(new Node(pos, u, v));
    }

    private static ScreenWallLayout single() { return new ScreenWallLayout(0, 0, 0, 0, 0, 0); }
}
