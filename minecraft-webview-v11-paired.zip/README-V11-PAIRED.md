# V11 paired build

Helper v11: WebView visual-state-aware frame capture and render-pipeline diagnostics.
Mod v11: Minecraft frame receiver/texture renderer with the vertex-format fix.

ZL2 APK is not modified.
