# WebView Helper V12

Modern adaptive UI, top navigation, colored diagnostics, Render Pipeline diagnostics, native WebView media preview, configurable capture rate/resolution, and GitHub Actions build.

Build in GitHub Actions: `.github/workflows/build.yml`.
