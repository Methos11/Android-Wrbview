package cn.autoforged.android_browser_mod_1789566815.client.browser;

import cn.autoforged.android_browser_mod_1789566815.AndroidBrowserBridge;
import cn.autoforged.android_browser_mod_1789566815.AndroidWebViewBridge;
import cn.autoforged.android_browser_mod_1789566815.BrowserConfig;
import cn.autoforged.android_browser_mod_1789566815.net.SetScreenUrlPayload;
import cn.autoforged.android_browser_mod_1789566815.client.input.BrowserInputAdapter;
import cn.autoforged.android_browser_mod_1789566815.client.render.WebViewTextureBridge;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import org.jspecify.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

/**
 * 悬浮小窗式内置浏览器：
 * <ul>
 *   <li>半透明覆盖层，保留游戏背景可见</li>
 *   <li>可拖动标题栏移动窗口</li>
 *   <li>触控优化的大号导航按钮</li>
 *   <li>Ctrl+滚轮 / 缩放按钮 缩放，滚轮翻页</li>
 *   <li>后台抓取网页并渲染纯文本；"外部打开"走 Android Intent / WebView 桥接</li>
 * </ul>
 */
@Environment(EnvType.CLIENT)
public class BrowserScreen extends Screen {
    private static final int OUTSIDE_BG = 0x50000000;
    private static final int WINDOW_BG = 0xE61B1B24;
    private static final int TITLE_BG = 0xFF2D2D3A;
    private static final int NAV_BG = 0xC0202028;
    private static final int CONTENT_BG = 0xE6F5F5F7;
    private static final int BORDER = 0xFF4DA3FF;
    private static final int MUTED_COLOR = 0xFFB8C7E0;
    private static final int STATUS_BG = 0xE614141B;

    private static final int TITLE_H = 22;
    private static final int NAV_H = 24;
    private static final int STATUS_H = 14;
    private static final int BTN_W = 24;
    private static final int BTN_H = 20;
    private static final int GAP = 2;

    private final BrowserConfig config = BrowserConfig.get();
    private final BrowserPageLoader loader = new BrowserPageLoader(config);

    private int winX;
    private int winY;
    private int winW;
    private int winH;
    private boolean positioned;

    private boolean dragging;
    private boolean contentDragging;
    private double dragAccumulator;
    private int scrollLine;
    private float zoom = 1.0f;

    private EditBox urlBox;
    private Button backBtn;
    private Button forwardBtn;
    private Button reloadBtn;
    private Button homeBtn;
    private Button zoomOutBtn;
    private Button zoomInBtn;
    private Button externalBtn;
    private Button closeBtn;
    private Button debugBtn;
    private Button muteBtn;
    private boolean debugOpen;

    /** Phase 4: Input adapter for forwarding mouse/keyboard events to the Android WebView. */
    private final BrowserInputAdapter inputAdapter = new BrowserInputAdapter();

    private final List<String> history = new ArrayList<>();
    private int historyIndex = -1;

    private String currentUrl = "";
    private String pageText = "";
    private String pageTitle = "";
    private String status = "输入网址后回车；点 E 用系统浏览器打开";
    private boolean loading;

    /** 若是从屏幕方块打开的窗口，导航时把网址同步回该方块。 */
    private final @Nullable BlockPos boundBlock;

    private HtmlDocument pageDocument = HtmlDocument.plain("");
    private List<HtmlDocument.Line> wrapped = new ArrayList<>();
    private int wrappedWidth = -1;
    private boolean initialLoadStarted;

    public BrowserScreen() {
        this(null, "");
    }

    public BrowserScreen(@Nullable BlockPos boundBlock, String initialUrl) {
        super(Component.translatable("screen.android_browser_mod_1789566815.browser"));
        this.boundBlock = boundBlock;
        if (initialUrl != null && !initialUrl.isBlank()) {
            this.currentUrl = initialUrl;
            this.status = "已绑定屏幕方块，导航网址会显示在方块上";
        }
    }

    // ---------------------------------------------------------------- 初始化 / 布局

    @Override
    protected void init() {
        super.init();

        int targetW = Math.min(config.windowDefaultWidth, Math.max(300, this.width - 32));
        int targetH = Math.min(config.windowDefaultHeight, Math.max(220, this.height - 64));
        winW = targetW;
        winH = targetH;
        if (!positioned) {
            winX = Math.max(4, (this.width - winW) / 2);
            winY = Math.max(4, (this.height - winH) / 2);
            positioned = true;
        }
        clampWindow();

        String initial = urlBox != null
            ? urlBox.getValue()
            : (currentUrl.isEmpty() ? config.defaultUrl : currentUrl);

        urlBox = new EditBox(this.font, 0, 0, 100, BTN_H - 2,
            Component.translatable("screen.android_browser_mod_1789566815.url"));
        urlBox.setMaxLength(2048);
        urlBox.setValue(initial);
        addRenderableWidget(urlBox);

        backBtn = addRenderableWidget(Button.builder(Component.literal("<"), b -> goBack())
            .bounds(0, 0, BTN_W, BTN_H).tooltip(tip("back")).build());
        forwardBtn = addRenderableWidget(Button.builder(Component.literal(">"), b -> goForward())
            .bounds(0, 0, BTN_W, BTN_H).tooltip(tip("forward")).build());
        reloadBtn = addRenderableWidget(Button.builder(Component.literal("R"), b -> reload())
            .bounds(0, 0, BTN_W, BTN_H).tooltip(tip("reload")).build());
        homeBtn = addRenderableWidget(Button.builder(Component.literal("H"), b -> home())
            .bounds(0, 0, BTN_W, BTN_H).tooltip(tip("home")).build());
        zoomOutBtn = addRenderableWidget(Button.builder(Component.literal("-"), b -> setZoom(zoom - 0.2f))
            .bounds(0, 0, BTN_W, BTN_H).tooltip(tip("zoom_out")).build());
        zoomInBtn = addRenderableWidget(Button.builder(Component.literal("+"), b -> setZoom(zoom + 0.2f))
            .bounds(0, 0, BTN_W, BTN_H).tooltip(tip("zoom_in")).build());
        externalBtn = addRenderableWidget(Button.builder(Component.literal("E"), b -> openExternal())
            .bounds(0, 0, BTN_W, BTN_H).tooltip(tip("external")).build());
        closeBtn = addRenderableWidget(Button.builder(Component.literal("X"), b -> onClose())
            .bounds(0, 0, BTN_W, BTN_H).tooltip(tip("close")).build());
        debugBtn = addRenderableWidget(Button.builder(Component.literal("D"), b -> debugOpen = !debugOpen)
            .bounds(0, 0, BTN_W, BTN_H).tooltip(Tooltip.create(Component.literal("WebView Debug"))).build());
        muteBtn = addRenderableWidget(Button.builder(Component.literal("M"), b -> {
            WebViewTextureBridge.toggleMute();
            status = WebViewTextureBridge.audioMuted() ? "音频已静音" : "音频已恢复";
        }).bounds(0, 0, BTN_W, BTN_H).tooltip(tip("mute")).build());

        layout();
        setInitialFocus(urlBox);

        if (!initialLoadStarted) {
            initialLoadStarted = true;
            navigateTo(initial, true);
        }
        rebuildWrapped();
    }

    private void layout() {
        int navY = winY + TITLE_H + 3;
        int buttonY = navY + (NAV_H - BTN_H) / 2;

        int x = winX + 4;
        backBtn.setPosition(x, buttonY);
        x += BTN_W + GAP;
        forwardBtn.setPosition(x, buttonY);
        x += BTN_W + GAP;
        reloadBtn.setPosition(x, buttonY);
        x += BTN_W + GAP;
        homeBtn.setPosition(x, buttonY);
        x += BTN_W + 6;

        // 6 right-side buttons: zoomOut, zoomIn, external, debug, mute, close
        int rightStart = winX + winW - 4 - (BTN_W * 6 + GAP * 5);
        int urlWidth = Math.max(40, rightStart - 8 - x);

        urlBox.setX(x);
        urlBox.setY(buttonY + 1);
        urlBox.setWidth(urlWidth);
        urlBox.setHeight(BTN_H - 2);

        int rx = rightStart;
        zoomOutBtn.setPosition(rx, buttonY);
        rx += BTN_W + GAP;
        zoomInBtn.setPosition(rx, buttonY);
        rx += BTN_W + GAP;
        externalBtn.setPosition(rx, buttonY);
        rx += BTN_W + GAP;
        debugBtn.setPosition(rx, buttonY);
        rx += BTN_W + GAP;
        muteBtn.setPosition(rx, buttonY);
        rx += BTN_W + GAP;
        closeBtn.setPosition(rx, buttonY);

        // Phase 4: Update content area bounds for input mapping.
        int contentY = winY + TITLE_H + 3 + NAV_H + 2;
        int contentW = winW - 8;
        int contentH = winH - (TITLE_H + 3 + NAV_H + 4) - STATUS_H - 2;
        inputAdapter.setContentBounds(winX + 4, contentY, contentW, Math.max(10, contentH));
    }

    private void clampWindow() {
        winX = Math.max(2, Math.min(winX, this.width - winW - 2));
        winY = Math.max(2, Math.min(winY, this.height - winH - 2));
    }

    @Override
    public void resize(int width, int height) {
        super.resize(width, height);
        // 记录拖动后的相对位置，避免初始化逻辑重置
        positioned = true;
    }

    // ---------------------------------------------------------------- 导航

    private void navigateTo(String input, boolean record) {
        String url = normalizeUrl(input);
        if (url.isEmpty()) {
            return;
        }
        String host = hostOf(url);
        if (host != null && !config.isDomainAllowed(host)) {
            status = "该域名被配置禁用: " + host;
            return;
        }
        loadUrl(url, false, record);
    }

    private void loadUrl(String url, boolean forceReload, boolean record) {
        if (record) {
            pushHistory(url);
        }
        currentUrl = url;
        // Android path: Chromium/WebView becomes the primary renderer. The legacy parser remains
        // as a desktop/fallback path and for status/search metadata.
        if (AndroidWebViewBridge.isAndroidRuntime()) {
            WebViewTextureBridge.load(url);
        }
        if (urlBox != null) {
            urlBox.setValue(url);
        }
        loading = true;
        status = "加载中... " + url;
        syncToScreenBlock(url);
        loader.load(url, !forceReload, result -> {
            if (this.minecraft == null) {
                return;
            }
            this.minecraft.execute(() -> {
                if (this.minecraft.gui.screen() != this) {
                    return;
                }
                loading = false;
                if (result.error != null) {
                    pageText = "";
                    pageDocument = HtmlDocument.plain("");
                    pageTitle = "";
                    status = "加载失败: " + result.error;
                } else {
                    pageText = result.text;
                    pageDocument = result.document;
                    pageTitle = result.title;
                    status = (result.fromCache ? "[缓存] " : "[网络] ") + result.url
                        + "  (" + pageText.length() + " 字)";
                }
                scrollLine = 0;
                wrappedWidth = -1;
                rebuildWrapped();
            });
        });
    }

    /** 把当前网址同步到绑定的屏幕方块（需要服务器已连接）。 */
    private void syncToScreenBlock(String url) {
        if (boundBlock == null || this.minecraft == null || url.isEmpty()) {
            return;
        }
        if (this.minecraft.getConnection() == null) {
            return;
        }
        ClientPlayNetworking.send(new SetScreenUrlPayload(boundBlock, url));
    }

    private void goBack() {
        if (historyIndex > 0) {
            historyIndex--;
            loadUrl(history.get(historyIndex), false, false);
        }
    }

    private void goForward() {
        if (historyIndex >= 0 && historyIndex < history.size() - 1) {
            historyIndex++;
            loadUrl(history.get(historyIndex), false, false);
        }
    }

    private void reload() {
        if (!currentUrl.isEmpty()) {
            loadUrl(currentUrl, true, false);
        } else {
            navigateTo(urlBox == null ? config.defaultUrl : urlBox.getValue(), true);
        }
    }

    private void home() {
        navigateTo(config.defaultUrl, true);
    }

    private void openExternal() {
        String url = urlBox != null && !urlBox.getValue().isBlank()
            ? normalizeUrl(urlBox.getValue())
            : currentUrl;
        if (url.isEmpty()) {
            return;
        }
        if (AndroidBrowserBridge.openExternal(url)) {
            status = "已请求系统浏览器 / WebView 打开: " + url;
        } else {
            status = "外部打开失败，可在窗口内阅读纯文本内容";
        }
    }

    private void pushHistory(String url) {
        if (historyIndex >= 0 && historyIndex < history.size() && history.get(historyIndex).equals(url)) {
            return;
        }
        while (history.size() > historyIndex + 1) {
            history.remove(history.size() - 1);
        }
        history.add(url);
        historyIndex = history.size() - 1;
    }

    private static String normalizeUrl(String input) {
        String value = input == null ? "" : input.trim();
        if (value.isEmpty()) {
            return "";
        }
        if (!value.contains("://")) {
            value = "https://" + value;
        }
        return value;
    }

    private static String hostOf(String url) {
        try {
            return new URI(url).getHost();
        } catch (Exception e) {
            return null;
        }
    }

    // ---------------------------------------------------------------- 缩放 / 滚动

    private void setZoom(float value) {
        float next = Math.max(0.5f, Math.min(2.5f, value));
        if (next != zoom) {
            zoom = next;
            wrappedWidth = -1;
            rebuildWrapped();
        }
    }

    private void rebuildWrapped() {
        int contentW = Math.max(20, winW - 8);
        int wrapWidth = Math.max(20, (int) ((contentW - 8) / Math.max(0.5f, zoom)));
        if (wrapWidth == wrappedWidth) {
            return;
        }
        wrappedWidth = wrapWidth;
        wrapped = pageDocument.wrap(wrapWidth, s -> this.font.width(s));
        clampScroll();
    }

    private void clampScroll() {
        int max = Math.max(0, wrapped.size() - 1);
        if (scrollLine < 0) {
            scrollLine = 0;
        }
        if (scrollLine > max) {
            scrollLine = max;
        }
    }

    // ---------------------------------------------------------------- 输入事件

    /** Returns true if the Android WebView is actively rendering content. */
    private boolean isWebViewActive() {
        return AndroidBrowserBridge.isAndroidRuntime() && WebViewTextureBridge.ready();
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            if (isOnTitleBar(event.x(), event.y())) {
                dragging = true;
                return true;
            }
            if (isInContent(event.x(), event.y())) {
                if (isWebViewActive()) {
                    // Phase 4: forward mouse click to the Android WebView as a touch event.
                    inputAdapter.onMouseDown(event.x(), event.y(), 0);
                    return true;
                }
                // 鼠标 / 触屏按住内容区拖动即可滑动页面（移动端主要靠这个）
                contentDragging = true;
                dragAccumulator = 0.0;
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragging) {
            winX += (int) dx;
            winY += (int) dy;
            clampWindow();
            layout();
            return true;
        }
        if (isWebViewActive() && inputAdapter.isInContent(event.x(), event.y())) {
            // Phase 4: forward drag as touch move to the WebView.
            inputAdapter.onMouseMove(event.x(), event.y());
            return true;
        }
        if (contentDragging) {
            double lineHeight = Math.max(4.0, 9.0 * zoom);
            dragAccumulator += dy;
            int steps = (int) (dragAccumulator / lineHeight);
            if (steps != 0) {
                dragAccumulator -= steps * lineHeight;
                scrollLine -= steps;
                clampScroll();
            }
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (event.button() == 0) {
            if (dragging) {
                dragging = false;
                return true;
            }
            if (isWebViewActive()) {
                // Phase 4: forward mouse release as touch up to the WebView.
                if (inputAdapter.isInContent(event.x(), event.y())) {
                    inputAdapter.onMouseUp(event.x(), event.y(), 0);
                } else {
                    inputAdapter.onMouseCancel();
                }
                return true;
            }
            if (contentDragging) {
                contentDragging = false;
                return true;
            }
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double scrollX, double scrollY) {
        if (isInContent(x, y)) {
            if (isWebViewActive()) {
                // Phase 4: forward scroll to the WebView for native page scrolling.
                inputAdapter.onScroll(scrollY);
                return true;
            }
            boolean zoomModifier = config.zoomSupport
                && InputConstants.isKeyDown(this.minecraft.getWindow(), GLFW.GLFW_KEY_LEFT_CONTROL);
            if (zoomModifier) {
                setZoom(zoom + (float) scrollY * 0.1f);
            } else {
                int step = (int) Math.signum(scrollY) * 3;
                scrollLine -= step;
                clampScroll();
            }
            return true;
        }
        return super.mouseScrolled(x, y, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.isEscape()) {
            onClose();
            return true;
        }
        if (urlBox != null && urlBox.isFocused()
            && (event.key() == GLFW.GLFW_KEY_ENTER || event.key() == GLFW.GLFW_KEY_KP_ENTER)) {
            urlBox.setFocused(false);
            navigateTo(urlBox.getValue(), true);
            return true;
        }
        // Phase 4: Forward keyboard events to the WebView when the URL box is not focused.
        if (isWebViewActive() && (urlBox == null || !urlBox.isFocused())) {
            // Determine action: GLFW_PRESS=1, GLFW_RELEASE=0, GLFW_REPEAT=2
            int action = 1; // default to press; 26.2 KeyEvent may not expose action directly
            inputAdapter.onKeyEvent(event.key(), action, '\0');
            // Still call super for Minecraft-level handling, but return true to consume.
            super.keyPressed(event);
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        // Minecraft 26.2 uses CharacterEvent instead of (char, modifiers).
        // Forward the Unicode code point to the Android WebView input bridge.
        char ch = (char) event.codepoint();
        if (isWebViewActive() && (urlBox == null || !urlBox.isFocused())) {
            inputAdapter.onKeyEvent(0, 0, ch);
            return true;
        }
        return super.charTyped(event);
    }

    private boolean isOnTitleBar(double x, double y) {
        return x >= winX && x <= winX + winW && y >= winY && y <= winY + TITLE_H;
    }

    private boolean isInContent(double x, double y) {
        int contentY = winY + TITLE_H + 3 + NAV_H + 2;
        int contentH = winH - (TITLE_H + 3 + NAV_H + 4) - STATUS_H - 2;
        return x >= winX + 4 && x <= winX + winW - 4
            && y >= contentY && y <= contentY + Math.max(10, contentH);
    }

    // ---------------------------------------------------------------- 渲染

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        // 不调用 super：避免原版模糊/全景背景，保留游戏世界可见（半透明覆盖层）
        graphics.fill(0, 0, this.width, this.height, OUTSIDE_BG);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        drawFrame(graphics);
        drawContent(graphics);
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        if (debugOpen) drawDebugPanel(graphics);
        drawStatusBar(graphics);
    }

    private void drawFrame(GuiGraphicsExtractor graphics) {
        graphics.fill(winX, winY, winX + winW, winY + winH, WINDOW_BG);
        graphics.outline(winX, winY, winW, winH, BORDER);

        graphics.fill(winX, winY, winX + winW, winY + TITLE_H, TITLE_BG);
        graphics.fill(winX + 1, winY + TITLE_H - 1, winX + winW - 1, winY + TITLE_H, 0xFF4DA3FF);
        String title = pageTitle == null || pageTitle.isBlank() ? "安卓内置浏览器" : pageTitle;
        int available = winW - 12;
        graphics.text(this.font, this.font.plainSubstrByWidth(title, available),
            winX + 6, winY + 7, 0xFFFFFFFF, false);

        int navY = winY + TITLE_H + 3;
        graphics.fill(winX + 2, navY, winX + winW - 2, navY + NAV_H, NAV_BG);
    }

    private void drawContent(GuiGraphicsExtractor graphics) {
        int contentX = winX + 4;
        int contentY = winY + TITLE_H + 3 + NAV_H + 2;
        int contentW = winW - 8;
        int contentH = winH - (TITLE_H + 3 + NAV_H + 4) - STATUS_H - 2;
        if (contentH < 10) {
            contentH = 10;
        }
        graphics.fill(contentX, contentY, contentX + contentW, contentY + contentH, CONTENT_BG);
        graphics.outline(contentX, contentY, contentW, contentH, 0x55202028);

        // Android：直接显示 Chromium 帧，CSS / 图片 / JS 不再经过 HtmlDocument。
        if (isWebViewActive()) {
            int texSize = WebViewTextureBridge.textureSize();
            graphics.enableScissor(contentX, contentY, contentX + contentW, contentY + contentH);
            graphics.blit(RenderPipelines.GUI_TEXTURED, WebViewTextureBridge.textureId(),
                contentX, contentY, 0, 0, contentW, contentH,
                texSize, texSize);
            graphics.disableScissor();
            drawScrollbar(graphics, contentX, contentY, contentW, contentH);
            return;
        }

        // 折行已在 init / 缩放 / 加载完成时重算，渲染阶段不再做副作用。

        // 逻辑行高固定 9px；折行宽度 = (内容宽)/zoom，绘制时整体按 zoom 缩放，
        // 这样缩放才真正改变字号而不是只改折行宽度（否则 zoom<100% 文本会溢出被裁剪）。
        final int lineStep = 9;
        int maxLines = Math.max(1, (int) ((contentH - 6) / Math.max(1.0f, lineStep * zoom)));

        graphics.enableScissor(contentX, contentY, contentX + contentW, contentY + contentH);
        graphics.pose().pushMatrix();
        graphics.pose().translate(contentX, contentY);
        graphics.pose().scale(zoom, zoom);
        if (pageDocument.isEmpty()) {
            String hint = loading ? "正在加载..." : "（无内容）";
            graphics.text(this.font, hint, 6, 4, 0xFF6A6A78, false);
        } else {
            for (int i = 0; i < maxLines; i++) {
                int index = scrollLine + i;
                if (index < 0 || index >= wrapped.size()) {
                    break;
                }
                drawLine(graphics, wrapped.get(index), 4, 3 + i * lineStep);
            }
        }
        graphics.pose().popMatrix();
        graphics.disableScissor();

        drawScrollbar(graphics, contentX, contentY, contentW, contentH);
    }

    /** 逐片段绘制一行，保留颜色与加粗（内联 CSS / 标题 / 链接）。 */
    private void drawLine(GuiGraphicsExtractor graphics, HtmlDocument.Line line, int x, int y) {
        int cursorX = x;
        for (HtmlDocument.Span span : line.spans) {
            if (span.text.isEmpty()) {
                continue;
            }
            if (span.bold) {
                Component text = Component.literal(span.text)
                    .withStyle(Style.EMPTY.withColor(span.color).withBold(true));
                graphics.text(this.font, text, cursorX, y, 0xFFFFFFFF, false);
            } else {
                graphics.text(this.font, span.text, cursorX, y, span.color, false);
            }
            cursorX += this.font.width(span.text);
        }
    }

    private void drawScrollbar(GuiGraphicsExtractor graphics, int x, int y, int w, int h) {
        if (wrapped.size() <= 1) {
            return;
        }
        int barX = x + w - 4;
        int trackH = h - 4;
        int visibleLines = Math.max(1, (int) ((h - 6) / Math.max(1.0f, 9.0f * zoom)));
        int thumbH = Math.max(10, trackH * visibleLines / wrapped.size());
        int thumbY = y + 2 + (int) ((long) (trackH - thumbH) * scrollLine / Math.max(1, wrapped.size() - 1));
        graphics.fill(barX, y + 2, barX + 2, y + 2 + trackH, 0x33000000);
        graphics.fill(barX, thumbY, barX + 2, thumbY + thumbH, 0xAA4DA3FF);
    }

    private void drawDebugPanel(GuiGraphicsExtractor graphics) {
        int x = winX + 8;
        int y = winY + TITLE_H + NAV_H + 10;
        int w = winW - 16;
        int h = winH - TITLE_H - NAV_H - STATUS_H - 18;
        if (h < 40) return;

        graphics.fill(x, y, x + w, y + h, 0xF5101118);
        graphics.outline(x, y, w, h, 0xFF55B7FF);
        graphics.text(this.font, Component.literal("WebView Debug / 运行诊断"),
            x + 7, y + 6, 0xFFFFFFFF, true);

        int lineY = y + 19;
        // V8 (ZL2ac): show which Android process/context the mod resolved. A non-null
        // Application with mode=APPLICATION(degraded) means the WebView is alive but the
        // game JVM could not reach an Activity — the expected state on ZL2's ":game"/":jvm"
        // processes. mode=NONE means we are not inside an Android app at all.
        int contextColor = AndroidWebViewBridge.isDegraded() ? 0xFFFFC46B : 0xFF8FE38F;
        for (String part : splitDebug(AndroidBrowserBridge.contextDiagnostics(), Math.max(20, w - 14))) {
            if (lineY > y + h - 12) break;
            graphics.text(this.font, part, x + 7, lineY, contextColor, false);
            lineY += 9;
        }

        lineY += 2;
        String summary = AndroidWebViewBridge.debugSummary();
        for (String part : splitDebug(summary, Math.max(20, w - 14))) {
            if (lineY > y + h - 12) break;
            graphics.text(this.font, part, x + 7, lineY, 0xFFB8C7E0, false);
            lineY += 9;
        }

        lineY += 3;
        graphics.fill(x + 5, lineY - 2, x + w - 5, lineY - 1, 0x553A5168);
        lineY += 3;

        String[] logs = AndroidWebViewBridge.debugLogSnapshot();
        if (logs.length == 0) {
            graphics.text(this.font, "暂无诊断日志", x + 7, lineY, 0xFF9AA4B2, false);
            return;
        }
        for (String log : logs) {
            if (lineY > y + h - 10) break;
            for (String part : splitDebug(log, Math.max(20, w - 14))) {
                if (lineY > y + h - 10) break;
                int color = part.startsWith("ERROR") ? 0xFFFF8080 : 0xFFD5DCE5;
                graphics.text(this.font, part, x + 7, lineY, color, false);
                lineY += 9;
            }
        }
    }

    private List<String> splitDebug(String text, int maxWidth) {
        List<String> result = new ArrayList<>();
        if (text == null || text.isEmpty()) return result;
        String remaining = text;
        while (!remaining.isEmpty()) {
            String part = this.font.plainSubstrByWidth(remaining, maxWidth);
            if (part == null || part.isEmpty()) break;
            result.add(part);
            if (part.length() >= remaining.length()) break;
            remaining = remaining.substring(part.length());
        }
        return result;
    }

    private void drawStatusBar(GuiGraphicsExtractor graphics) {
        int statusY = winY + winH - STATUS_H;
        graphics.fill(winX, statusY, winX + winW, winY + winH, STATUS_BG);
        graphics.fill(winX + 1, statusY, winX + winW - 1, statusY + 1, 0x554DA3FF);
        int zoomWidth = this.font.width(zoomLabel());
        int maxStatus = Math.max(20, winW - 12 - zoomWidth - 6);
        graphics.text(this.font, this.font.plainSubstrByWidth(status, maxStatus),
            winX + 5, statusY + 3, MUTED_COLOR, false);
        graphics.text(this.font, zoomLabel(),
            winX + winW - 5 - zoomWidth, statusY + 3, MUTED_COLOR, false);
    }

    private String zoomLabel() {
        return Math.round(zoom * 100) + "%";
    }

    /** 导航按钮的悬浮说明，避免只看到单个字母不知道含义。 */
    private static Tooltip tip(String key) {
        return Tooltip.create(Component.translatable(
            "screen.android_browser_mod_1789566815.tip." + key));
    }

    @Override
    public boolean isPauseScreen() {
        // 普通浏览暂停游戏以降低移动端负载；绑定屏幕方块时需保持服务器运行，
        // 否则网址同步包要等关窗才被处理，方块无法实时更新。
        return boundBlock == null;
    }

    @Override
    public void removed() {
        loader.shutdown();
        super.removed();
    }
}
