# WebView Mod V11 Render Fix

This revision targets the Minecraft 26.2 client render crash:
`IllegalStateException: Missing elements in vertex` in `ScreenBlockRenderer.submit`.

## Render fix
`RenderTypes.entitySolid(...)` uses a vertex format that includes overlay data. The custom quad now supplies `.setOverlay(0)` for every vertex, completing the vertex before the next vertex is started.

This is a Mod-side fix only; ZL2 itself is not modified.

## WebView pipeline
The Mod still receives the WebView frame through the existing bridge and uploads it on the Minecraft client thread. The Helper-side visual-state/onDraw changes belong to the separate Helper package.

## Build note
Build was not completed in this environment because the Gradle 9.5.1 distribution could not be downloaded (network/DNS unavailable). The source change itself is limited to the renderer vertex attributes and does not require an Android SDK.
