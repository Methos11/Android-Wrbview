# Minecraft WebView Helper v9 — Modern Diagnostics

Modern Android Helper for the Minecraft/ZL2 local WebView bridge.

## Build

The project root contains `gradlew`. It first uses an installed Gradle/Code FA Gradle environment. If none is available, the portable bootstrap downloads Gradle 9.5.1 to `~/.gradle/portable-wrapper` and runs it.

```bash
bash gradlew clean assembleDebug
```

Internet access is required only for the first bootstrap download if Gradle is not already installed/cached.

## Main features

- modern sliding navigation UI
- WebView preview before launching Minecraft
- HTML/CSS/JS/image/video/font/iframe diagnostics
- page progress/title/URL reporting
- JS console and resource/HTTP error logging
- live debug overlay
- copy/exportable runtime logs
- start/stop local helper service
- localhost port 28765 status
- configurable capture FPS and resolution
- local diagnostic assets

## Important

The `gradle/wrapper/gradle-wrapper.properties` file records the intended Gradle distribution. The `gradlew` script is a portable bootstrap for environments such as Proot/Code FA where a system Gradle installation may be absent.
