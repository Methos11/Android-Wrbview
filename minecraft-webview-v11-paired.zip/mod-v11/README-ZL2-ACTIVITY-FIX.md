# WebView V6.2 — ZL2 Activity Fix

针对 Zalith Launcher 2 (ZL2) 的 WebView Activity 获取修正版。

## 本次修改
- 增加 ZL2 MainActivity 类路径：`com.movtery.zalithlauncher.ui.activities.MainActivity`
- 增加 Pojav/ZL2 常见 View/Context 字段探测与静态字段扫描。
- 增加 ContextWrapper -> Activity 链式解析。
- 修复 Fabric 客户端初始化早于 Android 游戏 Activity 建立时“一次检测失败永久禁用”的问题。
- WebView Activity 最多重试约 5 秒。
- 屏幕纹理继续强制 alpha=255，加载期间保持纯白不透明。

## 测试日志
如果成功，应看到类似：

`[WebView-V6] Android WebView capability detected; Activity=...`

以及：

`[WebView-V6] created size=1024x1024 attached=true activityContext=true`

本环境无法联网获取 Gradle 9.5.1，因此未完成本地 Gradle 构建验证。
