package cn.autoforged.android_browser_mod_1789566815.client.browser;

import cn.autoforged.android_browser_mod_1789566815.BrowserConfig;
import net.minecraft.client.gui.Font;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 屏幕方块内容的客户端缓存：按 URL 抓取一次，折叠成可画在方块正面上的行。
 *
 * <p>抓取在 {@link BrowserPageLoader} 的后台线程进行，渲染线程只读 volatile 字段，
 * 抓完后的下一帧自动出现内容，不需要额外刷新通知。
 */
public final class ScreenBlockContentCache {
    /** 方块正面约 96 像素宽（1 格 / 文字缩放 1/96），留边距后取 88。 */
    private static final int WRAP_WIDTH = 88;
    private static final int MAX_LINES = 10;

    private static final BrowserPageLoader LOADER = new BrowserPageLoader(BrowserConfig.get());
    private static final Map<String, Entry> CACHE = new ConcurrentHashMap<>();

    private ScreenBlockContentCache() {
    }

    public static boolean isLoading(String url) {
        Entry entry = url == null ? null : CACHE.get(url);
        return entry != null && entry.loading;
    }

    public static String title(String url) {
        Entry entry = url == null ? null : CACHE.get(url);
        return entry == null ? "" : entry.title;
    }

    /** 取（必要时触发抓取）某 URL 的缓存条目。 */
    public static Entry entry(String url) {
        if (url == null || url.isBlank()) {
            return null;
        }
        return CACHE.computeIfAbsent(url, key -> {
            Entry entry = new Entry();
            LOADER.load(key, true, result -> {
                if (result.error != null) {
                    entry.error = result.error;
                } else {
                    entry.title = result.title;
                    entry.text = result.text;
                }
                entry.loading = false;
            });
            return entry;
        });
    }

    /** 取按方块正面宽度折好的行；未加载完成时返回空表。 */
    public static List<String> lines(String url, Font font) {
        Entry entry = entry(url);
        if (entry == null || entry.loading || entry.text == null || entry.text.isEmpty()) {
            return List.of();
        }
        List<String> wrapped = entry.wrapped;
        if (wrapped == null) {
            List<String> all = BrowserPageLoader.wrapText(entry.text, WRAP_WIDTH, font::width);
            wrapped = all.size() > MAX_LINES ? new ArrayList<>(all.subList(0, MAX_LINES)) : all;
            entry.wrapped = wrapped;
        }
        return wrapped;
    }

    /** 单条缓存的可见字段（后台线程写，渲染线程读）。 */
    public static final class Entry {
        volatile String title = "";
        volatile String text = "";
        volatile String error;
        volatile boolean loading = true;
        volatile List<String> wrapped;
    }
}
