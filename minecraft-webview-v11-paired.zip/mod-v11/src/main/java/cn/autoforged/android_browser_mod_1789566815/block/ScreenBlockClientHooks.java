package cn.autoforged.android_browser_mod_1789566815.block;

import net.minecraft.core.BlockPos;

import java.util.function.Consumer;

/**
 * 主代码 -> 客户端代码的桥。
 *
 * <p>{@link ScreenBlock} 位于 {@code src/main}（物理服务端也会加载），不能直接引用
 * {@code net.minecraft.client.*}。客户端在 {@code ClientModInitializer} 里把真正的开窗逻辑
 * 塞进 {@link #OPEN_SCREEN}，方块只在 {@code level.isClientSide()} 为真时调用。
 */
public final class ScreenBlockClientHooks {
    /** 默认空实现，纯服务端/未初始化客户端时安全。 */
    public static volatile Consumer<BlockPos> OPEN_SCREEN = pos -> {
    };

    private ScreenBlockClientHooks() {
    }

    public static void open(BlockPos pos) {
        OPEN_SCREEN.accept(pos);
    }
}
