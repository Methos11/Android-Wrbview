# Minecraft WebView Helper v11 — Render Pipeline

配套 Mod：android_browser_mod-webview-v8-helper-mod-renderfix-v11

核心链路：
WebView → postVisualStateCallback → UI-thread onDraw(Canvas) → Bitmap → PNG /frame → Minecraft Mod → DynamicTexture

新增诊断：
- /frameinfo
- status 中的 pipeline / visual / attached / frame_bytes
- VISUAL_READY / DRAWING / BITMAP_READY / FRAME_READY 状态
- 保留 CSS / JS / image / video / font / HTTP / resource 诊断

注意：首次构建仍需要 Android SDK。JDK 25 与 Gradle Wrapper 不能替代 Android SDK。
