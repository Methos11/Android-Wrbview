# WebView Helper V13 — GitHub Codespaces / Web Terminal

这是专门整理给手机浏览器 + GitHub Codespaces 使用的 Android APK 构建包。

## 目录结构

- `gradlew`：Gradle Wrapper
- `app/`：Android App
- `settings.gradle`：Gradle 根项目
- `build.gradle`：根构建脚本
- `gradle/wrapper/`：完整 Wrapper（包含 gradle-wrapper.jar）

## 在 Codespaces 中构建 APK

### 1. 上传 ZIP

把这个 ZIP 上传到 GitHub 仓库，或者在 Codespaces 的 Explorer 上传。

### 2. 解压

```bash
unzip WebView-Helper-V13-Codespaces.zip -d webview-v13
cd webview-v13
```

### 3. 确认目录

```bash
ls
```

这里应该直接看到：

```text
gradlew
build.gradle
settings.gradle
app/
gradle/
```

不要再 `cd` 到第二层项目目录。

### 4. 设置 Wrapper 权限

```bash
chmod +x gradlew
```

### 5. 检查 Java

```bash
java -version
```

Android Gradle Plugin 8.7 使用 JDK 17；如果 Codespaces 当前 Java 不是 17，切换到 JDK 17 后再构建。

### 6. 构建 Debug APK

```bash
./gradlew clean assembleDebug --stacktrace
```

### 7. 找 APK

```bash
find app/build/outputs/apk -type f -name '*.apk' -print
```

通常是：

```text
app/build/outputs/apk/debug/app-debug.apk
```

## 如果构建失败

执行：

```bash
./gradlew clean assembleDebug --stacktrace > build.log 2>&1
```

然后：

```bash
tail -n 120 build.log
```

把最后 120 行发给我。

## 注意

这个包只负责 WebView Helper Android APK 构建。Minecraft WebView Mod 是另一个 Gradle/Fabric 项目，不要在这个目录里构建 Mod。
