package cn.autoforged.android_browser_mod_1789566815;

import net.minecraft.util.Util;

import java.net.URI;

/**
 * Android 端浏览器桥接。
 *
 * <p>Minecraft Java 版本身跑在 JVM 里，无法静态引用 Android SDK。这里全部通过反射调用，
 * 保证在桌面端编译/运行不受影响：
 * <ol>
 *   <li>Android Intent（{@code android.intent.action.VIEW}）——FCL / ZL2 这类基于
 *       PojavLauncher 的启动器把 JVM 跑在 Android 应用进程内，Runtime 里能拿到
 *       {@code android.app.ActivityThread}，从而可以真正唤起系统 WebView / 浏览器。</li>
 *   <li>启动器自带的 Java 辅助方法（候选类名见 {@link #LAUNCHER_HOOKS}）——不同启动器
 *       版本可能自己暴露了 openURL 接口。</li>
 *   <li>桌面回退：{@code Util.getPlatform().openUri(...)}（Linux 上即 xdg-open）。</li>
 * </ol>
 * 所有 Android 相关调用均未实机验证，失败时静默回退。
 */
public final class AndroidBrowserBridge {
    /** 候选启动器辅助类 {类名, 静态方法名(String)}。 */
    private static final String[][] LAUNCHER_HOOKS = {
        {"net.kdt.pojavlaunch.Tools", "openURL"},
        {"net.kdt.pojavlaunch.PojavLauncher", "openURL"},
        {"net.kdt.pojavlaunch.JREUtils", "openURL"},
        {"com.tungsten.fcl.FCLApplication", "openURL"},
        {"com.tungsten.fclauncher.FCLApplication", "openURL"},
    };

    private AndroidBrowserBridge() {
    }

    /**
     * Returns the foreground Activity.
     *
     * Android launchers such as Pojav/Amethyst run the game JVM inside their
     * Activity process, but newer Android versions can restrict reflective access
     * to ActivityThread.mActivities. Therefore V8 uses several fallbacks:
     *  1) the launcher MainActivity's known static touchpad/context object;
     *  2) ActivityThread.mActivities (older Android / permissive ROMs);
     *  3) ActivityThread.currentApplication() as a context-only fallback.
     */
    private static volatile Object cachedActivity;

    public static Object currentActivity() {
        // Fast path: once we have a real Activity, reuse it while it is alive.
        Object cached = cachedActivity;
        if (isUsableActivity(cached)) return cached;

        // ZL2/Pojav exposes its game window as Android Views. In some ZL2 builds the
        // launcher classes are not visible through the Minecraft class loader, and
        // ActivityThread.mActivities is blocked by Android hidden-API rules. In that
        // situation the window-manager root list is the most useful process-local
        // fallback: a root View belongs to the foreground Activity's Context.
        Object fromWindows = activityFromWindowManagerRoots();
        if (fromWindows != null) {
            cachedActivity = fromWindows;
            debugActivity("WindowManagerGlobal", fromWindows);
            return fromWindows;
        }

        // Pojav/ZL2: try known static UI objects first.
        //
        // ZL2 v2 (ZalithLauncher2) is a MULTI-PROCESS launcher. Its AndroidManifest.xml
        // declares (namespace com.movtery.zalithlauncher):
        //   .ui.activities.VMActivity          -> android:process=":game"  (hosts Minecraft surface)
        //   .ui.activities.MainActivity        -> main process             (launcher UI)
        //   .ui.activities.SplashActivity      -> main process             (LAUNCHER entry)
        //   .game.launch.GameService           -> android:process=":game"  (game engine)
        //   .game.download.jvm_server.JvmService -> android:process=":jvm" (runs the JVM)
        // The mod runs inside the game JVM, i.e. in ":game" or ":jvm" — NOT in the main
        // process. Therefore VMActivity is the Activity that is actually in-process while
        // the game runs, and it MUST be probed before the main-process MainActivity.
        // Probing only MainActivity was the root cause of the "ZL2 Activity not found"
        // failure (ZL2ac).
        String[] launcherClasses = {
            // ZL2 v2 — game process (most likely match, highest priority)
            "com.movtery.zalithlauncher.ui.activities.VMActivity",
            // ZL2 v2 — main process fallbacks
            "com.movtery.zalithlauncher.ui.activities.MainActivity",
            "com.movtery.zalithlauncher.ui.activities.SplashActivity",
            "com.movtery.zalithlauncher.ui.activities.ControlEditorActivity",
            // ZL2 v1 / Pojav lineage
            "net.kdt.pojavlaunch.MainActivity",
            "net.kdt.pojavlaunch.customcontrols.ControlEditorActivity"
        };
        String[] likelyFields = {
            "touchpad", "minecraftGLView", "gameView", "glView", "view",
            "surfaceView", "gameSurfaceView", "contentView"
        };
        for (String launcherClass : launcherClasses) {
            for (String field : likelyFields) {
                Object activity = activityFromLauncherField(launcherClass, field);
                if (activity != null) { cachedActivity = activity; debugActivity("LauncherField:" + launcherClass + "." + field, activity); return activity; }
            }
            // Last-resort static-field scan. This handles ZL2/Pojav builds where the
            // actual View field was renamed without requiring a hard dependency on the
            // launcher APK classes.
            Object activity = activityFromAnyStaticViewField(launcherClass);
            if (activity != null) { cachedActivity = activity; debugActivity("LauncherStaticScan:" + launcherClass, activity); return activity; }
        }

        // Generic Android fallback.
        try {
            Class<?> activityThread = loadAndroidClass("android.app.ActivityThread");
            Object thread = activityThread.getMethod("currentActivityThread").invoke(null);
            java.lang.reflect.Field activitiesField = activityThread.getDeclaredField("mActivities");
            activitiesField.setAccessible(true);
            Object activities = activitiesField.get(thread);
            if (activities instanceof java.util.Map<?, ?> map) {
                for (Object record : map.values()) {
                    try {
                        java.lang.reflect.Field paused = findField(record.getClass(), "paused");
                        if (paused != null) {
                            paused.setAccessible(true);
                            if (paused.getBoolean(record)) continue;
                        }
                    } catch (Throwable ignored) {}
                    try {
                        java.lang.reflect.Field a = findField(record.getClass(), "activity");
                        if (a != null) {
                            a.setAccessible(true);
                            Object value = a.get(record);
                            if (value != null && isUsableActivity(value)) { cachedActivity = value; debugActivity("ActivityThread.mActivities", value); return value; }
                        }
                    } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable ignored) {}

        return null;
    }

    private static boolean isUsableActivity(Object value) {
        if (!isActivityObject(value)) return false;
        try {
            if (Boolean.TRUE.equals(value.getClass().getMethod("isFinishing").invoke(value))) return false;
        } catch (Throwable ignored) {}
        try {
            Class<?> activityClass = loadAndroidClass("android.app.Activity");
            if (androidApiAtLeast(17)) {
                Object destroyed = activityClass.getMethod("isDestroyed").invoke(value);
                if (Boolean.TRUE.equals(destroyed)) return false;
            }
        } catch (Throwable ignored) {}
        return true;
    }

    private static boolean androidApiAtLeast(int api) {
        try {
            Class<?> version = loadAndroidClass("android.os.Build$VERSION");
            Object sdk = version.getField("SDK_INT").get(null);
            return ((Number) sdk).intValue() >= api;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static void debugActivity(String source, Object activity) {
        try {
            ExampleMod.LOGGER.info("[WebView-V8] Activity resolved via {} -> {}", source, activity.getClass().getName());
        } catch (Throwable ignored) {}
    }

    /**
     * Finds an Activity from the process' actual Android window roots. This is useful
     * in Zalith/Pojav because the Minecraft JVM may not have the launcher Activity's
     * class loader, while the Android window hierarchy is still in the same process.
     */
    private static Object activityFromWindowManagerRoots() {
        try {
            Class<?> wmg = loadAndroidClass("android.view.WindowManagerGlobal");
            Object instance = wmg.getMethod("getInstance").invoke(null);

            // Android versions differ: prefer getRootViews(), then fall back to mViews.
            Object views = null;
            try {
                views = wmg.getMethod("getRootViews").invoke(instance);
            } catch (Throwable ignored) {}
            if (views == null) {
                java.lang.reflect.Field f = findField(wmg, "mViews");
                if (f != null) { f.setAccessible(true); views = f.get(instance); }
            }
            if (views instanceof java.util.List<?> list) {
                for (Object view : list) {
                    Object activity = activityFromObject(view);
                    if (isUsableActivity(activity)) return activity;
                }
            }

            // Some releases expose roots as mRoots (ViewRootImpl objects). Resolve
            // ViewRootImpl.mView -> View.getContext() as a final window-level fallback.
            java.lang.reflect.Field rootsField = findField(wmg, "mRoots");
            if (rootsField != null) {
                rootsField.setAccessible(true);
                Object roots = rootsField.get(instance);
                if (roots instanceof java.util.List<?> list) {
                    for (Object root : list) {
                        if (root == null) continue;
                        java.lang.reflect.Field viewField = findField(root.getClass(), "mView");
                        if (viewField == null) continue;
                        viewField.setAccessible(true);
                        Object view = viewField.get(root);
                        Object activity = activityFromObject(view);
                        if (isUsableActivity(activity)) return activity;
                    }
                }
            }
        } catch (Throwable t) {
            // Hidden-API restrictions are expected on some Android versions; continue to
            // the launcher/ActivityThread fallbacks below.
            try { ExampleMod.LOGGER.debug("[WebView-V8] WindowManagerGlobal lookup unavailable: {}", t.toString()); } catch (Throwable ignored) {}
        }
        return null;
    }

    private static Object activityFromLauncherField(String className, String fieldName) {
        try {
            Class<?> clazz = Class.forName(className);
            java.lang.reflect.Field field = findField(clazz, fieldName);
            if (field == null) return null;
            field.setAccessible(true);
            Object value = field.get(null);
            if (value == null) return null;

            // Touchpad / View -> Context -> Activity.
            try {
                java.lang.reflect.Method getContext = value.getClass().getMethod("getContext");
                Object context = getContext.invoke(value);
                if (isActivityObject(context)) return context;
            } catch (Throwable ignored) {}

            // In case a launcher field itself is an Activity.
            if (isActivityObject(value)) return value;
        } catch (Throwable ignored) {}
        return null;
    }


    private static Object activityFromAnyStaticViewField(String className) {
        try {
            Class<?> clazz = Class.forName(className);
            Class<?> c = clazz;
            while (c != null) {
                for (java.lang.reflect.Field field : c.getDeclaredFields()) {
                    if (!java.lang.reflect.Modifier.isStatic(field.getModifiers())) continue;
                    try {
                        field.setAccessible(true);
                        Object value = field.get(null);
                        if (value == null) continue;
                        Object activity = activityFromObject(value);
                        if (activity != null) return activity;
                    } catch (Throwable ignored) {}
                }
                c = c.getSuperclass();
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private static Object activityFromObject(Object value) {
        if (value == null) return null;
        if (isActivityObject(value)) return value;
        // View -> Context -> Activity.
        try {
            java.lang.reflect.Method getContext = value.getClass().getMethod("getContext");
            Object context = getContext.invoke(value);
            Object activity = activityFromContext(context);
            if (activity != null) return activity;
        } catch (Throwable ignored) {}
        return activityFromContext(value);
    }

    private static Object activityFromContext(Object context) {
        Object current = context;
        for (int i = 0; i < 8 && current != null; i++) {
            if (isActivityObject(current)) return current;
            try {
                java.lang.reflect.Method base = current.getClass().getMethod("getBaseContext");
                Object next = base.invoke(current);
                if (next == current) break;
                current = next;
            } catch (Throwable ignored) {
                break;
            }
        }
        return null;
    }

    private static java.lang.reflect.Field findField(Class<?> type, String name) {
        Class<?> c = type;
        while (c != null) {
            try {
                return c.getDeclaredField(name);
            } catch (NoSuchFieldException ignored) {
                c = c.getSuperclass();
            }
        }
        return null;
    }


    private static boolean isActivityObject(Object value) {
        if (value == null) return false;
        try {
            return loadAndroidClass("android.app.Activity").isInstance(value);
        } catch (Throwable ignored) {
            return false;
        }
    }

    /**
     * Loads an Android framework class without assuming the Minecraft/JVM application
     * class loader exposes every framework class directly.
     */
    private static Class<?> loadAndroidClass(String name) throws ClassNotFoundException {
        ClassNotFoundException first = null;
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException e) {
            first = e;
        }
        Object app = null;
        try {
            // ActivityThread is itself a framework class; if the default loader failed,
            // try the bootstrap/system loader explicitly.
            ClassLoader bootstrap = ClassLoader.getSystemClassLoader();
            if (bootstrap != null) return Class.forName(name, true, bootstrap);
        } catch (Throwable ignored) {}
        if (first != null) throw first;
        throw new ClassNotFoundException(name);
    }

    /**
     * Returns the Android Application Context through reflection, if available.
     *
     * <p>ZL2 v2 runs the game JVM in a NON-main process (":game" or ":jvm"). Android
     * process isolation means the main-process MainActivity can never be reached from the
     * game JVM. {@code ActivityThread.currentApplication()} is reachable from any process
     * of the app and returns the single Application object, so it is the most reliable
     * Context source available to the mod when no Activity is in-process.
     *
     * <p>A WebView built on the Application context still renders pages and executes JS;
     * only Activity-bound features degrade (file pickers, JS dialogs). That is far better
     * than disabling the browser completely, which is what V6/V7 did.
     */
    public static Object applicationContext() {
        try {
            Class<?> activityThread = loadAndroidClass("android.app.ActivityThread");
            Object application = activityThread.getMethod("currentApplication").invoke(null);
            if (application == null) return null;
            try {
                Object ctx = application.getClass().getMethod("getApplicationContext").invoke(application);
                if (ctx != null) return ctx;
            } catch (Throwable ignored) {}
            // Application itself IS a Context; returning it directly is a valid fallback.
            return application;
        } catch (Throwable ignored) {
            return null;
        }
    }

    /**
     * Returns the best usable Android Context: the foreground Activity when one can be
     * resolved, otherwise the Application context (degraded but usable). Returns null only
     * when no Android Context can be reached at all (i.e. not running on Android).
     */
    public static Object bestContext() {
        Object activity = currentActivity();
        if (activity != null) return activity;
        return applicationContext();
    }

    /** True when a real Activity was resolved (full-fidelity mode). */
    public static boolean hasActivity() { return currentActivity() != null; }

    /** Best-effort current process name (":game", ":jvm", or the package name). */
    public static String processName() {
        try {
            // ActivityThread.currentProcessName() exists on API 18+.
            Class<?> activityThread = loadAndroidClass("android.app.ActivityThread");
            Object name = activityThread.getMethod("currentProcessName").invoke(null);
            if (name != null) return String.valueOf(name);
        } catch (Throwable ignored) {}
        return "unknown";
    }

    /** Diagnostic description of the resolved Context, shown in the in-game debug panel. */
    public static String contextDiagnostics() {
        Object activity = currentActivity();
        Object app = applicationContext();
        String mode = activity != null ? "ACTIVITY"
            : (app != null ? "APPLICATION(degraded)" : "NONE");
        return "process=" + processName()
            + " | activity=" + (activity == null ? "none" : activity.getClass().getName())
            + " | application=" + (app == null ? "none" : app.getClass().getName())
            + " | mode=" + mode;
    }

    /** 判断当前是否跑在 Android 启动器里（FCL / ZL2 / PojavLauncher 系）。 */
    public static boolean isAndroidRuntime() {
        String vm = System.getProperty("java.vm.name", "");
        String os = System.getProperty("os.name", "");
        String vendor = System.getProperty("java.vendor", "");
        String probe = (vm + " " + os + " " + vendor).toLowerCase();
        if (probe.contains("dalvik") || probe.contains("android") || probe.contains("art runtime")) {
            return true;
        }
        return System.getenv("POJAV_LAUNCHER") != null
            || System.getenv("FCL") != null
            || System.getenv("ZL2") != null
            || System.getProperty("pojav.launcher") != null
            || System.getProperty("fcl.launcher") != null;
    }

    /**
     * 尝试用系统浏览器 / WebView 打开 url。
     *
     * @return true 表示至少有一条桥接路径成功执行
     */
    public static boolean openExternal(String url) {
        if (url == null || url.isBlank()) {
            return false;
        }
        if (openWithAndroidIntent(url)) {
            ExampleMod.LOGGER.info("已通过 Android Intent 打开 {}", url);
            return true;
        }
        if (openWithLauncherHook(url)) {
            ExampleMod.LOGGER.info("已通过启动器辅助接口打开 {}", url);
            return true;
        }
        try {
            Util.getPlatform().openUri(new URI(url));
            ExampleMod.LOGGER.info("已通过系统 openUri 打开 {}", url);
            return true;
        } catch (Exception e) {
            ExampleMod.LOGGER.warn("无法打开外部链接 {}", url, e);
            return false;
        }
    }

    private static boolean openWithAndroidIntent(String url) {
        try {
            Class<?> activityThread = Class.forName("android.app.ActivityThread");
            Object application = activityThread.getMethod("currentApplication").invoke(null);
            if (application == null) {
                return false;
            }
            Class<?> contextClass = Class.forName("android.content.Context");
            Class<?> intentClass = Class.forName("android.content.Intent");
            Class<?> uriClass = Class.forName("android.net.Uri");

            Object intent = intentClass.getConstructor(String.class).newInstance("android.intent.action.VIEW");
            Object uri = uriClass.getMethod("parse", String.class).invoke(null, url);
            intentClass.getMethod("setData", uriClass).invoke(intent, uri);
            // FLAG_ACTIVITY_NEW_TASK：从非 Activity 上下文启动必须加
            intentClass.getMethod("addFlags", int.class).invoke(intent, 0x10000000);
            contextClass.getMethod("startActivity", intentClass).invoke(application, intent);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean openWithLauncherHook(String url) {
        for (String[] hook : LAUNCHER_HOOKS) {
            try {
                Class<?> clazz = Class.forName(hook[0]);
                clazz.getMethod(hook[1], String.class).invoke(null, url);
                return true;
            } catch (Throwable ignored) {
                // 换下一个候选
            }
        }
        return false;
    }
}
